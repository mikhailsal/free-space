"""Draft canonical campaign helper; case 0 independently builds same-app 4f22 and e826 with candidate mode."""
import argparse
from contextlib import ExitStack
import datetime as dt
import fcntl
import hashlib
import json
import os
from pathlib import Path
import re
import resource
import subprocess
import tempfile

ROOT = Path('/home/tass/myprojects/corp_v2/free-space')
OUT = ROOT / 'docs/benchmark-results'
MANIFEST = OUT / 'v1-cache4-canonical-manifest-2026-11-01.json'
LEDGER = OUT / 'v1-w1-campaign-2026-10-31.json'
JOURNAL = Path('/tmp/freespace-cache4-canonical-bookkeeping-pending.json')
LOCK = Path('/tmp/freespace-cache4-canonical-bookkeeping.lock')
GLOBAL_LOCK = Path('/tmp/freespace-v1-campaign-ledger.lock')
COMPAT_LOCK = Path('/tmp/freespace-cache4-mechanism-bookkeeping.lock')
RECEIPT_DIR = Path('/tmp')
FREEZE = Path('/tmp/freespace-cache4-canonical-source-freeze.json')
IDS = ('cache4-canonical-aa', 'cache4-canonical-candidate')
BASE = 'e8265778ef78ec4acd9da1375eedb0be37a123f5'
APP_MECHANISM_REFERENCE = '63d98cc8ff88a54ab9687c5fb93fffd930e33d26'
CONTROL_HEAD = '4f22bf8e3b67f7f59049a72116b90c061fb1328b'
BASE_BINARY = 'ed2a1cb138b1e48e70a388a4a8fda3e79fcfd2e37fd0c061d41d2d6363f8e980'
PRIOR_HELPER = Path('/tmp/freespace-admit-cache4-mechanism.py')
PRIOR_MANIFEST = OUT / 'v1-cache4-mechanism-manifest-2026-11-01.json'
PRIOR_FREEZE = Path('/tmp/freespace-cache4-mechanism-source-freeze.json')
CANDIDATE = '1af549a8f1d834fb292e78a6cbd48ad9d12252cd'
BRANCHES = ('perf/v1-memory-candidate-control', 'perf/v1-root-reuse-cache4')
HEADS = (CONTROL_HEAD, CANDIDATE)
EPOCH = '1793464183'
WT = Path('/tmp/free-space-v1-root-reuse-cache4')
CONTROL_WT = Path('/tmp/free-space-v1-memory-candidate-control')
TARGET = 'x86_64-unknown-linux-musl'
WORKFLOW = '.github/workflows/representative-bench.yml'
CAP = 216000


def require(condition, message):
    if not condition:
        raise ValueError(message)


def read(path):
    return json.loads(path.read_bytes())


def encoded(value):
    return (json.dumps(value, indent=2, allow_nan=False) + '\n').encode()


def digest(value):
    return hashlib.sha256(value).hexdigest()


def sync_dir(directory):
    fd = os.open(directory, os.O_RDONLY | os.O_DIRECTORY)
    try:
        os.fsync(fd)
    finally:
        os.close(fd)


def atomic_write(path, data):
    fd, temporary = tempfile.mkstemp(prefix='.' + path.name + '.', dir=path.parent)
    try:
        with os.fdopen(fd, 'wb') as out:
            out.write(data)
            out.flush()
            os.fsync(out.fileno())
        os.replace(temporary, path)
        sync_dir(path.parent)
    finally:
        if os.path.exists(temporary):
            os.unlink(temporary)


def recover():
    if not JOURNAL.exists():
        return False
    journal = read(JOURNAL)
    entries = journal['entries']
    require(journal.get('version') == 1 and len(entries) == 3, 'invalid journal')
    paths = [LEDGER, MANIFEST, RECEIPT_DIR / ('freespace-' + journal['plan_id'] + '-dispatch.json')]
    require(journal['plan_id'] in IDS and [entry['path'] for entry in entries] == list(map(str, paths)),
            'journal paths invalid')
    for path, entry in zip(paths, entries):
        new = entry['new'].encode()
        require(digest(new) == entry['new_sha256'] and digest(path.read_bytes()) in
                (entry['old_sha256'], entry['new_sha256']), 'journal conflict: ' + str(path))
    for path, entry in zip(paths, entries):
        current = digest(path.read_bytes())
        require(current in (entry['old_sha256'], entry['new_sha256']), 'journal conflict before replacement: ' + str(path))
        if current != entry['new_sha256']:
            atomic_write(path, entry['new'].encode())
    JOURNAL.unlink()
    sync_dir(JOURNAL.parent)
    return True


def one(rows, ident):
    found = [row for row in rows if row.get('id') == ident]
    require(len(found) == 1, 'expected exactly one ' + ident)
    return found[0]


def gh_json(args):
    raw = subprocess.check_output(['gh', *args], cwd=ROOT, timeout=60)
    require(len(raw) <= 8 * 1024 * 1024, 'GitHub response too large')
    return json.loads(raw)


def fetch_run(run_id):
    repo = gh_json(['repo', 'view', '--json', 'nameWithOwner'])['nameWithOwner']
    require(re.fullmatch(r'[A-Za-z0-9_.-]+/[A-Za-z0-9_.-]+', repo) is not None, 'invalid repository')
    run = gh_json(['api', f'repos/{repo}/actions/runs/{run_id}'])
    pages = gh_json(['api', '--paginate', '--slurp', f'repos/{repo}/actions/runs/{run_id}/jobs?per_page=100'])
    require(isinstance(pages, list), 'invalid jobs pages')
    jobs = [job for page in pages for job in page['jobs']]
    require(len(jobs) <= 1000, 'too many jobs')
    return run, jobs


def seconds(jobs):
    total = 0.0
    for job in jobs:
        if job.get('status') != 'completed' or job.get('conclusion') == 'skipped':
            continue
        start = dt.datetime.fromisoformat(job['started_at'].replace('Z', '+00:00'))
        end = dt.datetime.fromisoformat(job['completed_at'].replace('Z', '+00:00'))
        require(start.tzinfo is not None and end.tzinfo is not None, 'job timestamps must be aware')
        total += max(0, (end - start).total_seconds())
    return total


def active_seconds(jobs, now):
    total = 0.0
    for job in jobs:
        if job.get('status') != 'in_progress' or not job.get('started_at'):
            continue
        start = dt.datetime.fromisoformat(job['started_at'].replace('Z', '+00:00'))
        require(start.tzinfo is not None, 'job timestamps must be aware')
        total += max(0, (now - start).total_seconds())
    return total


def accounting(ledger):
    require(ledger['aggregate_cap_runner_seconds'] == CAP, 'unexpected aggregate cap')
    planned = sum(p['maximum_job_seconds'] for p in ledger['planned_next_dispatches'])
    completed = sum(p.get('completed_job_seconds', 0) for p in ledger['runs'])
    committed = planned + sum(p['completed_job_seconds'] if p['status'] == 'completed'
                              else p['maximum_job_seconds'] for p in ledger['runs'])
    require(0 <= committed <= CAP, 'aggregate cap exceeded')
    active = sum(p.get('running_job_seconds_observed', 0) for p in ledger['runs'])
    ledger.update(planned_reserved_seconds=planned, completed_job_seconds=completed,
                  running_job_seconds_observed=active, used_runner_seconds_observed=completed + active,
                  maximum_committed_seconds=committed, remaining_unreserved_seconds=CAP - committed)



PLAN_MUTABLE = {'status', 'run_id', 'created_at', 'conclusion', 'head_sha_verified', 'completed_job_seconds',
                'running_job_seconds_observed', 'usage_observed_at', 'job_seconds', 'measurement_validation',
                'measurement_validation_error', 'observed_baseline_sha256', 'observed_candidate_sha256', 'evidence_sha256'}
TOP_MUTABLE = {'source_hash_manifest_sha256', 'updated_at'}


def bind_manifest(manifest, freeze):
    draft = read(Path(freeze['draft_manifest_path']))
    require(set(manifest) <= set(draft) | TOP_MUTABLE and set(draft) <= set(manifest), 'manifest top-level keys differ')
    for key in set(draft) - {'plans'}:
        require(manifest[key] == draft[key], 'manifest policy changed: ' + key)
    require(len(manifest['plans']) == len(draft['plans']), 'manifest plan count changed')
    for actual, original in zip(manifest['plans'], draft['plans']):
        require(set(actual) <= set(original) | PLAN_MUTABLE and set(original) <= set(actual), 'plan keys differ')
        for key in set(original) - PLAN_MUTABLE:
            require(actual[key] == original[key], 'plan policy changed: ' + key)
        if actual.get('status') == 'planned':
            require(actual == original, 'planned case differs from reviewed draft')


def listing_for(index):
    listing = gh_json(['run', 'list', '--workflow', 'representative-bench.yml', '--branch', BRANCHES[index],
                       '--event', 'workflow_dispatch', '--limit', '100', '--json', 'databaseId,headSha,event,createdAt'])
    require(isinstance(listing, list) and len(listing) < 100, 'truncated workflow listing')
    return listing


def registered_identity(run_id, run, receipt, freeze, ledger, index):
    attempted = dt.datetime.fromisoformat(receipt['dispatch_attempted_at'].replace('Z', '+00:00'))
    require(attempted.tzinfo is not None, 'attempt time lacks timezone')
    start = attempted.replace(microsecond=0); end = attempted + dt.timedelta(seconds=300)
    listing = listing_for(index)
    historical = {r['databaseId'] for r in freeze['historical_workflow_runs']}
    known = {r.get('run_id') for r in ledger['runs']}
    unknown = [r for r in listing if r.get('headSha') == HEADS[index] and r.get('databaseId') not in historical | known]
    require(len(unknown) == 1 and unknown[0].get('databaseId') == run_id, 'ambiguous or foreign same-head dispatch')
    item = unknown[0]
    created = dt.datetime.fromisoformat(item['createdAt'].replace('Z', '+00:00'))
    require(created.tzinfo is not None and start <= created <= end and item['event'] == 'workflow_dispatch'
            and item['createdAt'] == run['created_at'] and run_id not in historical, 'run creation outside attempt window')
    check_historical_runs([r for r in listing if r['databaseId'] != run_id], freeze, index, ledger)

def update(mode, plan_id, run_id, run, jobs):
    require(plan_id in IDS and type(run_id) is int and run_id > 0, 'invalid case or run')
    receipt_path = RECEIPT_DIR / ('freespace-' + plan_id + '-dispatch.json')
    captured = {path: path.read_bytes() for path in (LEDGER, MANIFEST, receipt_path)}
    ledger, manifest = json.loads(captured[LEDGER]), json.loads(captured[MANIFEST])
    require(manifest.get('status') == 'registered' and manifest.get('research_only') is True
            and manifest.get('product_qualification') is False, 'manifest is not registered research')
    freeze_bytes = FREEZE.read_bytes()
    require(digest(freeze_bytes) == manifest.get('source_hash_manifest_sha256'), 'source freeze hash mismatch')
    bind_manifest(manifest, json.loads(freeze_bytes))
    manifest_plan = one(manifest['plans'], plan_id)
    if mode == 'register':
        plan = one(ledger['planned_next_dispatches'], plan_id)
        require(plan == manifest_plan and plan.get('status') == 'planned', 'planned records differ')
        require(not any(p.get('id') == plan_id or p.get('run_id') == run_id for p in ledger['runs'])
                and run_id not in ledger['run_ids'], 'duplicate case or run')
    else:
        require(mode == 'refresh', 'invalid mode')
        plan = one(ledger['runs'], plan_id)
        require(plan == manifest_plan and plan.get('run_id') == run_id, 'registered records differ')
        require(ledger['run_ids'].count(run_id) == 1, 'run id ledger mismatch')
    revision = plan.get('revision')
    fixed_case(plan, IDS.index(plan_id))
    freeze = json.loads(freeze_bytes)
    source_checks(freeze)
    outside_review_checks(freeze)
    require(digest(Path(__file__).read_bytes()) == freeze.get('helper_sha256'), 'registrar hash mismatch')
    require(isinstance(revision, str) and re.fullmatch('[0-9a-f]{40}', revision) is not None
            and HEADS[IDS.index(plan_id)] == revision
            and plan.get('branch') == BRANCHES[IDS.index(plan_id)] and manifest.get('candidate_revision') == CANDIDATE,
            'frozen plan identity invalid')
    require(type(run.get('id')) is int and run.get('id') == run_id and run.get('head_sha') == revision and run.get('head_branch') == BRANCHES[IDS.index(plan_id)]
            and run.get('event') == 'workflow_dispatch' and run.get('path') == WORKFLOW
            and type(run.get('run_attempt')) is int and run['run_attempt'] == 1, 'GitHub run identity mismatch')
    require(run.get('status') in ('queued', 'in_progress', 'completed', 'waiting', 'pending', 'requested')
            and isinstance(run.get('created_at'), str) and run['created_at'], 'invalid GitHub run status')
    if run['status'] == 'completed':
        require(len(jobs) == 2 and {job.get('name') for job in jobs} == {'build', 'paired'}
                and all(job.get('status') == 'completed' for job in jobs),
                'terminal run jobs incomplete')
    if mode == 'refresh':
        require(plan['created_at'] == run['created_at'], 'run creation time changed')
        if plan['status'] == 'completed':
            require(run['status'] == 'completed' and plan['conclusion'] == run['conclusion'], 'completed run changed')
    receipt = json.loads(captured[receipt_path])
    require('dispatched' in receipt and receipt.get('plan_id') == plan_id and receipt.get('expected_head_sha') == revision
            and receipt.get('dispatched') is not False and receipt.get('dispatch_attempted_at'),
            'dispatch receipt mismatch')
    require(receipt.get('run_id') in (None, run_id), 'receipt run id mismatch')
    created = dt.datetime.fromisoformat(run['created_at'].replace('Z', '+00:00'))
    attempted = dt.datetime.fromisoformat(receipt['dispatch_attempted_at'].replace('Z', '+00:00'))
    require(created.tzinfo is not None and attempted.tzinfo is not None and attempted.replace(microsecond=0) <= created <= attempted + dt.timedelta(seconds=300),
            'run predates dispatch attempt')
    require(run_id not in {item['databaseId'] for item in freeze['historical_workflow_runs']},
            'historical run cannot be registered')
    if mode == 'register':
        registered_identity(run_id, run, receipt, freeze, ledger, IDS.index(plan_id))
    now = dt.datetime.now(dt.timezone.utc)
    active = active_seconds(jobs, now) if run['status'] != 'completed' else 0
    plan.update(run_id=run_id, created_at=run['created_at'], status=run['status'], conclusion=run['conclusion'],
                head_sha_verified=True, completed_job_seconds=seconds(jobs),
                running_job_seconds_observed=active, usage_observed_at=now.isoformat())
    if run['status'] == 'completed':
        plan['job_seconds'] = plan['completed_job_seconds']
    if mode == 'register':
        plan['measurement_validation'] = 'unverified'
        ledger['runs'].append(plan.copy())
        ledger['run_ids'].append(run_id)
        ledger['planned_next_dispatches'] = [p for p in ledger['planned_next_dispatches'] if p['id'] != plan_id]
    manifest_plan.update(plan)
    accounting(ledger)
    now_text = now.isoformat()
    ledger['updated_at'] = manifest['updated_at'] = now_text
    receipt.update(run_id=run_id, registration_head_sha=revision, registration_verified_at=now_text,
                   registration_run_status=run['status'])
    states = [(LEDGER, ledger), (MANIFEST, manifest), (receipt_path, receipt)]
    entries = []
    for path, state in states:
        old, new = captured[path], encoded(state)
        require(path.read_bytes() == old, 'concurrent modification before journal: ' + str(path))
        entries.append({'path': str(path), 'old_sha256': digest(old), 'new_sha256': digest(new), 'new': new.decode()})
    require(not JOURNAL.exists(), 'pending journal exists')
    require(all(path.read_bytes() == captured[path] for path, _ in states), 'concurrent modification before journal')
    atomic_write(JOURNAL, encoded({'version': 1, 'plan_id': plan_id, 'entries': entries}))
    recover()
    return {'run_id': run_id, 'plan_id': plan_id, 'status': run['status'],
            'maximum_committed_seconds': ledger['maximum_committed_seconds']}



def command(args, cwd=WT):
    return subprocess.check_output(args, cwd=cwd, text=True, timeout=60).strip()



# Exact audited benchmark-only changes; every other tree path is treated as application/build input.
NONBUILD_PATHS = frozenset({
    '.github/workflows/representative-bench.yml', 'scripts/bench-representative.sh',
    'scripts/bench_v1_admission.py', 'scripts/bench_v1_fixture.py', 'scripts/bench_v1_pair.py',
    'scripts/bench_v1_runner_prepare.py', 'scripts/bench_v1_runtime.py', 'scripts/bench_v1_summary.py',
    'scripts/tests/test_bench_cleanup.py', 'scripts/tests/test_bench_v1_admission.py',
    'scripts/tests/test_bench_v1_runner_prepare.py', 'scripts/tests/test_bench_v1_runtime.py',
    'scripts/tests/test_bench_v1_summary.py',
})


def application_diff(base, head):
    return set(command(['git', 'diff', '--name-only', base, head]).splitlines()) - NONBUILD_PATHS

def source_checks(freeze):
    require(freeze.get('helper_sha256') == digest(Path(__file__).read_bytes()), 'helper freeze mismatch')
    require(freeze.get('baseline_revision') == BASE and freeze.get('candidate_revision') == CANDIDATE
            and freeze.get('baseline_source_epoch') == EPOCH, 'freeze source identity')
    for tree, head in ((CONTROL_WT, CONTROL_HEAD), (WT, CANDIDATE)):
        require(command(['git', 'rev-parse', 'HEAD'], tree) == head
                and not command(['git', 'status', '--porcelain', '--untracked-files=no'], tree), 'dirty tree')
    require(command(['git', 'show', '-s', '--format=%ct', BASE]) == EPOCH, 'epoch mismatch')
    require(not application_diff(BASE, CONTROL_HEAD), 'control application differs')
    changed = application_diff(BASE, CANDIDATE)
    require(len(changed) == 11 and set(changed) == set(freeze['composed_app_sha256']), 'composed source set mismatch')
    for path in changed:
        require(digest((WT / path).read_bytes()) == freeze['composed_app_sha256'][path], 'composed source bytes mismatch')
    require(command(['git', 'diff', '--name-only', APP_MECHANISM_REFERENCE, CANDIDATE]).splitlines() == ['core/src/scan/staged.rs'], 'source scope mismatch')
    before = subprocess.check_output(['git', 'show', APP_MECHANISM_REFERENCE + ':core/src/scan/staged.rs'], cwd=WT)
    after = (WT / 'core/src/scan/staged.rs').read_bytes()
    require(before.count(b'const CACHE_KIB: u64 = 8192;') == 1 and before.replace(
        b'const CACHE_KIB: u64 = 8192;', b'const CACHE_KIB: u64 = 4096;') == after, 'not exact cache delta')
    paths = command(['git', 'ls-files', 'scripts', '.github/workflows']).splitlines()
    expected = freeze['protocol_sha256']
    require(len(paths) == 54 and set(paths) == set(expected), 'protocol paths mismatch')
    for path in paths:
        data = (WT / path).read_bytes()
        require(digest(data) == expected[path] == digest((CONTROL_WT / path).read_bytes()), 'protocol bytes mismatch: ' + path)
    prompt_path = Path(freeze['review_prompt_path'])
    require(digest(prompt_path.read_bytes()) == freeze['review_prompt_path_sha256'], 'source review prompt changed')
    prompt = prompt_path.read_bytes()
    patch = subprocess.check_output(['git', 'diff', APP_MECHANISM_REFERENCE, CANDIDATE, '--', 'core/src/scan/staged.rs'], cwd=WT)
    require(after in prompt and patch in prompt, 'source body or exact diff missing from review prompt')
    review = read(Path(freeze['review_path']))
    validation = read(Path(freeze['review_validation_path']))
    disposition = read(Path(freeze['review_disposition_path']))
    for key in ('review_path', 'review_validation_path', 'review_disposition_path'):
        require(digest(Path(freeze[key]).read_bytes()) == freeze[key + '_sha256'], 'review evidence changed')
    require(review.get('status') == 'completed' and review.get('exit_code') == 0
            and review.get('is_error') is not True and set(review.get('modelUsage', {})) == {'claude-opus-5-5'}
            and '[P3]' in review.get('result', '') and 'v2' in review['result']
            and validation.get('valid') is True and validation.get('result') == review['result']
            and validation.get('checked', {}).get('completed') is True
            and validation.get('checked', {}).get('gate') == 'pass'
            and 'v2' in disposition.get('constant_scope', '') and 'unmeasured' in disposition.get('measurement_scope', '')
            and disposition.get('source_sha256') == digest(after), 'review disposition mismatch')



def outside_review_checks(freeze):
    review = freeze['outside_review']
    required = {str(Path(__file__)), '/tmp/test-freespace-cache4-canonical-admission.py',
                str(PRIOR_HELPER), freeze['draft_manifest_path'], freeze['prereg_audit_path']}
    require(len(required) == 5, 'review input paths overlap')
    for key in ('prompt_path', 'raw_path', 'validation_path'):
        require(digest(Path(review[key]).read_bytes()) == review[key + '_sha256'], 'outside review evidence changed')
    prompt = Path(review['prompt_path']).read_text()
    begin, end = '\nBEGIN_REVIEW_INPUTS_JSON\n', '\nEND_REVIEW_INPUTS_JSON\n'
    require(prompt.count(begin) == 1 and prompt.count(end) == 1 and prompt.endswith(end), 'bad outside review packet')
    data = json.loads(prompt.split(begin, 1)[1][:-len(end)])
    require(set(data) == {'private_files', 'composed_app_files'} and set(data['private_files']) == required, 'outside review inputs mismatch')
    require(set(data['composed_app_files']) == set(freeze['composed_app_sha256']) and len(data['composed_app_files']) == 11, 'composed review set mismatch')
    for path, entry in data['composed_app_files'].items():
        require(isinstance(entry, dict) and set(entry) == {'content', 'sha256'} and isinstance(entry['content'], str), 'invalid composed review body')
        body = entry['content'].encode()
        require(digest(body) == entry['sha256'] == freeze['composed_app_sha256'][path] and (WT / path).read_bytes() == body, 'composed reviewed body changed')
    for path, entry in data['private_files'].items():
        require(isinstance(entry, dict) and set(entry) == {'content', 'sha256'} and isinstance(entry['content'], str), 'invalid reviewed body')
        content = entry['content'].encode()
        require(digest(content) == entry['sha256'] and Path(path).read_bytes() == content, 'outside reviewed body changed')
    raw, validation = read(Path(review['raw_path'])), read(Path(review['validation_path']))
    require(raw.get('status') == 'completed' and raw.get('exit_code') == 0 and raw.get('is_error') is not True
            and set(raw.get('modelUsage', {})) == {'claude-opus-5-5'} and raw.get('result', '').strip() == 'NO_FINDINGS'
            and validation.get('valid') is True and validation.get('result') == raw['result']
            and validation.get('checked', {}).get('completed') is True and validation.get('checked', {}).get('gate') == 'pass',
            'helper outside review not clean')

def fixed_case(plan, index):
    fixed = {'id': IDS[index], 'branch': BRANCHES[index], 'revision': HEADS[index], 'baseline': BASE,
             'comparison': 'candidate', 'stage': 'screen', 'operations': ['scan', 'refresh'],
             'files': 1000000, 'expected_entries': 1004499, 'pairs_per_operation': 3, 'subtree_entries': 100,
             'scenario': 'unchanged', 'memory_mib': 4096, 'swap_mib': 0, 'setup_memory_mib': 4096,
             'observer_memory_mib': 4096, 'cpus': 2, 'workers': 1, 'target': TARGET, 'io': 'local',
             'timeout_minutes': 55, 'forecast_seconds': 1950, 'forecast_with_margin_seconds': 2535,
             'maximum_job_seconds': 5400, 'research_only': True}
    require(all(plan.get(k) == v for k, v in fixed.items()), 'fixed case mismatch')
    require(plan.get('artifact_prefix') == '/tmp/freespace-' + IDS[index]
            and plan.get('binary_artifact_prefix') == '/tmp/freespace-' + IDS[index] + '-binaries', 'artifact path mismatch')



class EvidenceMismatch(ValueError):
    """An available measurement receipt contradicts the preregistered case."""


def evidence_require(condition, message):
    if not condition:
        raise EvidenceMismatch(message)


def validate_log(log, index):
    # Match actual step output/env, never the echoed shell body.
    required = [
        ('build', 'Validate per-stage time envelope', 'STAGE: screen'),
        ('build', 'Validate per-stage time envelope', 'REQUESTED_MINUTES: 55'),
        ('build', 'Validate per-stage time envelope', 'COMPARISON: candidate'),
        ('build', 'Build both arms with one recorded toolchain', 'COMPARISON: candidate'),
        ('paired', 'Paired v1 commands with isolated observers', 'BENCH_IO: local'),
        ('paired', 'Paired v1 commands with isolated observers', 'STAGE: screen'),
    ]
    lines = log.splitlines()
    for job, step, field in required:
        evidence_require(any(line.startswith(job + '\t' + step + '\t') and
                             re.search(r'\s' + re.escape(field) + r'\s*$', line) for line in lines),
                         'missing run log field: ' + field)
    evidence_require(any(line.startswith('build\tBuild both arms with one recorded toolchain\t')
                         and re.search(r'Preparing worktree \(detached HEAD ' + BASE[:7] + r'[0-9a-f]*\)\s*$', line)
                         for line in lines), 'independent baseline worktree not observed')


def fetch_log(run_id):
    cap = 16 * 1024 * 1024
    def cap_output():
        resource.setrlimit(resource.RLIMIT_FSIZE, (cap + 1, cap + 1))
    with tempfile.TemporaryFile() as output:
        subprocess.run(['gh', 'run', 'view', str(run_id), '--log'], cwd=ROOT, stdout=output,
                       stderr=subprocess.PIPE, timeout=60, check=True, preexec_fn=cap_output)
        output.seek(0)
        data = output.read(cap + 1)
    if len(data) > cap: raise OSError('run log exceeds 16 MiB limit')
    return data.decode('utf-8')


def evidence_hashes(plan, log):
    paths = []
    for operation in ('scan', 'refresh'):
        root = Path(plan['artifact_prefix']) / operation / 'measurements'
        if not root.is_dir(): raise FileNotFoundError(root)
        paths.extend(p for p in root.rglob('*') if p.is_file())
    paths += [Path(str(plan['artifact_prefix']) + '-github.json'),
              Path(plan['binary_artifact_prefix']) / 'baseline', Path(plan['binary_artifact_prefix']) / 'candidate']
    if len(paths) > 1000: raise OSError('too many evidence files')
    hashes = {str(path): digest(path.read_bytes()) for path in sorted(paths)}
    hashes['github_live_log_utf8_sha256'] = digest(log.encode('utf-8'))
    return hashes

def validate_artifacts(plan, ledger, index, expected_baseline=None, proof=None, log_override=None, log_capture=None):
    import sys
    sys.path.insert(0, str(CONTROL_WT / 'scripts'))
    from bench_v1_summary import summarize
    from bench_v1_profile import analyze
    registered = one(ledger['runs'], IDS[index])
    evidence_require(plan == registered and plan.get('status') == 'completed' and plan.get('conclusion') == 'success', 'control not validly registered')
    fixed_case(plan, index)
    live, live_jobs = fetch_run(plan['run_id'])
    evidence_require(live.get('id') == plan['run_id'] and live.get('head_sha') == HEADS[index]
            and live.get('head_branch') == BRANCHES[index] and live.get('event') == 'workflow_dispatch'
            and live.get('path') == WORKFLOW and live.get('run_attempt') == 1 and live.get('status') == 'completed'
            and live.get('conclusion') == 'success' and len(live_jobs) == 2
            and {j.get('name') for j in live_jobs} == {'build', 'paired'}
            and all(j.get('conclusion') == 'success' and j.get('status') == 'completed' for j in live_jobs), 'live run invalid')
    prefix = Path(plan['artifact_prefix'])
    gh = read(Path(str(prefix) + '-github.json'))
    evidence_require(gh.get('status') == 'completed' and gh.get('conclusion') == 'success' and gh.get('headSha') == HEADS[index]
            and gh.get('databaseId') == plan['run_id'] and len(gh['jobs']) == 2
            and {j.get('name') for j in gh['jobs']} == {'build', 'paired'}
            and all(j.get('conclusion') == 'success' for j in gh['jobs']), 'control GitHub invalid')
    log = fetch_log(plan['run_id']) if log_override is None else log_override
    if log_capture is not None: log_capture.append(log.encode('utf-8'))
    validate_log(log, index)
    hashes = evidence_hashes(plan, log)
    if proof is not None: proof.update(hashes)
    binaries = Path(plan['binary_artifact_prefix'])
    observed = digest((binaries / 'baseline').read_bytes())
    candidate_hash = digest((binaries / 'candidate').read_bytes())
    evidence_require(index == 0 or candidate_hash != observed, 'candidate binary unexpectedly equals baseline')
    evidence_require((index == 0 and candidate_hash == observed == BASE_BINARY) or (index == 1 and observed == expected_baseline), 'baseline or control binary mismatch')
    for operation in ('scan', 'refresh'):
        directory = prefix / operation / 'measurements'
        raw = read(directory / 'summary.json'); checked = summarize(directory, require_runner_cleanup=True)
        evidence_require(raw == checked and checked.get('valid') is True and not checked.get('issues')
                and len(checked.get('pairs', [])) == 3, 'control strict summary invalid')
        manifest = read(directory / 'manifest.json')
        evidence_require(manifest.get('operation') == operation and manifest.get('scenario') == 'unchanged'
                and manifest.get('files') == 1000000 and manifest.get('memory_mib') == 4096
                and manifest.get('subtree_entries') == 100 and manifest.get('pairs') == 3
                and manifest.get('fixture_receipt', {}).get('expected_entries') == 1004499
                and manifest.get('github', {}).get('GITHUB_SHA') == HEADS[index]
                and str(manifest.get('github', {}).get('GITHUB_RUN_ID')) == str(plan['run_id']), 'control manifest mismatch')
        images = manifest.get('environment', {}).get('image', [])
        local_tag = f"representative-calibration:{plan['run_id']}-paired-local"
        evidence_require(isinstance(images, list) and any(local_tag in image.get('RepoTags', []) for image in images
                if isinstance(image, dict)), 'local I/O image provenance missing')
        expected = {f'p{i}-{arm}-v1' for i in (1, 2, 3) for arm in ('baseline', 'candidate')}
        evidence_require(set(manifest['expected_arms']) == expected, 'arm mismatch')
        for arm in ('baseline-v1', 'candidate-v1'):
            prov = manifest['provenance'][arm]; build = prov['build']
            revision = BASE if arm == 'baseline-v1' else HEADS[index]
            binary = observed if arm == 'baseline-v1' else candidate_hash
            evidence_require(prov['source_revision'] == revision and prov['sha256'] == binary
                    and build['source_revision'] == revision and build['sha256'] == binary
                    and build['target'] == TARGET and build['flags']['SOURCE_DATE_EPOCH'] == EPOCH, 'control provenance mismatch')
        for arm in expected:
            metric = read(directory / arm / 'metrics.json')
            events = dict(line.split() for line in metric['cgroup_after']['memory.events'].splitlines())
            evidence_require(metric.get('exit_code') == 0 and metric.get('timed_out') is False
                    and metric.get('validated') is True and metric.get('memory_mib') == 4096
                    and metric.get('timeout_seconds') == 1200 and metric.get('cpus') == 2
                    and all(events.get(k) == '0' for k in ('oom', 'oom_kill', 'oom_group_kill')), 'worker failure or OOM')
        if operation == 'refresh':
            profile = analyze(directory)
            evidence_require(profile.get('valid_structure') is True and not profile.get('issues'), 'profile invalid')
    return observed, candidate_hash, hashes


def valid_control(plan, ledger):
    require(plan.get('measurement_validation') == 'valid', 'control scientific validation incomplete')
    recorded = plan['evidence_sha256']
    log_prefix = plan['artifact_prefix'] + '-github-log-'
    log_paths = [path for path in recorded if path.startswith(log_prefix)]
    require(len(log_paths) == 1 and re.fullmatch(r'[0-9a-f]{64}\.log', log_paths[0][len(log_prefix):]),
            'control retained log path invalid')
    log_bytes = Path(log_paths[0]).read_bytes(); log_hash = digest(log_bytes)
    require(log_hash == log_paths[0][len(log_prefix):-4] == recorded[log_paths[0]]
            == recorded['github_live_log_utf8_sha256'], 'control retained log changed')
    baseline, candidate, hashes = validate_artifacts(plan, ledger, 0, log_override=log_bytes.decode('utf-8'))
    hashes[log_paths[0]] = log_hash
    sidecars = set(recorded) - set(hashes)
    require(len(sidecars) == 1, 'control evidence set mismatch')
    path = next(iter(sidecars)); prefix = plan['artifact_prefix'] + '-verification-input-dispatch-'
    require(path.startswith(prefix) and re.fullmatch(r'[0-9a-f]{64}\.json', path[len(prefix):]) is not None,
            'control receipt evidence path mismatch')
    sidecar_hash = digest(Path(path).read_bytes())
    require(sidecar_hash == path[len(prefix):-5] == recorded[path], 'control receipt evidence changed')
    require(recorded == dict(hashes, **{path: sidecar_hash}) and baseline == candidate == BASE_BINARY
            and plan.get('observed_baseline_sha256') == baseline and plan.get('observed_candidate_sha256') == candidate,
            'control evidence or recorded binary hash changed')
    return baseline


def check_historical_runs(listing, freeze, index, ledger):
    cutoff = dt.datetime.fromisoformat(freeze['launch_cutoff'].replace('Z', '+00:00'))
    require(cutoff.tzinfo is not None, 'launch cutoff must be timezone aware')
    allowlist = freeze['historical_workflow_runs']
    require(isinstance(allowlist, list), 'invalid historical allowlist')
    allowed = {}
    for row in allowlist:
        require(isinstance(row, dict) and set(row) == {'databaseId', 'headSha', 'event', 'createdAt', 'branch'}
                and type(row['databaseId']) is int and row['databaseId'] > 0 and row['event'] == 'workflow_dispatch'
                and row['branch'] in BRANCHES and row['headSha'] == HEADS[BRANCHES.index(row['branch'])], 'bad historical identity')
        when = dt.datetime.fromisoformat(row['createdAt'].replace('Z', '+00:00'))
        require(when.tzinfo is not None and when <= cutoff and row['databaseId'] not in allowed, 'bad historical cutoff or duplicate')
        allowed[row['databaseId']] = row
    known = {x.get('run_id') for x in ledger['runs']}
    for row in listing:
        require(isinstance(row, dict) and set(row) >= {'databaseId', 'headSha', 'event', 'createdAt'}
                and type(row['databaseId']) is int and row['databaseId'] > 0
                and row['event'] == 'workflow_dispatch', 'invalid workflow listing')
        when = dt.datetime.fromisoformat(row['createdAt'].replace('Z', '+00:00'))
        require(when.tzinfo is not None, 'workflow time missing timezone')
        if row['headSha'] != HEADS[index]:
            continue
        historical = allowed.get(row['databaseId'])
        if row['databaseId'] in known:
            continue
        require(historical is not None and historical == dict(row, branch=BRANCHES[index]) and when <= cutoff,
                'unknown same-head workflow dispatch; inspect before proceeding')
    # All frozen entries for this branch must still be present in the non-truncated response.
    listed = {row['databaseId'] for row in listing}
    require(all(row['databaseId'] in listed for row in allowlist if row['branch'] == BRANCHES[index]),
            'historical workflow allowlist missing from listing')


def verify_mechanism_evidence(freeze, ledger):
    require(digest(PRIOR_HELPER.read_bytes()) == freeze['prior_helper_sha256'] ==
            'a4cb5ed585988d28ed6f77c4e5931f7a2f0a97fdad1b103461f4791cc532198d', 'prior helper differs')
    require(digest(PRIOR_FREEZE.read_bytes()) == freeze['prior_freeze_sha256']
            and digest(PRIOR_MANIFEST.read_bytes()) == freeze['prior_manifest_sha256'], 'prior proof changed')
    prior_freeze, prior = read(PRIOR_FREEZE), read(PRIOR_MANIFEST)
    require(prior_freeze['helper_sha256'] == freeze['prior_helper_sha256']
            and prior['source_hash_manifest_sha256'] == freeze['prior_freeze_sha256'], 'prior source freeze mismatch')
    ids = ('cache4-mechanism-63-aa', 'cache4-mechanism-4-vs-8')
    require([p.get('id') for p in prior['plans']] == list(ids), 'prior cases differ')
    plans = prior['plans']
    for plan, ident in zip(plans, ids):
        require(plan == one(ledger['runs'], ident) and plan.get('status') == 'completed'
                and plan.get('conclusion') == 'success' and plan.get('measurement_validation') == 'valid', 'prior scientific proof unavailable')
        evidence = plan['evidence_sha256']
        require(isinstance(evidence, dict) and evidence.get('github_live_log_utf8_sha256'), 'prior recorded log digest missing')
        prefix = plan['artifact_prefix']
        receipt_key = prefix + '-dispatch.json'
        require(receipt_key in evidence and 'github_live_log_utf8_sha256' in evidence, 'prior receipt or log hash missing')
        for path, expected in evidence.items():
            if path == 'github_live_log_utf8_sha256':
                actual_path = Path(prefix + '-github.log')
            elif path == receipt_key:
                actual_path = Path(prefix + '-verification-input-dispatch.json')
            else:
                require(path.startswith('/tmp/freespace-cache4-mechanism-'), 'unexpected prior evidence path')
                actual_path = Path(path)
            require(digest(actual_path.read_bytes()) == expected, 'prior raw evidence changed: ' + path)
        import sys
        sys.path.insert(0, str(CONTROL_WT / 'scripts'))
        from bench_v1_summary import summarize
        from bench_v1_profile import analyze
        for operation in ('scan', 'refresh'):
            directory = Path(plan['artifact_prefix']) / operation / 'measurements'
            result = summarize(directory, require_runner_cleanup=True)
            require(result == read(directory / 'summary.json') and result.get('valid') is True
                    and not result.get('issues') and len(result.get('pairs', [])) == 3, 'prior strict summary mismatch')
            if operation == 'refresh':
                profile = analyze(directory)
                require(profile.get('valid_structure') is True and not profile.get('issues'), 'prior profile invalid')
    require(plans[0]['observed_baseline_sha256'] == plans[0]['observed_candidate_sha256'] == plans[1]['observed_baseline_sha256']
            and plans[1]['observed_candidate_sha256'] != plans[1]['observed_baseline_sha256'], 'prior actual binaries mismatch')

def admit(plan_id, dispatch=False):
    index = IDS.index(plan_id)
    require(not JOURNAL.exists(), 'pending bookkeeping recovery')
    manifest, ledger, freeze = read(MANIFEST), read(LEDGER), read(FREEZE)
    require(manifest.get('status') == 'registered' and manifest.get('research_only') is True
            and manifest.get('product_qualification') is False and manifest.get('candidate_revision') == CANDIDATE
            and manifest.get('source_hash_manifest_sha256') == digest(FREEZE.read_bytes()), 'manifest freeze mismatch')
    require([x.get('id') for x in manifest['plans']] == list(IDS), 'case order mismatch')
    bind_manifest(manifest, freeze)
    plan = one(manifest['plans'], plan_id)
    require(plan == one(ledger['planned_next_dispatches'], plan_id) and plan.get('status') == 'planned'
            and not any(x.get('id') == plan_id for x in ledger['runs']), 'plan not exclusively reserved')
    fixed_case(plan, index)
    require(plan.get('scan_profile') == 'disk' and plan.get('runner_preparation_policy') == 'sdk-space-v1'
            and plan.get('measurement_protocol') == 'v1-single-operation-pairs-v4', 'protocol mismatch')
    require(plan['forecast_with_margin_seconds'] == plan['forecast_seconds'] * 1.3
            and plan['forecast_with_margin_seconds'] < 3300, 'forecast invalid')
    require(ledger.get('aggregate_cap_runner_seconds') == CAP, 'budget cap invalid')
    planned = sum(x['maximum_job_seconds'] for x in ledger['planned_next_dispatches'])
    runs = sum(x['completed_job_seconds'] if x['status'] == 'completed' else x['maximum_job_seconds'] for x in ledger['runs'])
    require(planned == ledger['planned_reserved_seconds'] and runs + planned == ledger['maximum_committed_seconds']
            and 0 <= runs + planned <= CAP and ledger['remaining_unreserved_seconds'] == CAP - runs - planned, 'budget accounting invalid')
    require(not any(x.get('status') == 'dispatch_attempted' or str(x.get('dispatch_outcome', '')).startswith('unknown')
                    for x in ledger['runs'] + ledger['planned_next_dispatches']), 'unresolved dispatch')
    source_checks(freeze)
    outside_review_checks(freeze)
    verify_mechanism_evidence(freeze, ledger)
    observed = valid_control(one(manifest['plans'], IDS[0]), ledger) if index else None
    for branch, head in zip(BRANCHES, HEADS):
        ref = 'refs/heads/' + branch
        require(command(['git', 'ls-remote', 'origin', ref]).splitlines() == [head + '\t' + ref], 'remote head mismatch')
    receipt_path = RECEIPT_DIR / ('freespace-' + plan_id + '-dispatch.json')
    require(not receipt_path.exists(), 'attempt already exists; inspect, no retry')
    inputs = {'stage': 'screen', 'operation': 'auto', 'target': TARGET, 'subtree_entries': '100',
              'scenario': 'unchanged', 'memory_mib': '4096', 'io': 'local', 'comparison': 'candidate',
              'baseline': BASE, 'timeout_minutes': '55', 'forecast_seconds': '0', 'forecast_case_id': ''}
    receipt = {'plan_id': plan_id, 'expected_head_sha': HEADS[index], 'expected_baseline_binary_sha256': observed,
               'source_epoch': EPOCH, 'inputs': inputs, 'research_only': True,
               'dispatch_attempted_at': dt.datetime.now(dt.timezone.utc).isoformat(), 'dispatched': False}
    if not dispatch:
        return {'mode': 'dry-run', **receipt}
    with receipt_path.open('x') as out:
        out.write(encoded(receipt).decode()); out.flush(); os.fsync(out.fileno())
    sync_dir(receipt_path.parent)
    try:
        repo = gh_json(['repo', 'view', '--json', 'nameWithOwner'])['nameWithOwner']
        require(isinstance(repo, str), 'repository invalid')
        check_historical_runs(listing_for(index), freeze, index, ledger)
    except Exception as error:
        receipt.update(dispatched=False, dispatch_outcome='not_dispatched', error=str(error))
        atomic_write(receipt_path, encoded(receipt))
        return receipt
    args = ['gh', 'workflow', 'run', 'representative-bench.yml', '--ref', BRANCHES[index]]
    for key, value in inputs.items(): args += ['-f', key + '=' + value]
    receipt.update(dispatched=None, dispatch_outcome='unknown; inspect, do not retry',
                   dispatch_attempted_at=dt.datetime.now(dt.timezone.utc).isoformat())
    atomic_write(receipt_path, encoded(receipt))
    try:
        result = subprocess.run(args, cwd=ROOT, text=True, capture_output=True, timeout=60)
        receipt.update(dispatched=True if result.returncode == 0 else None, dispatch_exit_code=result.returncode,
                       stdout=result.stdout, stderr=result.stderr)
        if result.returncode == 0: receipt['dispatch_outcome'] = 'submitted'
    except Exception as error:
        receipt.update(error=str(error))
    atomic_write(receipt_path, encoded(receipt))
    return receipt




def retain_bytes(prefix, label, extension, data):
    value = digest(data)
    path = Path(prefix + '-' + label + '-' + value + extension)
    try:
        fd = os.open(path, os.O_WRONLY | os.O_CREAT | os.O_EXCL | os.O_NOFOLLOW, 0o600)
    except FileExistsError:
        require(not path.is_symlink() and path.read_bytes() == data, 'sidecar conflict')
    else:
        with os.fdopen(fd, 'wb') as out:
            out.write(data); out.flush(); os.fsync(out.fileno())
        sync_dir(path.parent)
    return path, value

def validate_result(plan_id):
    require(not JOURNAL.exists(), 'pending journal')
    index = IDS.index(plan_id)
    receipt_path = RECEIPT_DIR / ('freespace-' + plan_id + '-dispatch.json')
    captured = {path: path.read_bytes() for path in (LEDGER, MANIFEST, receipt_path)}
    ledger, manifest, freeze = json.loads(captured[LEDGER]), json.loads(captured[MANIFEST]), read(FREEZE)
    require(manifest.get('source_hash_manifest_sha256') == digest(FREEZE.read_bytes()), 'freeze mismatch')
    bind_manifest(manifest, freeze); source_checks(freeze); outside_review_checks(freeze)
    verify_mechanism_evidence(freeze, ledger)
    plan = one(ledger['runs'], plan_id); other = one(manifest['plans'], plan_id)
    require(plan == other and plan.get('status') == 'completed', 'result must be completed')
    if plan.get('measurement_validation') in ('valid', 'invalid'):
        return {'plan_id':plan_id, 'measurement_validation':plan['measurement_validation']}
    require(plan.get('measurement_validation') == 'unverified', 'result must be unverified')
    receipt = json.loads(captured[receipt_path])
    expected = valid_control(one(manifest['plans'], IDS[0]), ledger) if index else None
    receipt_bytes = captured[receipt_path]
    proof = {}
    logs = []
    try:
        if index: evidence_require(receipt.get('expected_baseline_binary_sha256') == expected, 'receipt baseline mismatch')
        baseline, candidate, hashes = validate_artifacts(plan, ledger, index, expected, proof, log_capture=logs)
        plan.update(measurement_validation='valid', observed_baseline_sha256=baseline, observed_candidate_sha256=candidate, evidence_sha256=proof)
    except EvidenceMismatch as error:
        plan.update(measurement_validation='invalid', measurement_validation_error=str(error), evidence_sha256=proof)
    # Preserve exact evidence preimages only after all readiness and evidence reads finish.
    sidecar, receipt_hash = retain_bytes(plan['artifact_prefix'], 'verification-input-dispatch', '.json', receipt_bytes)
    proof[str(sidecar)] = receipt_hash
    if logs:
        require(len(logs) == 1, 'unexpected log count')
        log_sidecar, log_hash = retain_bytes(plan['artifact_prefix'], 'github-log', '.log', logs[0])
        require(proof.get('github_live_log_utf8_sha256', log_hash) == log_hash, 'log evidence mismatch')
        proof['github_live_log_utf8_sha256'] = log_hash
        proof[str(log_sidecar)] = log_hash
    plan['evidence_sha256'] = proof
    other.update(plan); receipt['measurement_validation'] = plan['measurement_validation']
    ledger['updated_at'] = manifest['updated_at'] = dt.datetime.now(dt.timezone.utc).isoformat()
    states = [(LEDGER, ledger), (MANIFEST, manifest), (receipt_path, receipt)]
    entries = []
    for path, state in states:
        old, new = captured[path], encoded(state)
        require(path.read_bytes() == old, 'concurrent modification before journal: ' + str(path))
        entries.append({'path':str(path), 'old_sha256':digest(old), 'new_sha256':digest(new), 'new':new.decode()})
    require(all(path.read_bytes() == captured[path] for path, _ in states), 'concurrent modification before journal')
    atomic_write(JOURNAL, encoded({'version':1, 'plan_id':plan_id, 'entries':entries})); recover()
    return {'plan_id':plan_id, 'measurement_validation':plan['measurement_validation']}

def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument('mode', nargs='?', default='dry', choices=('dry', 'dispatch', 'register', 'refresh', 'validate', 'recover'))
    parser.add_argument('--dispatch', action='store_true')
    parser.add_argument('plan_id', nargs='?', choices=IDS)
    parser.add_argument('run_id', nargs='?', type=int)
    args = parser.parse_args()
    if args.dispatch:
        require(args.mode == 'dry', '--dispatch only applies to dry admission')
        args.mode = 'dispatch'
    with ExitStack() as locks:
        for path in (GLOBAL_LOCK, COMPAT_LOCK, LOCK):
            lock = locks.enter_context(path.open('a+'))
            fcntl.flock(lock, fcntl.LOCK_EX | fcntl.LOCK_NB)
        if args.mode == 'recover':
            require(args.plan_id is None and args.run_id is None, 'recover takes no case')
            print(json.dumps({'recovered': recover()})); return
        require(not JOURNAL.exists(), 'pending journal; use recover explicitly')
        require(args.plan_id is not None, 'case required')
        if args.mode == 'validate':
            require(args.run_id is None, 'run id not allowed')
            print(json.dumps(validate_result(args.plan_id))); return
        if args.mode in ('dry', 'dispatch'):
            require(args.run_id is None, 'run id not allowed')
            print(json.dumps(admit(args.plan_id, args.mode == 'dispatch'), indent=2)); return
        require(args.run_id is not None and args.run_id > 0, 'run id required')
        run, jobs = fetch_run(args.run_id)
        print(json.dumps(update(args.mode, args.plan_id, args.run_id, run, jobs)))


if __name__ == '__main__':
    main()
