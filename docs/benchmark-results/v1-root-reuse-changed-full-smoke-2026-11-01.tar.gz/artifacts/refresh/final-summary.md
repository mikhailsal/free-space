# v1-single-operation-pairs-v4

Case: {"case_policy": "qualification-v1", "memory_mib": 1024, "mutation_receipt": {"added_inode": 525544, "added_mtime": 1700000060000000000, "added_nested_entries": 3, "added_size": 5, "changed_mtime": 1700000060000000000, "changed_size": 8192, "deleted_inode": 425225, "entry_delta": 0, "file_delta": 0, "nested_deleted_inode": 435221, "new_file_inode": 525549, "new_file_mtime": 1700000060000000000, "new_file_size": 11, "new_link_inode": 435222, "new_link_mtime": 1700000000000000000, "new_link_size": 13, "old_outside_inode": 435220, "old_outside_mtime": 1700000000000000000, "old_outside_size": 9, "old_owner_inode": 435220, "outside_owner_inode": 435222, "recipe": "full-balanced-v1", "removed_nested_entries": 3, "renamed_inode": 425223, "replacement_inode": 525547, "replacement_mtime": 1700000060000000000, "subtree_entries_after": 10000, "subtree_entries_before": 10000, "target_mtime": 1700000060000000000}, "observer_memory_mib": 4096, "scenario": "changed-full", "setup_memory_mib": 4096, "subtree_entries": 10000}


Descriptive paired results; no automatic promotion or uncertainty estimate.
Application disk peak is sampled; RSS excludes the observer.

| Pair | Elapsed baseline → candidate (s) | RSS baseline → candidate (MiB) | App disk baseline → candidate (GiB) |
|---:|---:|---:|---:|
| 1 | 1.383 → 1.385 (Δ +0.002) | 72.914 → 60.887 (Δ -12.027) | 0.034 → 0.034 (Δ +0.000) |

VALID
