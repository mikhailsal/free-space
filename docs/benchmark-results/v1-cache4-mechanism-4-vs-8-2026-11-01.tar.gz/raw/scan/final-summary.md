# v1-single-operation-pairs-v4

Case: {"case_policy": "qualification-v1", "memory_mib": 4096, "mutation_receipt": null, "observer_memory_mib": 4096, "scenario": "unchanged", "setup_memory_mib": 4096, "subtree_entries": 100}


Descriptive paired results; no automatic promotion or uncertainty estimate.
Application disk peak is sampled; RSS excludes the observer.

| Pair | Elapsed baseline → candidate (s) | RSS baseline → candidate (MiB) | App disk baseline → candidate (GiB) |
|---:|---:|---:|---:|
| 1 | 44.079 → 45.431 (Δ +1.352) | 36.480 → 24.543 (Δ -11.938) | 0.424 → 0.424 (Δ +0.000) |
| 2 | 44.430 → 45.060 (Δ +0.630) | 36.742 → 24.656 (Δ -12.086) | 0.424 → 0.424 (Δ +0.000) |
| 3 | 44.899 → 45.286 (Δ +0.387) | 36.699 → 24.520 (Δ -12.180) | 0.424 → 0.424 (Δ +0.000) |

VALID
