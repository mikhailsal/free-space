# v1-single-operation-pairs-v4

Case: {"case_policy": "qualification-v1", "memory_mib": 4096, "mutation_receipt": null, "observer_memory_mib": 4096, "scenario": "unchanged", "setup_memory_mib": 4096, "subtree_entries": 100}


Descriptive paired results; no automatic promotion or uncertainty estimate.
Application disk peak is sampled; RSS excludes the observer.

| Pair | Elapsed baseline → candidate (s) | RSS baseline → candidate (MiB) | App disk baseline → candidate (GiB) |
|---:|---:|---:|---:|
| 1 | 10.681 → 10.685 (Δ +0.004) | 280.191 → 280.078 (Δ -0.113) | 0.350 → 0.350 (Δ +0.000) |
| 2 | 10.683 → 10.685 (Δ +0.001) | 280.223 → 280.289 (Δ +0.066) | 0.350 → 0.350 (Δ -0.000) |
| 3 | 10.581 → 10.637 (Δ +0.056) | 280.227 → 280.293 (Δ +0.066) | 0.350 → 0.350 (Δ +0.000) |

VALID
