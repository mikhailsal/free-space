# v1-single-operation-pairs-v4

Case: {"case_policy": "qualification-v1", "memory_mib": 4096, "mutation_receipt": null, "observer_memory_mib": 4096, "scenario": "unchanged", "setup_memory_mib": 4096, "subtree_entries": 100}


Descriptive paired results; no automatic promotion or uncertainty estimate.
Application disk peak is sampled; RSS excludes the observer.

| Pair | Elapsed baseline → candidate (s) | RSS baseline → candidate (MiB) | App disk baseline → candidate (GiB) |
|---:|---:|---:|---:|
| 1 | 66.789 → 66.818 (Δ +0.029) | 36.750 → 36.961 (Δ +0.211) | 0.428 → 0.428 (Δ +0.000) |
| 2 | 67.126 → 67.034 (Δ -0.092) | 36.961 → 36.848 (Δ -0.113) | 0.428 → 0.428 (Δ +0.000) |
| 3 | 66.670 → 66.964 (Δ +0.294) | 36.961 → 37.051 (Δ +0.090) | 0.428 → 0.428 (Δ +0.000) |

Identical binaries: observed maximum absolute paired differences (descriptive band):
- elapsed_seconds: median Δ +0.029; max |Δ| 0.294
- peak_rss_kib: median Δ +92.000; max |Δ| 216.000
- app_disk_peak_bytes: median Δ +0.000; max |Δ| 0.000

VALID
