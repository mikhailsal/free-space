# v1-single-operation-pairs-v3

Descriptive paired results; no automatic promotion or uncertainty estimate.
Application disk peak is sampled; RSS excludes the observer.

| Pair | Elapsed baseline → candidate (s) | RSS baseline → candidate (MiB) | App disk baseline → candidate (GiB) |
|---:|---:|---:|---:|
| 1 | 74.630 → 74.379 (Δ -0.251) | 1764.711 → 1764.645 (Δ -0.066) | 2.555 → 2.555 (Δ -0.000) |

Identical binaries: observed maximum absolute paired differences (descriptive band):
- elapsed_seconds: median Δ -0.251; max |Δ| 0.251
- peak_rss_kib: median Δ -68.000; max |Δ| 68.000
- app_disk_peak_bytes: median Δ -4096.000; max |Δ| 4096.000

VALID
