# Small unchanged refresh overhead audit

The candidate's paired whole-command refresh differences were +8.913, +25.007 and +37.347 ms. Fresh A/A maximum absolute spread was 35.233 ms and 0.331818%; the worst candidate pair was +0.349425%, exceeding both bands. All three candidate deltas are positive. H2 remains inconclusive; no root cause is established from these three pairs.

The table shows candidate minus baseline **CLI report** durations in milliseconds. Residual is total minus the sum of the listed phases; it includes uninstrumented work and must not be called sync time. Whole-command wall timing is separate from CLI total.

| Pair | Load | Walk | Load + walk | Graft/finalize | Insert | Index | Publish | Residual | CLI total |
| --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- |
| 1 | -82.430 | +91.780 | +9.350 | -7.692 | -29.134 | +36.298 | -0.653 | +1.591 | +9.761 |
| 2 | -62.415 | +94.064 | +31.649 | -9.357 | +16.788 | -7.159 | -0.359 | -3.157 | +28.405 |
| 3 | -81.782 | +93.886 | +12.104 | -9.306 | +28.729 | +10.422 | -0.324 | -6.593 | +35.031 |

Walk is +91.780 to +94.064 ms, but load is −62.415 to −82.430 ms; their combined net is +9.350, +31.649 and +12.104 ms. Insert and index vary in both directions and materially affect each pair. Profile elapsed start-to-loaded is not a comparable load-only interval: candidate moved walk ahead of the marker, while baseline's marker precedes walk. The CLI's combined load plus walk is the appropriate coarse comparison, but it does not isolate individual causes. Allocation-profile HWM monotonicity failed; that does not by itself invalidate monotonic elapsed timestamps and no memory allocation conclusion is drawn from it.

Source confirms a plausible extra operation: candidate [prepare_refresh](/tmp/free-space-v1-memory-candidate-default-cache/core/src/refresh/load.rs:24) calls `roots(snap)` before walking, then [load_tree_with_extra](/tmp/free-space-v1-memory-candidate-default-cache/core/src/refresh/load.rs:72) calls `load_roots` again. The [roots query](/tmp/free-space-v1-memory-candidate-default-cache/core/src/refresh/load.rs:255) thus executes twice versus once in baseline E826. Candidate includes the first query in `load_seconds`, but emits no separate root-query duration. It could contribute; there is no evidence that it costs tens of milliseconds. Candidate also walks before loading, changing cache/order and the set of live data; the large walk difference and compensating load difference are consistent with an order effect, but neither proves its cause or net overhead.

[Refresh timing](/tmp/free-space-v1-memory-candidate-default-cache/core/src/refresh.rs:244) groups graft, filesystem-stat update and finalization. [Writer timing](/tmp/free-space-v1-memory-candidate-default-cache/core/src/snapshot/writer.rs:151) separately measures insertion and index/commit/ANALYZE; close, snapshot fsync and other work are outside those intervals. There is no individual sync or merge timer, so the residual cannot attribute either. A/A load-plus-walk differences were −4.280, −5.501 and +1.150 ms; A/A insert/index variation also shows why one interval is not a causal proof.

The smallest discriminating prospective diagnostic is to add monotonic point timings for the first root read, subtree walk, full-tree load including its second root read, graft/finalize, snapshot sync and remaining writer work, with identical marker overhead on both arms and the same frozen fixture, order, semantic checks and matched A/A. Record each query count and distinguish the two root reads. A targeted measurement of the repeated root query can test that hypothesis, but removal or reuse must retain root metadata and current semantics; no fix is established here.

The separate scan worker-cgroup paired differences were [-4571136, -4567040, -4349952] bytes (median -4,567,040 bytes, about −4.355 MiB / -0.235% of the paired baseline); all three were smaller. This is a small screen-only observation, not a minimum-budget or full-scale claim. Raw reports and both sets of exact numeric deltas are in the accompanying JSON.
