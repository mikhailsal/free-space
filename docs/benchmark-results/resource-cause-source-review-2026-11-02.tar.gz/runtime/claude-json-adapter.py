#!/usr/bin/env python3
"""Invocation-local compatibility adapter; preserve Claude result and exit code."""
import json
import subprocess
import sys

def normalize(raw):
    value = json.loads(raw)
    if isinstance(value, list):
        results = [item for item in value if isinstance(item, dict) and item.get('type') == 'result']
        if not results:
            raise ValueError('Claude event array contains no final result')
        value = results[-1]
    if not isinstance(value, dict):
        raise ValueError('Expected Claude result object or event array')
    return json.dumps(value)

if __name__ == '__main__':
    result = subprocess.run(['/home/tass/.local/bin/claude', *sys.argv[1:]], input=sys.stdin.buffer.read(), capture_output=True)
    sys.stderr.buffer.write(result.stderr)
    try:
        print(normalize(result.stdout))
    except (ValueError, UnicodeError) as error:
        sys.stderr.write('Claude response normalization failed: '+str(error)+'\n')
        sys.stdout.buffer.write(result.stdout)
        sys.exit(result.returncode or 1)
    sys.exit(result.returncode)
