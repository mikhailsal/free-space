# v1-single-operation-pairs-v4

Case: {"case_policy": "qualification-v1", "memory_mib": 4096, "mutation_receipt": null, "observer_memory_mib": 4096, "scenario": "unchanged", "setup_memory_mib": 4096, "subtree_entries": 100}


Descriptive paired results; no automatic promotion or uncertainty estimate.
Application disk peak is sampled; RSS excludes the observer.

| Pair | Elapsed baseline → candidate (s) | RSS baseline → candidate (MiB) | App disk baseline → candidate (GiB) |
|---:|---:|---:|---:|
| 1 | 10.189 → 10.190 (Δ +0.001) | 368.035 → 279.930 (Δ -88.105) | 0.349 → 0.349 (Δ +0.000) |
| 2 | 10.196 → 10.402 (Δ +0.206) | 368.043 → 279.895 (Δ -88.148) | 0.349 → 0.349 (Δ +0.000) |
| 3 | 10.190 → 10.158 (Δ -0.033) | 368.082 → 279.801 (Δ -88.281) | 0.349 → 0.349 (Δ +0.000) |

VALID
