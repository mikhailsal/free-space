# v1-single-operation-pairs-v4

Case: {"case_policy": "qualification-v1", "memory_mib": 4096, "mutation_receipt": null, "observer_memory_mib": 4096, "scenario": "unchanged", "setup_memory_mib": 4096, "subtree_entries": 100}


Descriptive paired results; no automatic promotion or uncertainty estimate.
Application disk peak is sampled; RSS excludes the observer.

| Pair | Elapsed baseline → candidate (s) | RSS baseline → candidate (MiB) | App disk baseline → candidate (GiB) |
|---:|---:|---:|---:|
| 1 | 52.645 → 44.228 (Δ -8.418) | 35.016 → 24.961 (Δ -10.055) | 0.428 → 0.424 (Δ -0.004) |
| 2 | 53.095 → 44.303 (Δ -8.792) | 34.980 → 24.738 (Δ -10.242) | 0.428 → 0.424 (Δ -0.004) |
| 3 | 52.866 → 45.001 (Δ -7.865) | 35.051 → 24.695 (Δ -10.355) | 0.428 → 0.424 (Δ -0.004) |

VALID
