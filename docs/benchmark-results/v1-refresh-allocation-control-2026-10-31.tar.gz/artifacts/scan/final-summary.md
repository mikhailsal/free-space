# v1-single-operation-pairs-v3

Descriptive paired results; no automatic promotion or uncertainty estimate.
Application disk peak is sampled; RSS excludes the observer.

| Pair | Elapsed baseline → candidate (s) | RSS baseline → candidate (MiB) | App disk baseline → candidate (GiB) |
|---:|---:|---:|---:|
| 1 | 52.861 → 53.079 (Δ +0.217) | 27.195 → 27.023 (Δ -0.172) | 0.428 → 0.428 (Δ +0.000) |
| 2 | 53.363 → 53.029 (Δ -0.334) | 27.133 → 27.055 (Δ -0.078) | 0.428 → 0.428 (Δ +0.000) |
| 3 | 53.597 → 53.593 (Δ -0.004) | 27.262 → 27.156 (Δ -0.105) | 0.428 → 0.428 (Δ +0.000) |

Identical binaries: observed maximum absolute paired differences (descriptive band):
- elapsed_seconds: median Δ -0.004; max |Δ| 0.334
- peak_rss_kib: median Δ -108.000; max |Δ| 176.000
- app_disk_peak_bytes: median Δ +0.000; max |Δ| 0.000

VALID
