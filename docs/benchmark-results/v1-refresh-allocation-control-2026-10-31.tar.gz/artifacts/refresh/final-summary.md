# v1-single-operation-pairs-v3

Descriptive paired results; no automatic promotion or uncertainty estimate.
Application disk peak is sampled; RSS excludes the observer.

| Pair | Elapsed baseline → candidate (s) | RSS baseline → candidate (MiB) | App disk baseline → candidate (GiB) |
|---:|---:|---:|---:|
| 1 | 9.464 → 9.595 (Δ +0.131) | 244.941 → 244.852 (Δ -0.090) | 0.350 → 0.350 (Δ +0.000) |
| 2 | 9.381 → 9.409 (Δ +0.027) | 244.914 → 244.730 (Δ -0.184) | 0.350 → 0.350 (Δ +0.000) |
| 3 | 9.364 → 9.387 (Δ +0.024) | 244.887 → 244.812 (Δ -0.074) | 0.350 → 0.350 (Δ +0.000) |

Identical binaries: observed maximum absolute paired differences (descriptive band):
- elapsed_seconds: median Δ +0.027; max |Δ| 0.131
- peak_rss_kib: median Δ -92.000; max |Δ| 188.000
- app_disk_peak_bytes: median Δ +0.000; max |Δ| 0.000

VALID
