import json, math, re, sys
from pathlib import Path

COMMON = ['refresh_start','refresh_loaded','refresh_before_graft','refresh_after_graft','refresh_after_finalize']
FULL = ['refresh_start','refresh_loaded','refresh_before_graft','refresh_after_names','refresh_after_nodes','refresh_after_graft','refresh_after_finalize']
SCALARS = ['node_len','node_capacity','name_len','name_capacity','node_size_bytes']
FLAGS = ['node_buffer_changed','name_buffer_changed']

def integer(v):
    return type(v) is int and 0 <= v < 2**64

def number(v):
    return type(v) in (int,float) and math.isfinite(v) and v >= 0

def analyze(folder):
    root=Path(folder)/'refresh'/'measurements'
    manifest=json.loads((root/'manifest.json').read_text())
    ordinary=json.loads((root/'summary.json').read_text())
    issues=[];arms=[]
    if ordinary.get('valid') is not True: issues.append('ordinary paired receipts invalid')
    if manifest.get('pairs') != 3 or manifest.get('files') != 1000000: issues.append('unexpected initial diagnostic workload')
    if manifest.get('diagnostic_policy',{}).get('allocation_diagnostics') is not True:issues.append('missing explicit diagnostic policy')
    ids=manifest.get('expected_arms',[])
    if len(ids)!=6:issues.append('initial diagnostic requires6measuredarms')
    for ident in ids:
        local=[]
        if not re.fullmatch(r'p[1-3]-(baseline|candidate)-v1',ident):issues.append('unsafe or unexpected arm id');continue
        path=root/ident
        try:
            spec=json.loads((path/'spec.json').read_text());metric=json.loads((path/'metrics.json').read_text())
            if spec.get('allocation_diagnostics') is not True:local.append('refresh trace flag missing')
            trace=path/'allocation-profile.jsonl'
            if not trace.is_file() or trace.stat().st_size>128*1024:raise ValueError('trace missing or unexpectedly large')
            events=[json.loads(line) for line in trace.read_text().splitlines() if line.strip()]
            report=metric['report'];required=COMMON if report.get('removed') is True else FULL
            positions={}
            elapsed=-1;hwm=-1
            for i,event in enumerate(events):
                phase=event.get('phase')
                if not isinstance(phase,str) or not number(event.get('elapsed_seconds')):raise ValueError('invalid phase/elapsed field')
                if not integer(event.get('rss_kib')) or not integer(event.get('hwm_kib')):raise ValueError('invalid RSS/HWM')
                if event['elapsed_seconds']<elapsed or event['hwm_kib']<hwm:raise ValueError('nonmonotonic elapsed/HWM')
                elapsed,hwm=event['elapsed_seconds'],event['hwm_kib']
                if phase in required:
                    if phase in positions:raise ValueError('duplicate required event')
                    positions[phase]=i
                if phase.startswith('refresh_') and phase!='refresh_start':
                    if phase not in FULL:raise ValueError('unrecognized allocation boundary')
                    if any(not integer(event.get(k)) for k in SCALARS) or any(type(event.get(k)) is not bool for k in FLAGS):raise ValueError('invalid allocation scalar fields')
                    if event['node_capacity']<event['node_len'] or event['name_capacity']<event['name_len'] or not event['node_size_bytes']:raise ValueError('invalid vector capacities')
            if any(x not in positions for x in required):raise ValueError('missing required boundary')
            if [positions[x] for x in required] != sorted(positions[x] for x in required):raise ValueError('invalid boundary order')
            by={e['phase']:e for e in events if e['phase'] in required}
            loaded=by['refresh_loaded'];before=by['refresh_before_graft'];after=by.get('refresh_after_nodes',by['refresh_after_graft'])
            if loaded['node_len']!=spec['expected_entries'] or before['node_len']!=loaded['node_len']:local.append('unexpected loaded/before-graft node count')
            if loaded['node_buffer_changed'] or loaded['name_buffer_changed']:local.append('first allocation event must mean no prior buffer')
            expected=loaded['node_len']+max(0,report.get('subtree_entries',0)-1)
            if report.get('removed') is not True and after['node_len']!=expected:local.append('unexpected post-append node count')
            arms.append({'id':ident,'events':events,'required_boundaries':by,'final_process_peak_rss_kib':metric['time']['peak_rss_kib'],'elapsed_seconds':metric['elapsed_seconds'],'node_capacity_before':before['node_capacity'],'node_capacity_after':after['node_capacity'],'node_buffer_moved_at_append':after['node_buffer_changed'],'node_append_hwm_delta_kib':after['hwm_kib']-by.get('refresh_after_names',before)['hwm_kib'],'name_append_hwm_delta_kib':by.get('refresh_after_names',before)['hwm_kib']-before['hwm_kib'],'post_finalize_hwm_kib':by['refresh_after_finalize']['hwm_kib'],'local_issues':local})
        except (OSError,ValueError,KeyError,TypeError) as exc:local.append(str(exc))
        issues.extend(ident+': '+x for x in local)
    return {'valid_diagnostic':not issues and len(arms)==6,'issues':issues,'run':manifest.get('github'),'arms':arms,'interpretation':'Boundary RSS samples and cumulative HWM; buffer movement alone does not prove copying. No automatic optimization acceptance.'}

if __name__=='__main__':
    result=analyze(sys.argv[1]);Path(sys.argv[2]).write_text(json.dumps(result,indent=2)+'\n')
    print('valid_diagnostic',result['valid_diagnostic'],'issues',result['issues'])
    for a in result['arms']:
        print(a['id'],'nodescap',a['node_capacity_before'],'->',a['node_capacity_after'],'moved',a['node_buffer_moved_at_append'],'nodeHWMdeltaMiB',round(a['node_append_hwm_delta_kib']/1024,3),'namesHWMdeltaMiB',round(a['name_append_hwm_delta_kib']/1024,3),'finalizeHWMMiB',round(a['post_finalize_hwm_kib']/1024,3),'processPeakMiB',round(a['final_process_peak_rss_kib']/1024,3))
    raise SystemExit(0 if result['valid_diagnostic'] else 1)
