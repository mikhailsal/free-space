# v1-single-operation-pairs-v3

Descriptive paired results; no automatic promotion or uncertainty estimate.
Application disk peak is sampled; RSS excludes the observer.

| Pair | Elapsed baseline → candidate (s) | RSS baseline → candidate (MiB) | App disk baseline → candidate (GiB) |
|---:|---:|---:|---:|
| 1 | 10.271 → 10.285 (Δ +0.014) | 246.035 → 245.773 (Δ -0.262) | 0.350 → 0.350 (Δ +0.000) |
| 2 | 10.282 → 10.301 (Δ +0.019) | 246.051 → 245.781 (Δ -0.270) | 0.350 → 0.350 (Δ +0.000) |
| 3 | 10.286 → 10.300 (Δ +0.014) | 245.824 → 245.859 (Δ +0.035) | 0.350 → 0.350 (Δ +0.000) |

VALID
