# v1-single-operation-pairs-v3

Descriptive paired results; no automatic promotion or uncertainty estimate.
Application disk peak is sampled; RSS excludes the observer.

| Pair | Elapsed baseline → candidate (s) | RSS baseline → candidate (MiB) | App disk baseline → candidate (GiB) |
|---:|---:|---:|---:|
| 1 | 54.876 → 50.644 (Δ -4.231) | 26.852 → 27.094 (Δ +0.242) | 0.428 → 0.428 (Δ +0.000) |
| 2 | 54.786 → 50.580 (Δ -4.207) | 26.832 → 26.867 (Δ +0.035) | 0.428 → 0.428 (Δ +0.000) |
| 3 | 54.680 → 50.451 (Δ -4.229) | 26.629 → 26.992 (Δ +0.363) | 0.428 → 0.428 (Δ +0.000) |

VALID
