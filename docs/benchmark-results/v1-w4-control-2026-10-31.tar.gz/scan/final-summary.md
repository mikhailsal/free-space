# v1-single-operation-pairs-v3

Descriptive paired results; no automatic promotion or uncertainty estimate.
Application disk peak is sampled; RSS excludes the observer.

| Pair | Elapsed baseline → candidate (s) | RSS baseline → candidate (MiB) | App disk baseline → candidate (GiB) |
|---:|---:|---:|---:|
| 1 | 61.319 → 61.593 (Δ +0.274) | 26.879 → 26.695 (Δ -0.184) | 0.428 → 0.428 (Δ +0.000) |
| 2 | 62.346 → 61.639 (Δ -0.706) | 26.793 → 26.965 (Δ +0.172) | 0.428 → 0.428 (Δ +0.000) |
| 3 | 62.284 → 62.478 (Δ +0.194) | 26.789 → 26.684 (Δ -0.105) | 0.428 → 0.428 (Δ +0.000) |

Identical binaries: observed maximum absolute paired differences (descriptive band):
- elapsed_seconds: median Δ +0.194; max |Δ| 0.706
- peak_rss_kib: median Δ -108.000; max |Δ| 188.000
- app_disk_peak_bytes: median Δ +0.000; max |Δ| 0.000

VALID
