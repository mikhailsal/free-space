# v1-single-operation-pairs-v3

Descriptive paired results; no automatic promotion or uncertainty estimate.
Application disk peak is sampled; RSS excludes the observer.

| Pair | Elapsed baseline → candidate (s) | RSS baseline → candidate (MiB) | App disk baseline → candidate (GiB) |
|---:|---:|---:|---:|
| 1 | 10.660 → 10.742 (Δ +0.083) | 245.254 → 245.453 (Δ +0.199) | 0.349 → 0.349 (Δ +0.000) |
| 2 | 10.850 → 10.782 (Δ -0.069) | 245.324 → 245.246 (Δ -0.078) | 0.349 → 0.349 (Δ +0.000) |
| 3 | 10.742 → 10.741 (Δ -0.001) | 245.281 → 245.324 (Δ +0.043) | 0.349 → 0.349 (Δ +0.000) |

Identical binaries: observed maximum absolute paired differences (descriptive band):
- elapsed_seconds: median Δ -0.001; max |Δ| 0.083
- peak_rss_kib: median Δ +44.000; max |Δ| 204.000
- app_disk_peak_bytes: median Δ +0.000; max |Δ| 0.000

VALID
