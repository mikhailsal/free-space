# v1-single-operation-pairs-v4

Case: {"case_policy": "qualification-v1", "memory_mib": 4096, "mutation_receipt": null, "observer_memory_mib": 4096, "scenario": "unchanged", "setup_memory_mib": 4096, "subtree_entries": 100}


Descriptive paired results; no automatic promotion or uncertainty estimate.
Application disk peak is sampled; RSS excludes the observer.

| Pair | Elapsed baseline → candidate (s) | RSS baseline → candidate (MiB) | App disk baseline → candidate (GiB) |
|---:|---:|---:|---:|
| 1 | 10.636 → 10.598 (Δ -0.038) | 369.047 → 281.055 (Δ -87.992) | 0.349 → 0.349 (Δ +0.000) |
| 2 | 10.650 → 10.632 (Δ -0.018) | 369.137 → 281.066 (Δ -88.070) | 0.349 → 0.349 (Δ +0.000) |
| 3 | 10.707 → 10.564 (Δ -0.143) | 369.086 → 281.051 (Δ -88.035) | 0.349 → 0.349 (Δ +0.000) |

VALID
