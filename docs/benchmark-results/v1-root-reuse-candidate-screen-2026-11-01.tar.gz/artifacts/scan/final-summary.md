# v1-single-operation-pairs-v4

Case: {"case_policy": "qualification-v1", "memory_mib": 4096, "mutation_receipt": null, "observer_memory_mib": 4096, "scenario": "unchanged", "setup_memory_mib": 4096, "subtree_entries": 100}


Descriptive paired results; no automatic promotion or uncertainty estimate.
Application disk peak is sampled; RSS excludes the observer.

| Pair | Elapsed baseline → candidate (s) | RSS baseline → candidate (MiB) | App disk baseline → candidate (GiB) |
|---:|---:|---:|---:|
| 1 | 69.539 → 46.768 (Δ -22.770) | 34.934 → 36.543 (Δ +1.609) | 0.428 → 0.424 (Δ -0.004) |
| 2 | 69.390 → 47.045 (Δ -22.345) | 34.953 → 36.484 (Δ +1.531) | 0.428 → 0.424 (Δ -0.004) |
| 3 | 69.225 → 47.024 (Δ -22.200) | 34.988 → 36.719 (Δ +1.730) | 0.428 → 0.424 (Δ -0.004) |

VALID
