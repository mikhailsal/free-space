"""One-shot root-reuse admission. Dry by default; never retries or registers a run."""
import argparse, datetime as dt, fcntl, hashlib, importlib.util, json, os, pathlib, re, subprocess, sys
P=pathlib.Path; ROOT=P('/home/tass/myprojects/corp_v2/free-space'); OUT=ROOT/'docs/benchmark-results'; TMP=P('/tmp')
MANIFEST=OUT/'v1-refresh-root-reuse-manifest-2026-11-01.json'; LEDGER=OUT/'v1-w1-campaign-2026-10-31.json'; AA_MANIFEST=OUT/'v1-compact-stage-https-manifest-2026-11-01.json'; FREEZE=TMP/'freespace-root-reuse-all-source-hashes.json'
BASE='e8265778ef78ec4acd9da1375eedb0be37a123f5'; HEAD='63d98cc8ff88a54ab9687c5fb93fffd930e33d26'; CONTROL='4f22bf8e3b67f7f59049a72116b90c061fb1328b'; REF='471c4d14ed4881106ce1d0b6cd5d6361839b2bc8'; BASE_BIN='ed2a1cb138b1e48e70a388a4a8fda3e79fcfd2e37fd0c061d41d2d6363f8e980'; BRANCH='perf/v1-refresh-root-reuse'; ORDER=['root-reuse-changed-full-smoke','root-reuse-candidate-screen']; TREES={'candidate':TMP/'free-space-v1-refresh-root-reuse','control':TMP/'free-space-v1-memory-candidate-control','reference_471':TMP/'free-space-v1-memory-candidate-default-cache'}
def read(p): return json.loads(p.read_text())
def require(ok,msg):
 if not ok: raise ValueError(msg)
def one(rows,ident):
 found=[x for x in rows if x.get('id')==ident];require(len(found)==1,'expected one record: '+ident);return found[0]
def run(command,cwd=ROOT): return subprocess.check_output(command,cwd=cwd,text=True,timeout=60).strip()
def fsync_dir(p):
 fd=os.open(p,os.O_RDONLY|os.O_DIRECTORY)
 try: os.fsync(fd)
 finally: os.close(fd)
def main():
 parser=argparse.ArgumentParser(description=__doc__);parser.add_argument('plan_id',choices=ORDER);parser.add_argument('--dispatch',action='store_true');args=parser.parse_args()
 lock=None
 if args.dispatch:
  lock=open(TMP/'freespace-root-reuse-admission.lock','a+');fcntl.flock(lock,fcntl.LOCK_EX|fcntl.LOCK_NB)
 m,l,f=read(MANIFEST),read(LEDGER),read(FREEZE);require(m.get('status')=='registered' and hashlib.sha256(FREEZE.read_bytes()).hexdigest()==m.get('source_hash_manifest_sha256'),'unregistered or changed source freeze'); plan=one(m['plans'],args.plan_id);require(plan==one(l['planned_next_dispatches'],args.plan_id),'manifest/ledger differ');require(not plan.get('run_id') and not any(x.get('id')==args.plan_id for x in l['runs']),'already registered');receipt=TMP/('freespace-'+args.plan_id+'-dispatch.json');require(not receipt.exists(),'existing attempt; inspect it, do not retry')
 require(m['candidate_revision']==HEAD and m['baseline_revision']==BASE and m['control_revision']==CONTROL and m['prerequisite_aa_run']==41253374855,'manifest identity mismatch')
 require(l['aggregate_cap_runner_seconds']==216000 and l['maximum_committed_seconds']<=216000 and l['remaining_unreserved_seconds']==216000-l['maximum_committed_seconds'] and l['remaining_unreserved_seconds']>=0,'campaign accounting mismatch');require(l['planned_reserved_seconds']==sum(p['maximum_job_seconds'] for p in l['planned_next_dispatches']),'reservation mismatch')
 expected=(100000,100409,['refresh'],10000,'changed-full',1024,'smoke',1,20,3300,900) if args.plan_id==ORDER[0] else (1000000,1004499,['scan','refresh'],100,'unchanged',4096,'screen',3,55,5400,2400)
 actual=tuple(plan[k] for k in ('files','expected_entries','operations','subtree_entries','scenario','memory_mib','stage','pairs_per_operation','timeout_minutes','maximum_job_seconds','forecast_seconds'));require(actual==expected,'case mismatch')
 require(all(plan.get(k)==v for k,v in {'branch':BRANCH,'revision':HEAD,'baseline':BASE,'comparison':'candidate','target':'x86_64-unknown-linux-musl','io':'local','cpus':2,'workers':1,'setup_memory_mib':4096,'observer_memory_mib':4096,'runner_preparation_policy':'sdk-space-v1','measurement_protocol':'v1-single-operation-pairs-v4','scan_profile':'disk'}.items()),'protocol mismatch')
 require(plan['forecast_with_margin_seconds']==plan['forecast_seconds']*1.3 and plan['forecast_with_margin_seconds']<plan['timeout_minutes']*60,'forecast mismatch')
 require(f['baseline_source_epoch']==1793464183 and int(run(['git','show','-s','--format=%ct',BASE],TREES['candidate']))==f['baseline_source_epoch'],'source epoch mismatch')
 for key,tree in TREES.items():
  state=f['states'][key];require(run(['git','rev-parse','HEAD'],tree)==state['head'],'head changed '+key);require(not run(['git','status','--porcelain','--untracked-files=no'],tree),'modified tracked files '+key)
  tracked=subprocess.check_output(['git','ls-files','-z'],cwd=tree,timeout=60).decode().split('\0');require(set(filter(None,tracked))==set(state['tracked_file_sha256']),'tracked set changed '+key)
  for p,h in state['tracked_file_sha256'].items():require(hashlib.sha256((tree/p).read_bytes()).hexdigest()==h,'source changed '+p)
 require(f['states']['candidate']['head']==HEAD and f['states']['control']['head']==CONTROL and f['states']['reference_471']['head']==REF,'frozen heads mismatch')
 require(set(f['benchmark_paths'])=={p for p in f['states']['candidate']['tracked_file_sha256'] if p.startswith(('scripts/','.github/workflows/'))},'benchmark scope mismatch')
 for p in f['benchmark_paths']:
  digest=f['states']['candidate']['tracked_file_sha256'][p]
  require(digest==f['states']['reference_471']['tracked_file_sha256'].get(p)==f['states']['control']['tracked_file_sha256'].get(p),'benchmark equivalence failed '+p)
 sys.path.insert(0,str(TREES['candidate']/'scripts'));from bench_v1_admission import stage_timeouts,qualification_case,validate_changed_full_baseline
 require(stage_timeouts(plan['stage'],plan['timeout_minutes'])['maximum_runner_minutes']*60==plan['maximum_job_seconds'],'job maximum mismatch');qualification_case(str(plan['subtree_entries']),plan['scenario'],str(plan['memory_mib']),plan['operations'],plan['files']);validate_changed_full_baseline(plan['scenario'],plan['comparison'],BASE)
 prior=TMP/'freespace-admit-compact-stage-https.py';require(hashlib.sha256(prior.read_bytes()).hexdigest()==f['prior_admission_sha256'],'prior validator changed')
 spec=importlib.util.spec_from_file_location('prior_admission',prior);old=importlib.util.module_from_spec(spec);spec.loader.exec_module(old)
 aa=one(read(AA_MANIFEST)['plans'],'compact-stage-https-matched-control-screen');require(aa.get('run_id')==41253374855,'AA identity mismatch');old.verify_prior(aa,one(l['runs'],aa['id']),BASE_BIN)
 frozen=None
 if args.plan_id==ORDER[1]:
  frozen=m.get('candidate_binary_sha256');require(isinstance(frozen,str) and re.fullmatch('[0-9a-f]{64}',frozen) is not None,'freeze smoke candidate hash before screen');smoke=one(m['plans'],ORDER[0]);require(smoke.get('actual_candidate_sha256')==frozen,'smoke hash not frozen');old.verify_prior(smoke,one(l['runs'],ORDER[0]),frozen)
 inputs=dict(stage=plan['stage'],operation=plan['operations'][0] if len(plan['operations'])==1 else 'auto',target=plan['target'],subtree_entries=str(plan['subtree_entries']),scenario=plan['scenario'],memory_mib=str(plan['memory_mib']),io=plan['io'],comparison='candidate',baseline=BASE,timeout_minutes=str(plan['timeout_minutes']),forecast_seconds='0',forecast_case_id='')
 record={'plan_id':args.plan_id,'expected_head_sha':HEAD,'expected_baseline_binary':BASE_BIN,'expected_candidate_binary':frozen,'inputs':inputs,'source_epoch':f['baseline_source_epoch'],'source_hashes_verified':True,'fresh_aa_run':41253374855,'forecast_with_margin_seconds':plan['forecast_with_margin_seconds'],'maximum_job_seconds':plan['maximum_job_seconds'],'dispatch_attempted_at':dt.datetime.now(dt.timezone.utc).isoformat(),'dispatched':False,'registration':'separate manual registration required'}
 if not args.dispatch:print(json.dumps({'mode':'dry-run','remote_heads':'not checked in dry-run',**record},indent=2));return
 with receipt.open('x') as out:out.write(json.dumps(record,indent=2)+'\n');out.flush();os.fsync(out.fileno())
 fsync_dir(receipt.parent)
 try:
  for ref,sha in [('refs/heads/'+BRANCH,HEAD),('refs/heads/perf/v1-memory-candidate-control',CONTROL),('refs/heads/perf/v1-memory-candidate-default-cache',REF)]:
   rows=run(['git','ls-remote','origin',ref]).splitlines();require(len(rows)==1 and rows[0].split()==[sha,ref],'remote changed: '+ref)
  command=['gh','workflow','run','representative-bench.yml','--ref',BRANCH]
  for k,v in inputs.items():command+=['-f',k+'='+v]
  result=subprocess.run(command,cwd=ROOT,text=True,capture_output=True,timeout=60);record.update(dispatched=result.returncode==0,dispatch_exit_code=result.returncode,stdout=result.stdout,stderr=result.stderr)
 except subprocess.TimeoutExpired as e:record.update(error=type(e).__name__+': '+str(e),dispatch_outcome='unknown; inspect GitHub before any action')
 except Exception as e:record.update(error=type(e).__name__+': '+str(e),dispatch_outcome='unknown; inspect GitHub before any action')
 with receipt.open('w') as out:out.write(json.dumps(record,indent=2)+'\n');out.flush();os.fsync(out.fileno())
 print(json.dumps(record,indent=2));return 0 if record['dispatched'] else 1
if __name__=='__main__':sys.exit(main())
