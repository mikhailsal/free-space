# v1-single-operation-pairs-v4

Case: {"case_policy": "qualification-v1", "memory_mib": 4096, "mutation_receipt": null, "observer_memory_mib": 4096, "scenario": "unchanged", "setup_memory_mib": 4096, "subtree_entries": 100}


Descriptive paired results; no automatic promotion or uncertainty estimate.
Application disk peak is sampled; RSS excludes the observer.

| Pair | Elapsed baseline → candidate (s) | RSS baseline → candidate (MiB) | App disk baseline → candidate (GiB) |
|---:|---:|---:|---:|
| 1 | 64.284 → 64.332 (Δ +0.048) | 36.816 → 37.148 (Δ +0.332) | 0.430 → 0.430 (Δ +0.000) |
| 2 | 64.136 → 64.581 (Δ +0.445) | 37.117 → 36.875 (Δ -0.242) | 0.430 → 0.430 (Δ +0.000) |
| 3 | 64.247 → 64.501 (Δ +0.254) | 37.016 → 36.949 (Δ -0.066) | 0.430 → 0.430 (Δ +0.000) |

Identical binaries: observed maximum absolute paired differences (descriptive band):
- elapsed_seconds: median Δ +0.254; max |Δ| 0.445
- peak_rss_kib: median Δ -68.000; max |Δ| 340.000
- app_disk_peak_bytes: median Δ +0.000; max |Δ| 0.000

VALID
