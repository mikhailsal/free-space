# v1-single-operation-pairs-v4

Case: {"case_policy": "qualification-v1", "memory_mib": 4096, "mutation_receipt": null, "observer_memory_mib": 4096, "scenario": "unchanged", "setup_memory_mib": 4096, "subtree_entries": 100}


Descriptive paired results; no automatic promotion or uncertainty estimate.
Application disk peak is sampled; RSS excludes the observer.

| Pair | Elapsed baseline → candidate (s) | RSS baseline → candidate (MiB) | App disk baseline → candidate (GiB) |
|---:|---:|---:|---:|
| 1 | 10.499 → 10.451 (Δ -0.048) | 368.363 → 368.371 (Δ +0.008) | 0.350 → 0.350 (Δ +0.000) |
| 2 | 10.359 → 10.304 (Δ -0.055) | 368.258 → 368.488 (Δ +0.230) | 0.350 → 0.350 (Δ +0.000) |
| 3 | 10.180 → 11.150 (Δ +0.969) | 368.434 → 368.230 (Δ -0.203) | 0.350 → 0.350 (Δ +0.000) |

Identical binaries: observed maximum absolute paired differences (descriptive band):
- elapsed_seconds: median Δ -0.048; max |Δ| 0.969
- peak_rss_kib: median Δ +8.000; max |Δ| 236.000
- app_disk_peak_bytes: median Δ +0.000; max |Δ| 0.000

VALID
