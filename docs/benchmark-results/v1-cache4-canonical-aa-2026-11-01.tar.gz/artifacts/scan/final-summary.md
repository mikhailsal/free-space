# v1-single-operation-pairs-v4

Case: {"case_policy": "qualification-v1", "memory_mib": 4096, "mutation_receipt": null, "observer_memory_mib": 4096, "scenario": "unchanged", "setup_memory_mib": 4096, "subtree_entries": 100}


Descriptive paired results; no automatic promotion or uncertainty estimate.
Application disk peak is sampled; RSS excludes the observer.

| Pair | Elapsed baseline → candidate (s) | RSS baseline → candidate (MiB) | App disk baseline → candidate (GiB) |
|---:|---:|---:|---:|
| 1 | 63.823 → 64.626 (Δ +0.802) | 36.910 → 36.887 (Δ -0.023) | 0.430 → 0.430 (Δ +0.000) |
| 2 | 63.613 → 64.450 (Δ +0.837) | 36.973 → 36.781 (Δ -0.191) | 0.430 → 0.430 (Δ +0.000) |
| 3 | 63.661 → 64.648 (Δ +0.986) | 36.941 → 36.871 (Δ -0.070) | 0.430 → 0.430 (Δ +0.000) |

Identical binaries: observed maximum absolute paired differences (descriptive band):
- elapsed_seconds: median Δ +0.837; max |Δ| 0.986
- peak_rss_kib: median Δ -72.000; max |Δ| 196.000
- app_disk_peak_bytes: median Δ +0.000; max |Δ| 0.000

VALID
