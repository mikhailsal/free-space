# v1-single-operation-pairs-v4

Case: {"case_policy": "qualification-v1", "memory_mib": 4096, "mutation_receipt": null, "observer_memory_mib": 4096, "scenario": "unchanged", "setup_memory_mib": 4096, "subtree_entries": 100}


Descriptive paired results; no automatic promotion or uncertainty estimate.
Application disk peak is sampled; RSS excludes the observer.

| Pair | Elapsed baseline → candidate (s) | RSS baseline → candidate (MiB) | App disk baseline → candidate (GiB) |
|---:|---:|---:|---:|
| 1 | 11.049 → 10.648 (Δ -0.401) | 369.102 → 369.027 (Δ -0.074) | 0.349 → 0.349 (Δ +0.000) |
| 2 | 10.623 → 10.657 (Δ +0.034) | 369.086 → 368.922 (Δ -0.164) | 0.349 → 0.349 (Δ +0.000) |
| 3 | 10.591 → 10.733 (Δ +0.142) | 369.059 → 369.078 (Δ +0.020) | 0.349 → 0.349 (Δ +0.000) |

Identical binaries: observed maximum absolute paired differences (descriptive band):
- elapsed_seconds: median Δ +0.034; max |Δ| 0.401
- peak_rss_kib: median Δ -76.000; max |Δ| 168.000
- app_disk_peak_bytes: median Δ +0.000; max |Δ| 0.000

VALID
