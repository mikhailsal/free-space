"""Read-only paired descriptions; no acceptance-policy decisions or benchmark execution."""
import argparse
from fractions import Fraction
from pathlib import Path
import hashlib
import json
import statistics


def sha(path):
    return hashlib.sha256(path.read_bytes()).hexdigest()


def value(x):
    return Fraction(str(x))


def describe(rows):
    result = []
    for number, baseline, candidate in rows:
        baseline, candidate = value(baseline), value(candidate)
        assert baseline > 0
        delta = candidate - baseline
        percent = 100 * delta / baseline
        result.append(dict(pair=number, baseline=float(baseline), candidate=float(candidate),
                           delta=float(delta), delta_exact=str(delta), percent=float(percent),
                           percent_exact=str(percent)))
    deltas = [Fraction(r['delta_exact']) for r in result]
    percents = [Fraction(r['percent_exact']) for r in result]
    return dict(pairs=result, median_delta=float(statistics.median(deltas)),
                median_delta_exact=str(statistics.median(deltas)),
                median_percent=float(statistics.median(percents)),
                median_percent_exact=str(statistics.median(percents)),
                maximum_absolute_delta=float(max(map(abs, deltas))),
                maximum_absolute_percent=float(max(map(abs, percents))),
                worst_increase_delta=float(max(deltas)),
                worst_increase_percent=float(max(percents)))


def analyze(prefix):
    data, inputs = {}, {}
    for operation in ('scan', 'refresh'):
        directory = prefix / operation / 'measurements'
        path = directory / 'summary.json'
        inputs[str(path)] = sha(path)
        summary = json.loads(path.read_bytes())
        assert summary['valid'] is True and not summary['issues']
        assert [p['pair'] for p in summary['pairs']] == [1, 2, 3]
        metrics = {}
        for key in ('elapsed_seconds', 'peak_rss_kib', 'app_disk_peak_bytes'):
            metrics[key] = describe([(p['pair'], p[key]['baseline'], p[key]['candidate'])
                                     for p in summary['pairs']])
        memory = []
        for pair in (1, 2, 3):
            peaks = []
            for arm in ('baseline', 'candidate'):
                path = directory / f'p{pair}-{arm}-v1' / 'metrics.json'
                inputs[str(path)] = sha(path)
                metric = json.loads(path.read_bytes())
                assert metric['exit_code'] == 0 and metric['validated'] is True
                peaks.append(int(metric['cgroup_after']['memory.peak']))
            memory.append((pair, *peaks))
        metrics['total_worker_cgroup_peak_bytes'] = describe(memory)
        data[operation] = metrics
    return dict(metrics=data, input_sha256=inputs)


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument('control_prefix', type=Path)
    parser.add_argument('candidate_prefix', type=Path)
    args = parser.parse_args()
    result = dict(scope='Descriptive paired medians and empirical A/A spreads only; not confidence bounds or a qualification decision.',
                  calculator_sha256=sha(Path(__file__)), control=analyze(args.control_prefix),
                  candidate=analyze(args.candidate_prefix))
    print(json.dumps(result, indent=2, allow_nan=False))


if __name__ == '__main__':
    main()
