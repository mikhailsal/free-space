# v1-single-operation-pairs-v4

Case: {"case_policy": "qualification-v1", "memory_mib": 1024, "mutation_receipt": {"changed_mtime": 1700000060000000000, "changed_size": 8192, "recipe": "rename-size-mtime", "renamed_inode": 850439, "target_mtime": 1700000060000000000}, "observer_memory_mib": 4096, "scenario": "changed", "setup_memory_mib": 4096, "subtree_entries": 10000}


Descriptive paired results; no automatic promotion or uncertainty estimate.
Application disk peak is sampled; RSS excludes the observer.

| Pair | Elapsed baseline → candidate (s) | RSS baseline → candidate (MiB) | App disk baseline → candidate (GiB) |
|---:|---:|---:|---:|
| 1 | 1.146 → 1.144 (Δ -0.002) | 71.035 → 71.141 (Δ +0.105) | 0.034 → 0.034 (Δ +0.000) |

Identical binaries: observed maximum absolute paired differences (descriptive band):
- elapsed_seconds: median Δ -0.002; max |Δ| 0.002
- peak_rss_kib: median Δ +108.000; max |Δ| 108.000
- app_disk_peak_bytes: median Δ +0.000; max |Δ| 0.000

VALID
