## Cgroup instrumentation contrast — VALID

Instrumentation contrast, not a noise band or product optimization. Cgroup reads, JSON encoding and cache writes are cocharged to the worker. The shared 20ms sampler can delay disk sampling and free-space reserve checks. Output and snapshot devices can share a physical disk. Five-second points are non-atomic; they provide no phase attribution or peak decomposition.

- p1-candidate-v1: receipt.scope=worker cgroup includes CLI, helper, sampler and diagnostic; output may share storage; output st_dev=2049; snapshot st_dev=1792
