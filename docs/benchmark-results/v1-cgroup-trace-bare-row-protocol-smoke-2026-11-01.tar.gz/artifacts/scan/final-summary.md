# v1-single-operation-pairs-v4

Case: {"case_policy": "qualification-v1", "memory_mib": 4096, "mutation_receipt": null, "observer_memory_mib": 4096, "scenario": "unchanged", "setup_memory_mib": 4096, "subtree_entries": 100}


Descriptive paired results; no automatic promotion or uncertainty estimate.
Application disk peak is sampled; RSS excludes the observer.

| Pair | Elapsed baseline → candidate (s) | RSS baseline → candidate (MiB) | App disk baseline → candidate (GiB) |
|---:|---:|---:|---:|
| 1 | 5.046 → 5.034 (Δ -0.013) | 37.051 → 37.121 (Δ +0.070) | 0.042 → 0.042 (Δ +0.000) |

Identical binaries: observed maximum absolute paired differences (descriptive band):
- elapsed_seconds: median Δ -0.013; max |Δ| 0.013
- peak_rss_kib: median Δ +72.000; max |Δ| 72.000
- app_disk_peak_bytes: median Δ +0.000; max |Δ| 0.000

VALID
