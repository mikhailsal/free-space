# Prospective cgroup-trace calibration audit

The two cases fit the stated time and current aggregate budgets as **planning proposals**, not a dispatch or a product qualification. Final source review and hash freeze, actual binary verification, and a fresh budget snapshot remain prerequisites. The parent agent corrected the smoke count: unchanged 100,000 files / subtree 100 produces **100,449 entries**, not 100,409. The latter came from a different changed-full, 10,000-subtree fixture. Current fixture source counts `files + len(directories)`: 100 unrelated chunks, 449 directories and 100,449 total; prior unchanged A/A smoke 41231314351 independently recorded that count. The 1m case has 1,004,499 entries.

Both proposed cases are staged-v1 scan only, unchanged subtree 100, musl/local, two CPUs, one worker, no swap, 4 GiB measured-worker cap and separately capped 4 GiB seeds/observers. `off` remains the default; explicit `contrast` runs baseline trace-off and candidate trace-on with the same product binary in an interleaved pair. Use workflow comparison `candidate` to build baseline `e826` and the reviewed diagnostic-harness head; both actual binary SHA-256 values **must** be `ed2a1cb138b1e48e70a388a4a8fda3e79fcfd2e37fd0c061d41d2d6363f8e980`. Validate ordinary protocol-v4 summaries unchanged and diagnostic receipts separately. The only proposed cases are:

| Case | Pairs | Whole-step allowance breakdown, seconds | Forecast + 30% | Step / aggregate job caps |
| --- | ---: | --- | ---: | ---: |
| 100k / 100,449 smoke | 1 | fixture 4 + seeds 4 + workers 10 + observers 4 + copies 2 + fixed 300 + diagnostic uncertainty 576 = 900 | 1,170 s | 1,200 / 3,300 s |
| 1m / 1,004,499 screen | 3 | fixture 44 + seeds 72 + workers 390 + observers 138 + copies 6 + fixed 600 + diagnostic uncertainty 1,150 = 2,400 | 3,120 s | 3,300 / 5,400 s |

Round-ups use the maximum per-arm values from prior unchanged A/A raw receipts: 100k fixture 3.731 s, seed maximum 1.711 s, worker 4.527 s, observer 1.567 s, copy 0.054 s (run 41231314351); 1m fixture 43.987 s, seed maximum 35.787 s, worker 64.581 s, observer 22.564 s, copy 0.799 s (run 41237970872). Six worker/observer/copy allowances in the screen correspond to three pairs; seeds run twice. Fixed and uncertainty allowances are judgments, not measured diagnostic overhead or guarantees. The smoke has just 30 s of margin below its step cap; tracing, runner variation or setup can exceed the allowance. A timeout or incomplete case is invalid, not an invitation to silently raise caps or retry.

`stage_timeouts` at the uncommitted diagnostic source bounds requested 20/55-minute steps to job caps of 30/65 minutes plus 25-minute builds, giving 3,300/5,400 aggregate runner-second maxima. The supplied ledger snapshot is cap 216,000, completed 43,696, existing reserved 34,800 and committed 78,496 seconds. Adding 8,700 seconds reserves 87,196, leaving 128,804 unreserved; refresh ledger and concurrent reservations immediately before any admission. This arithmetic does not itself reserve or authorize anything.

## Pre-data disposition: smoke is validity-only

The parent agent decided before any diagnostic data, within the authorized W1 investigation that numeric overhead bars apply **only to the 1m three-pair screen**. The 100k one-pair smoke must pass every ordinary semantic, resource, cleanup, hash and cap check and have a complete valid trace. Its metrics are descriptive; it does not calibrate overhead or establish no-regression. A valid smoke permits the already-registered screen only, not full-scale work or promotion. Any invalid smoke stops progression. This avoids treating a single pair as a 1% median calibration, especially given the earlier approximately +1.63% 100k A/A spread. No product acceptance bar changes.

The original pre-data proposal and its numerical bars remain below as history; the numerical bars now apply to the screen only. The previously noted smoke false-failure concern explains this disposition, not a change made after observing diagnostic data.

## Freeze before seeing contrast results

Proposed instrumentation calibration bars (not D2/D3 exceptions, population confidence bounds or product-gain thresholds):

- Time: absolute value of the median **signed paired percentage changes** ≤1%; maximum absolute paired percentage change ≤2%.
- Process RSS: absolute value of the median **signed paired KiB changes** ≤256 KiB; maximum absolute paired KiB change ≤512 KiB.
- Worker cgroup peak: positive part of median signed paired byte change ≤4 MiB; positive part of the largest signed paired byte change ≤8 MiB. Report negative changes too.
- Sampled application disk: median signed paired byte change exactly zero; maximum absolute paired byte change ≤8 KiB.

For pair `i`, percentage is `100*(trace_on_i/trace_off_i - 1)`. Median is taken over those paired changes; `abs(median(delta))` is **not** `median(abs(delta))`. A single smoke pair has no stable distribution and its median is that one pair. The 1m three-pair control is descriptive, not a confidence interval or transferable precision claim. These proposed numbers are qualitative choices rather than empirically established tolerances. For example, the earlier different-run 100k A/A worker times 4.454/4.527 s differ by about +1.63%, above the proposed 1% median bar; this illustrates false-failure risk, not a prediction for the new trace. Do not retune after seeing results. An invalid smoke stops the screen. A failed or inconclusive screen stops progression with no blind retry.

Require trace validation for all enabled arms: all specified cgroup files and required fields, complete hash-bound records and final sample, zero errors/missing/truncation/missed ticks, no invalid timing, and the same ordinary semantic/integrity/cleanup checks. Collector bounds are at most 1,500 samples, 4 MiB total, 64 KiB per record/read and 5 s interval. Report setup/finalization wall and thread CPU costs and late-tick counts; user-space scheduling or co-charged trace writes can themselves affect measurements. File reads are sequential and non-atomic, and 5 s points may miss peaks. Overlapping `memory.stat` fields cannot be added into a peak decomposition; monotonic trace times are not mapped to application phase clocks. Attribution and overhead are observational only; the source runner and full-scale workload may differ.

The [JSON](/tmp/freespace-cgroup-trace-bare-row-prereg-audit-20261101.json) records raw components and SHA-256 hashes for 37 evidence/source files. No manifest, ledger, source, test or workflow was changed or dispatched by this audit.

## Pre-data field bindings and evaluator contract

These are parent-agent measurement choices within the authorized W1 investigation; they are not new human decisions and do not change product gates. Apply numerical bars only to the three-pair screen. Within each same pair, **on** is `candidate-v1` and **off** is `baseline-v1`. Read time from `metrics.json.elapsed_seconds`, not GNU-rounded `time.elapsed_seconds`; RSS from `metrics.json.time.peak_rss_kib`; total cgroup peak from `metrics.json.cgroup_after["memory.peak"]` as an ASCII decimal string parsed to integer bytes; and sampled app disk peak from `metrics.json.app_disk_peak_bytes`, not incremental filesystem usage.

For each pair calculate signed time percent as `100 * (on - off) / off`; require `abs(median(signed percentages)) <= 1%` and `max(abs(pair percentage)) <= 2%`. Calculate signed on-minus-off differences for the remaining metrics: RSS exact integer KiB requires absolute median <= 256 KiB and worst absolute pair <= 512 KiB; total cgroup exact integer bytes requires positive median <= 4 MiB and positive worst pair <= 8 MiB; app disk exact integer bytes requires median exactly zero and worst absolute pair <= 8192 bytes. Medians are taken over the three signed paired differences before applying the specified absolute value or positive clipping. No data-driven tolerance applies. Smoke remains validity-only and all ordinary and diagnostic validity checks remain mandatory.

## New bare-row campaign, pre-data

Old smoke 41265785702 was ordinary-valid but diagnostic-invalid; its screen was cancelled and its reservation released. Kernel io.stat may emit a device header with no primary counters: valid absent counters remain explicitly unreported, never zero-filled. Malformed or partially reported counters remain invalid. This new-source campaign requires its own final exact review and immutable freeze; numerical gates remain unchanged. The refreshed budget snapshot is 44,065 seconds used, 34,800 reserved, 78,865 committed; these two cases reserve up to 8,700 more, leaving 128,435 seconds under the 216,000-second cap. Refresh the ledger before admission. Prior root-cause evidence: /tmp/freespace-cgroup-trace-smoke-root-cause-validation.json.
