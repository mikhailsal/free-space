# v1-single-operation-pairs-v4

Case: {"case_policy": "qualification-v1", "memory_mib": 1024, "mutation_receipt": null, "observer_memory_mib": 4096, "scenario": "unchanged", "setup_memory_mib": 4096, "subtree_entries": 100}


Descriptive paired results; no automatic promotion or uncertainty estimate.
Application disk peak is sampled; RSS excludes the observer.

| Pair | Elapsed baseline → candidate (s) | RSS baseline → candidate (MiB) | App disk baseline → candidate (GiB) |
|---:|---:|---:|---:|
| 1 | 58.120 → 57.357 (Δ -0.763) | 33.938 → 36.539 (Δ +2.602) | 0.430 → 0.430 (Δ -0.000) |
| 2 | 63.349 → 64.237 (Δ +0.887) | 36.617 → 36.543 (Δ -0.074) | 0.430 → 0.430 (Δ -0.000) |
| 3 | 58.448 → 60.589 (Δ +2.141) | 32.969 → 36.258 (Δ +3.289) | 0.430 → 0.430 (Δ -0.000) |

Identical binaries: observed maximum absolute paired differences (descriptive band):
- elapsed_seconds: median Δ +0.887; max |Δ| 2.141
- peak_rss_kib: median Δ +2664.000; max |Δ| 3368.000
- app_disk_peak_bytes: median Δ -4096.000; max |Δ| 16384.000

VALID
