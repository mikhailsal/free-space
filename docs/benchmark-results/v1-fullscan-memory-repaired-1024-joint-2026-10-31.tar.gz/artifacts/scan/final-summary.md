# v1-single-operation-pairs-v4

Case: {"case_policy": "qualification-v1", "memory_mib": 1024, "mutation_receipt": null, "observer_memory_mib": 4096, "scenario": "unchanged", "setup_memory_mib": 4096, "subtree_entries": 100}


Descriptive paired results; no automatic promotion or uncertainty estimate.
Application disk peak is sampled; RSS excludes the observer.

| Pair | Elapsed baseline → candidate (s) | RSS baseline → candidate (MiB) | App disk baseline → candidate (GiB) |
|---:|---:|---:|---:|
| 1 | 79.236 → 59.076 (Δ -20.160) | 36.332 → 36.305 (Δ -0.027) | 0.428 → 0.428 (Δ +0.000) |
| 2 | 77.655 → 55.039 (Δ -22.616) | 36.184 → 36.418 (Δ +0.234) | 0.428 → 0.428 (Δ +0.000) |
| 3 | 77.566 → 57.110 (Δ -20.456) | 36.449 → 36.152 (Δ -0.297) | 0.428 → 0.428 (Δ +0.000) |

VALID
