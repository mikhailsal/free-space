# v1-single-operation-pairs-v3

Descriptive paired results; no automatic promotion or uncertainty estimate.
Application disk peak is sampled; RSS excludes the observer.

| Pair | Elapsed baseline → candidate (s) | RSS baseline → candidate (MiB) | App disk baseline → candidate (GiB) |
|---:|---:|---:|---:|
| 1 | 63.638 → 63.707 (Δ +0.069) | 36.984 → 37.031 (Δ +0.047) | 0.428 → 0.428 (Δ +0.000) |
| 2 | 63.795 → 63.744 (Δ -0.051) | 36.977 → 37.086 (Δ +0.109) | 0.428 → 0.428 (Δ +0.000) |
| 3 | 63.868 → 64.359 (Δ +0.491) | 37.156 → 36.898 (Δ -0.258) | 0.428 → 0.428 (Δ +0.000) |

VALID
