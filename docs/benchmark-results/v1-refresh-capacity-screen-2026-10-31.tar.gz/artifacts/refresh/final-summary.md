# v1-single-operation-pairs-v3

Descriptive paired results; no automatic promotion or uncertainty estimate.
Application disk peak is sampled; RSS excludes the observer.

| Pair | Elapsed baseline → candidate (s) | RSS baseline → candidate (MiB) | App disk baseline → candidate (GiB) |
|---:|---:|---:|---:|
| 1 | 10.711 → 10.641 (Δ -0.071) | 369.012 → 280.883 (Δ -88.129) | 0.349 → 0.349 (Δ +0.000) |
| 2 | 10.625 → 10.637 (Δ +0.012) | 369.090 → 280.934 (Δ -88.156) | 0.349 → 0.349 (Δ +0.000) |
| 3 | 10.678 → 10.637 (Δ -0.041) | 369.086 → 281.055 (Δ -88.031) | 0.349 → 0.349 (Δ +0.000) |

VALID
