# Harness findings triage

Baseline source: `e8265778ef78ec4acd9da1375eedb0be37a123f5`. Harness: `/tmp/free-space-v1-memory-candidate`. No app or benchmark was run.

## H1: validation gap; schema claims supported

Baseline e826 core/src/snapshot/schema.rs:85-108,110-112 declares BLOB path/name and required integer columns; core/src/scan/tree.rs:61 ALIAS=2; core/src/scan/walk.rs:229,301 stores MetadataExt mtime seconds; core/src/snapshot/writer.rs:268-285,299-313 writes raw name bytes and hardlink dev/ino as i64. scripts/bench_v1_fixture.py:33-39 records raw st_dev/st_ino and ns time; runtime.py:43-77 uses raw Python ints, seconds floor and bit 2. Normal ext4 values fit i64; u64 values above i64 max wrap on Rust cast but Python comparison does not, a real portability edge.

Next: Add real product-generated tiny snapshot integration/oracle fixture on GH and explicitly validate or normalize signed SQLite representation with boundary coverage; do not assume synthetic schemas establish parity.

## H2: unsupported nondeterminism claim; runtime parity gap

e826 core/src/scan/staged/visit.rs:114-124,135-137 and staged/write.rs:245-272 select owner ORDER BY path,root,id; scan/tree.rs:300-337,349-362,445-469 picks lexicographically smallest full path, with first tie. Fixture paths in scripts/bench_v1_fixture.py:23-40 make small/nested/owner sort before unrelated/old-link. Refresh core/src/refresh.rs:148-199 preserves outside owner via forced_raw; removed inside owner tries forced_path then falls back to best. Thus out-of-subtree old alias promoted when old path gone; new external-owner file was single-link and absent from old hardlink map, new link is zeroed when known count < nlink. Not readdir-dependent.

Next: Exercise real baseline full scan + changed-full refresh with this exact fixture on GH, including both ownership transitions and original link accounting.

## H3: validation gap; claimed incompatibility unsupported

Integrated workflow .github/workflows/representative-bench.yml:55-58 defaults afce6fd; scripts/bench_v1_pair.py:128-143 seeds baseline. afce6fd core/src/refresh.rs:139-199 contains the same forced owner/fallback rules, and git diff afce6fd..e826 for schema/tree/staged visit/staged write is empty; refresh diff adds seven profiling lines only. No proof from source that afce lacks promotion. Protocol provenance still matters: afce default is not the authorized canonical e826 baseline.

Next: Require explicit full e826 SHA for this candidate campaign, verify admitted manifest/provenance, and run a real changed-full end-to-end smoke before qualification.

## H4: reviewer rotation claim false; validation gap real

e826 core/src/refresh.rs:279-294 publishes only current; core/src/snapshot/publish.rs:1-5 specifies rotate_prev only full scan; job.rs:330-349 rotates on scan. Integrated scripts/bench_v1_summary.py:274-280 correctly compares previous facts to seed snapshot.prev.db, not seed current. Equal rows between the two initial scans make link facts alone unable to detect unintended rotation/substitution.

Next: Preserve previous contract; add prior-specific byte/hash or generation/scanned_at evidence and a negative fixture with distinct prior/current to detect replacement.

## H5: unsupported defect claim; not inode-reuse coverage

scripts/bench_v1_fixture.py:107-123 creates additions before deleting originals, then checks distinct live inode identities; summary.py:62 validates receipt distinctness. This deliberately avoids reuse ambiguity and asserts pre-mutation distinctness; it does not claim to test reuse.

Next: Keep guard, document scope; exercise delete-then-add reuse only in a separately specified fixture if that behavior is required.

## H6: confirmed missing execution deadline; full-table claim overstated

scripts/bench_v1_runtime.py:43-57 has no SQLite progress/deadline; host call scripts/bench_v1_pair.py:142-143 is outside container deadline, and observer calls runtime.py:199-202 also lack a lookup-specific deadline. e826 core/src/snapshot/schema.rs:135-136 has entries_parent_alloc index, so parent_id lookup can use its prefix; cannot infer full table scan per component, but large child fanout can still cost time.

Next: Add a monotonic SQLite progress deadline/interrupt plus host-level bounded execution as appropriate; test expiration and cleanup without loosening semantic checks.

## H7: confirmed orchestration test gap

scripts/bench_v1_pair.py:106,130-154,183-197 wires prepare, seed facts, mutation and per-arm plan; runtime.py:185-205 builds observer facts. Existing scripts/tests/test_bench_v1_runtime.py:20-49 and summary.py:81-175 exercise helper/synthetic inputs; runtime.py:246-250 host test only refuses non-GH execution. No changed-full host/inside end-to-end wiring test found.

Next: Add tiny mocked host orchestration and observer-inside tests asserting scenario, plans, both seed snapshots, current/previous evidence, and failure propagation; do not run app locally.

## H8: confirmed validation gap

scripts/bench_v1_summary.py:145-158 validates full fields only when changed-full; spec plan comparison occurs only at :274-280. Non-full manifest seed_link_facts, fixture mutation_plan, per-spec mutation_plan or observer full_link_facts can contain stale evidence without rejection. Current host emits seed_link_facts=None for non-full.

Next: Enforce explicit absent/None policy consistent with existing v4 producers and compatibility, reject stale scenario-only fields with focused negative tests; retain strict valid ordinary cases.
