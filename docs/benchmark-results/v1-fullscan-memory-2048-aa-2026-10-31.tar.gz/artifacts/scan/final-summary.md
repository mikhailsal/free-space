# v1-single-operation-pairs-v4

Case: {"case_policy": "qualification-v1", "memory_mib": 2048, "mutation_receipt": null, "observer_memory_mib": 4096, "scenario": "unchanged", "setup_memory_mib": 4096, "subtree_entries": 100}


Descriptive paired results; no automatic promotion or uncertainty estimate.
Application disk peak is sampled; RSS excludes the observer.

| Pair | Elapsed baseline → candidate (s) | RSS baseline → candidate (MiB) | App disk baseline → candidate (GiB) |
|---:|---:|---:|---:|
| 1 | 67.488 → 66.514 (Δ -0.974) | 36.637 → 36.680 (Δ +0.043) | 0.428 → 0.428 (Δ +0.000) |
| 2 | 65.812 → 67.151 (Δ +1.339) | 36.684 → 36.754 (Δ +0.070) | 0.428 → 0.428 (Δ +0.000) |
| 3 | 65.944 → 66.163 (Δ +0.218) | 36.809 → 36.730 (Δ -0.078) | 0.428 → 0.428 (Δ +0.000) |

Identical binaries: observed maximum absolute paired differences (descriptive band):
- elapsed_seconds: median Δ +0.218; max |Δ| 1.339
- peak_rss_kib: median Δ +44.000; max |Δ| 80.000
- app_disk_peak_bytes: median Δ +12288.000; max |Δ| 12288.000

VALID
