# v1-single-operation-pairs-v4

Case: {"case_policy": "qualification-v1", "memory_mib": 512, "mutation_receipt": null, "observer_memory_mib": 4096, "scenario": "unchanged", "setup_memory_mib": 4096, "subtree_entries": 100000}


Descriptive paired results; no automatic promotion or uncertainty estimate.
Application disk peak is sampled; RSS excludes the observer.

| Pair | Elapsed baseline → candidate (s) | RSS baseline → candidate (MiB) | App disk baseline → candidate (GiB) |
|---:|---:|---:|---:|
| 1 | 4.635 → 4.741 (Δ +0.106) | 96.285 → 96.398 (Δ +0.113) | 0.030 → 0.030 (Δ +0.000) |

Identical binaries: observed maximum absolute paired differences (descriptive band):
- elapsed_seconds: median Δ +0.106; max |Δ| 0.106
- peak_rss_kib: median Δ +116.000; max |Δ| 116.000
- app_disk_peak_bytes: median Δ +0.000; max |Δ| 0.000

VALID
