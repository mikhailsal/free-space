# v1-single-operation-pairs-v4

Case: {"case_policy": "qualification-v1", "memory_mib": 512, "mutation_receipt": null, "observer_memory_mib": 4096, "scenario": "unchanged", "setup_memory_mib": 4096, "subtree_entries": 100}


Descriptive paired results; no automatic promotion or uncertainty estimate.
Application disk peak is sampled; RSS excludes the observer.

| Pair | Elapsed baseline → candidate (s) | RSS baseline → candidate (MiB) | App disk baseline → candidate (GiB) |
|---:|---:|---:|---:|
| 1 | 83.709 → 84.978 (Δ +1.269) | 34.422 → 33.223 (Δ -1.199) | 0.428 → 0.428 (Δ -0.000) |
| 2 | 84.817 → 82.220 (Δ -2.597) | 33.039 → 33.145 (Δ +0.105) | 0.428 → 0.428 (Δ +0.000) |
| 3 | 85.356 → 85.127 (Δ -0.229) | 33.117 → 32.332 (Δ -0.785) | 0.428 → 0.428 (Δ -0.000) |

Identical binaries: observed maximum absolute paired differences (descriptive band):
- elapsed_seconds: median Δ -0.229; max |Δ| 2.597
- peak_rss_kib: median Δ -804.000; max |Δ| 1228.000
- app_disk_peak_bytes: median Δ -12288.000; max |Δ| 36864.000

VALID
