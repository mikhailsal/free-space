# v1-single-operation-pairs-v3

Descriptive paired results; no automatic promotion or uncertainty estimate.
Application disk peak is sampled; RSS excludes the observer.

| Pair | Elapsed baseline → candidate (s) | RSS baseline → candidate (MiB) | App disk baseline → candidate (GiB) |
|---:|---:|---:|---:|
| 1 | 639.785 → 477.140 (Δ -162.645) | 34.445 → 34.230 (Δ -0.215) | 3.133 → 3.133 (Δ -0.000) |

VALID
