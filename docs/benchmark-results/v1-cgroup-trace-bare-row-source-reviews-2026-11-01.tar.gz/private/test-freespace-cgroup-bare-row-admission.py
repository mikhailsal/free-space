import unittest,tempfile,pathlib,json,types,sys,importlib.util
from unittest.mock import patch
p=importlib.util.spec_from_file_location('admission','/tmp/freespace-admit-cgroup-trace-bare-row.py');m=importlib.util.module_from_spec(p);p.loader.exec_module(m)
a=json.load(open('/tmp/freespace-cgroup-trace-bare-row-prereg-audit-20261101.json'))
class TestEvaluator(unittest.TestCase):
 def setUp(self):
  self.binding=patch.object(m,'screen_binding',return_value={});self.binding.start();self.t=tempfile.TemporaryDirectory();self.d=pathlib.Path(self.t.name);self.summary={'valid':True};self.result={'valid':True,'issues':[],'ordinary_summary':self.summary};sys.modules['bench_v1_cgroup_diagnostic']=types.SimpleNamespace(analyze=lambda _:self.result)
  (self.d/'summary.json').write_text(json.dumps(self.summary));(self.d/'diagnostic-summary.json').write_text(json.dumps(self.result));(self.d/'manifest.json').write_text(json.dumps({'operation':'scan','pairs':3,'files':1000000,'fixture_receipt':{'expected_entries':1004499},'cgroup_trace_policy':{'mode':'contrast','baseline-v1':False,'candidate-v1':True},'provenance':{k:{'sha256':m.BINARY} for k in ('baseline-v1','candidate-v1')}}))
  for i in range(1,4):
   for arm in ('baseline','candidate'):
    d=self.d/f'p{i}-{arm}-v1';d.mkdir();(d/'metrics.json').write_text(json.dumps({'elapsed_seconds':100,'time':{'peak_rss_kib':1000,'elapsed_seconds':1},'cgroup_after':{'memory.peak':'10000000'},'app_disk_peak_bytes':10000}))
 def tearDown(self):self.binding.stop();self.t.cleanup();sys.modules.pop('bench_v1_cgroup_diagnostic',None)
 def patch(self,i,arm,**kw):
  p=self.d/f'p{i}-{arm}-v1'/'metrics.json';v=json.loads(p.read_text());v.update(kw);p.write_text(json.dumps(v))
 def test_signed_boundary_and_path(self):
  for i in range(1,4):self.patch(i,'candidate',elapsed_seconds=101,time={'peak_rss_kib':1256,'elapsed_seconds':900},cgroup_after={'memory.peak':str(10000000+4*1048576)})
  v=m.evaluate_screen(self.d,a);self.assertEqual(v['decision'],'pass');self.assertEqual(v['signed_pairs'][0]['time_percent'],'1/1');self.assertEqual(v['signed_pairs'][0]['rss_kib'],256)
 def test_beyond_threshold_and_orientation(self):
  for i in range(1,4):self.patch(i,'candidate',elapsed_seconds=101.00001)
  self.assertEqual(m.evaluate_screen(self.d,a)['decision'],'fail')
  for i in range(1,4):self.patch(i,'candidate',elapsed_seconds=99,cgroup_after={'memory.peak':'1'})
  r=m.evaluate_screen(self.d,a);self.assertEqual(r['decision'],'pass');self.assertEqual(r['signed_pairs'][0]['time_percent'],'-1/1')
 def test_invalid_is_inconclusive(self):
  self.patch(1,'baseline',elapsed_seconds=0);self.assertEqual(m.evaluate_screen(self.d,a)['decision'],'inconclusive')
  self.patch(1,'baseline',elapsed_seconds=100,cgroup_after={'memory.peak':'1.0'});self.assertEqual(m.evaluate_screen(self.d,a)['decision'],'inconclusive')
class TestScreenBinding(unittest.TestCase):
 def test_registered_identity_and_case_fail_closed(self):
  with tempfile.TemporaryDirectory() as tmp:
   root=pathlib.Path(tmp);head='a'*40;artifact=root/'artifact';directory=artifact/'scan/measurements';directory.mkdir(parents=True)
   plan={'id':m.ORDER[1],'status':'completed','conclusion':'success','run_id':123,'revision':head,'baseline':m.BASE,'comparison':'candidate','operations':['scan'],'files':1000000,'expected_entries':1004499,'pairs_per_operation':3,'subtree_entries':100,'scenario':'unchanged','memory_mib':4096,'setup_memory_mib':4096,'observer_memory_mib':4096,'swap_mib':0,'cpus':2,'workers':1,'target':m.TARGET,'io':'local','cgroup_trace':'contrast','artifact_prefix':str(artifact),'binary_artifact_prefix':str(root/'binary')}
   freeze={'states':{'candidate':{'head':head,'tracked_file_sha256':{}}},'admission_helper_sha256':'hash','prior_validator_sha256':'hash','prereg_audit_sha256':'hash'}
   manifest={'status':'registered','research_only':True,'product_qualification':False,'source_hash_manifest_sha256':'hash','candidate_revision':head,'plans':[plan],'screen_calibration_bars':a['bars'],'screen_metric_sources':a['metric_sources'],'arm_orientation':a['arm_orientation'],'screen_interpretation_math':a['interpretation_math']};ledger={'runs':[dict(plan)]}
   provenance={arm:{'source_revision':rev,'sha256':m.BINARY,'build':{'source_revision':rev,'sha256':m.BINARY,'target':m.TARGET,'flags':{'SOURCE_DATE_EPOCH':m.EPOCH}}} for arm,rev in [('baseline-v1',m.BASE),('candidate-v1',head)]}
   raw={'github':{'GITHUB_SHA':head,'GITHUB_RUN_ID':'123'},'provenance':provenance};audit=a
   def fake_read(p):
    if p==m.MANIFEST:return manifest
    if p==m.LEDGER:return ledger
    if p==m.FREEZE:return freeze
    if p==m.AUDIT:return audit
    if p==directory/'manifest.json':return raw
    raise AssertionError(str(p))
   module=types.SimpleNamespace(verify_prior=lambda *x:True);spec=types.SimpleNamespace(loader=types.SimpleNamespace(exec_module=lambda _:None))
   def fake_digest(p):return m.BINARY if str(p).startswith(str(root/'binary')) else 'hash'
   with patch.object(m,'read',side_effect=fake_read),patch.object(m,'digest',side_effect=fake_digest),patch.object(m,'command',side_effect=lambda args,*x: '' if 'status' in args else head),patch.object(m.importlib.util,'spec_from_file_location',return_value=spec),patch.object(m.importlib.util,'module_from_spec',return_value=module):
    self.assertEqual(m.screen_binding(directory,audit),plan)
    raw['github']['GITHUB_RUN_ID']='124'
    with self.assertRaises(ValueError):m.screen_binding(directory,audit)
    raw['github']['GITHUB_RUN_ID']='123';ledger['runs'][0]['memory_mib']=1024
    with self.assertRaises(ValueError):m.screen_binding(directory,audit)

if __name__=='__main__':unittest.main()
