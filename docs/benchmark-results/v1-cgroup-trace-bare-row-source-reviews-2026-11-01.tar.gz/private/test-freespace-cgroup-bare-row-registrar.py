import datetime as dt
import importlib.util
import json
from pathlib import Path
import tempfile
import unittest
from unittest.mock import patch

spec = importlib.util.spec_from_file_location('registrar', '/tmp/freespace-register-cgroup-trace-bare-row.py')
r = importlib.util.module_from_spec(spec)
spec.loader.exec_module(r)


class RegistrarTests(unittest.TestCase):
    def setUp(self):
        self.temp = tempfile.TemporaryDirectory()
        self.addCleanup(self.temp.cleanup)
        root = Path(self.temp.name)
        for name, value in (('LEDGER', root / 'ledger'), ('MANIFEST', root / 'manifest'),
                            ('JOURNAL', root / 'journal'), ('RECEIPT_DIR', root), ('FREEZE', root / 'freeze')):
            patcher = patch.object(r, name, value)
            patcher.start()
            self.addCleanup(patcher.stop)
        self.plan_id = r.IDS[0]
        self.revision = 'a' * 40
        self.plan = dict(id=self.plan_id, revision=self.revision, branch=r.BRANCH,
                         status='planned', maximum_job_seconds=3300, immutable='kept')
        self.ledger = dict(runs=[], run_ids=[], planned_next_dispatches=[self.plan],
                           aggregate_cap_runner_seconds=216000)
        self.manifest = dict(plans=[self.plan], candidate_revision=self.revision, status='registered',
                             research_only=True, product_qualification=False)
        self.receipt_path = root / ('freespace-' + self.plan_id + '-dispatch.json')
        self.put(r.FREEZE, {'states': {'candidate': {'head': self.revision}},
                            'registrar_sha256': r.digest(Path(r.__file__).read_bytes())})
        self.manifest['source_hash_manifest_sha256'] = r.digest(r.FREEZE.read_bytes())
        self.put(r.LEDGER, self.ledger)
        self.put(r.MANIFEST, self.manifest)
        self.put(self.receipt_path, dict(plan_id=self.plan_id, dispatched=True, dispatch_attempted_at='now',
                                         expected_head_sha=self.revision, stdout='raw outcome'))
        self.run = dict(id=42, head_sha=self.revision, head_branch=r.BRANCH, event='workflow_dispatch',
                        path=r.WORKFLOW, run_attempt=1, status='in_progress', conclusion=None, created_at='now')
        self.job = dict(name='build', status='completed', conclusion='success', started_at='2026-01-01T00:00:00Z',
                        completed_at='2026-01-01T00:00:10Z')

    def put(self, path, data):
        path.write_text(json.dumps(data))

    def test_register_and_refresh_completed(self):
        start = (dt.datetime.now(dt.timezone.utc) - dt.timedelta(seconds=5)).isoformat()
        active = {'status': 'in_progress', 'started_at': start}
        r.update('register', self.plan_id, 42, self.run, [self.job, active])
        ledger = r.read(r.LEDGER)
        self.assertGreaterEqual(ledger['running_job_seconds_observed'], 5)
        self.assertEqual(ledger['used_runner_seconds_observed'], 10 + ledger['running_job_seconds_observed'])
        self.assertEqual(ledger['runs'][0]['running_job_seconds_observed'], ledger['running_job_seconds_observed'])
        self.assertTrue(ledger['runs'][0]['usage_observed_at'])
        self.assertEqual(ledger['maximum_committed_seconds'], 3300)
        self.assertEqual(ledger['runs'][0], r.read(r.MANIFEST)['plans'][0])
        completed = dict(self.run, status='completed', conclusion='success')
        r.update('refresh', self.plan_id, 42, completed,
                 [self.job, {'name': 'paired', 'status': 'completed', 'conclusion': 'skipped'}])
        ledger, manifest = r.read(r.LEDGER), r.read(r.MANIFEST)
        self.assertEqual(ledger['runs'][0], manifest['plans'][0])
        self.assertEqual(ledger['maximum_committed_seconds'], 10)
        self.assertEqual(ledger['running_job_seconds_observed'], 0)
        self.assertEqual(ledger['used_runner_seconds_observed'], 10)
        self.assertEqual(ledger['runs'][0]['status'], 'completed')
        self.assertEqual(r.read(self.receipt_path)['stdout'], 'raw outcome')
        with self.assertRaises(ValueError):
            r.update('register', self.plan_id, 42, completed, [self.job])

    def test_identity_mismatch_never_writes(self):
        for field, value in (('event', 'push'), ('head_sha', 'b' * 40), ('head_branch', 'wrong'),
                             ('path', '.github/workflows/other.yml'), ('run_attempt', 2), ('id', 43)):
            with self.subTest(field=field):
                invalid = dict(self.run, **{field: value})
                before = (r.LEDGER.read_bytes(), r.MANIFEST.read_bytes(), self.receipt_path.read_bytes())
                with self.assertRaises(ValueError):
                    r.update('register', self.plan_id, 42, invalid, [self.job])
                self.assertEqual(before, (r.LEDGER.read_bytes(), r.MANIFEST.read_bytes(), self.receipt_path.read_bytes()))

    def test_completed_run_requires_both_terminal_jobs(self):
        completed = dict(self.run, status='completed', conclusion='success')
        for jobs in ([], [self.job], [self.job, {'name': 'paired', 'status': 'in_progress'}]):
            with self.subTest(jobs=jobs), self.assertRaises(ValueError):
                r.update('register', self.plan_id, 42, completed, jobs)
        self.assertFalse(r.JOURNAL.exists())
        self.assertEqual(r.read(r.LEDGER)['runs'], [])

    def test_self_hash_mismatch_is_rejected(self):
        freeze = r.read(r.FREEZE)
        freeze['registrar_sha256'] = 'wrong'
        self.put(r.FREEZE, freeze)
        self.manifest['source_hash_manifest_sha256'] = r.digest(r.FREEZE.read_bytes())
        self.put(r.MANIFEST, self.manifest)
        with self.assertRaisesRegex(ValueError, 'registrar hash mismatch'):
            r.update('register', self.plan_id, 42, self.run, [self.job])
        self.assertFalse(r.JOURNAL.exists())

    def test_manifest_and_freeze_binding_rejected_before_mutation(self):
        for key, value in (('status', 'draft'), ('research_only', False),
                           ('product_qualification', True), ('source_hash_manifest_sha256', 'wrong')):
            with self.subTest(key=key):
                manifest = dict(self.manifest, **{key: value})
                self.put(r.MANIFEST, manifest)
                before = r.LEDGER.read_bytes()
                with self.assertRaises(ValueError):
                    r.update('register', self.plan_id, 42, self.run, [self.job])
                self.assertEqual(r.LEDGER.read_bytes(), before)
                self.assertFalse(r.JOURNAL.exists())

    def test_recovery_after_first_file_is_idempotent_and_conflicts_rejected(self):
        original = r.atomic_write
        def fail_manifest(path, data):
            if path == r.MANIFEST:
                raise OSError('simulated crash')
            return original(path, data)
        with patch.object(r, 'atomic_write', side_effect=fail_manifest):
            with self.assertRaises(OSError):
                r.update('register', self.plan_id, 42, self.run, [self.job])
        self.assertTrue(r.JOURNAL.exists())
        saved = r.MANIFEST.read_bytes()
        r.MANIFEST.write_text('foreign')
        with self.assertRaises(ValueError):
            r.recover()
        self.assertTrue(r.JOURNAL.exists())
        r.MANIFEST.write_bytes(saved)
        self.assertTrue(r.recover())
        self.assertFalse(r.recover())
        self.assertEqual(r.read(r.LEDGER)['runs'][0], r.read(r.MANIFEST)['plans'][0])
        self.assertEqual(r.read(self.receipt_path)['run_id'], 42)

    def test_job_seconds_skip_and_clamp(self):
        reversed_job = dict(self.job, completed_at='2025-12-31T23:59:59Z')
        skipped = dict(status='completed', conclusion='skipped', started_at=None, completed_at=None)
        self.assertEqual(r.seconds([self.job, reversed_job, skipped, {'status': 'in_progress'}]), 10)


if __name__ == '__main__':
    unittest.main()
