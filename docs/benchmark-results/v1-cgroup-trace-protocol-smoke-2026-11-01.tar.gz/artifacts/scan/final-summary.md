# v1-single-operation-pairs-v4

Case: {"case_policy": "qualification-v1", "memory_mib": 4096, "mutation_receipt": null, "observer_memory_mib": 4096, "scenario": "unchanged", "setup_memory_mib": 4096, "subtree_entries": 100}


Descriptive paired results; no automatic promotion or uncertainty estimate.
Application disk peak is sampled; RSS excludes the observer.

| Pair | Elapsed baseline → candidate (s) | RSS baseline → candidate (MiB) | App disk baseline → candidate (GiB) |
|---:|---:|---:|---:|
| 1 | 4.930 → 4.927 (Δ -0.003) | 37.016 → 36.973 (Δ -0.043) | 0.042 → 0.042 (Δ +0.000) |

Identical binaries: observed maximum absolute paired differences (descriptive band):
- elapsed_seconds: median Δ -0.003; max |Δ| 0.003
- peak_rss_kib: median Δ -44.000; max |Δ| 44.000
- app_disk_peak_bytes: median Δ +0.000; max |Δ| 0.000

VALID
