"""DRAFT: one-shot same-binary cgroup diagnostic admission; dry-run by default."""
import argparse, datetime as dt, fcntl, hashlib, importlib.util, json, os, pathlib, re, subprocess, sys
from decimal import Decimal
from fractions import Fraction
P=pathlib.Path; ROOT=P('/home/tass/myprojects/corp_v2/free-space'); OUT=ROOT/'docs/benchmark-results'; TMP=P('/tmp'); WT=TMP/'free-space-v1-cgroup-memory-trace'
MANIFEST=OUT/'v1-cgroup-memory-trace-manifest-2026-11-01.json'; LEDGER=OUT/'v1-w1-campaign-2026-10-31.json'; FREEZE=TMP/'freespace-cgroup-trace-all-source-hashes.json'; AUDIT=TMP/'freespace-cgroup-trace-prereg-audit-20261101.json'; PRIOR=TMP/'freespace-admit-compact-stage-https.py'
BASE='e8265778ef78ec4acd9da1375eedb0be37a123f5'; BINARY='ed2a1cb138b1e48e70a388a4a8fda3e79fcfd2e37fd0c061d41d2d6363f8e980'; EPOCH='1793464183'; BRANCH='perf/v1-cgroup-memory-trace'; TARGET='x86_64-unknown-linux-musl'; ORDER=['cgroup-trace-protocol-smoke','cgroup-trace-overhead-screen']
def read(path): return json.loads(path.read_text())
def digest(path): return hashlib.sha256(path.read_bytes()).hexdigest()
def require(condition,message):
 if not condition: raise ValueError(message)
def one(items,ident):
 rows=[x for x in items if x.get('id')==ident];require(len(rows)==1,'expected exactly one '+ident);return rows[0]
def command(args,cwd=ROOT): return subprocess.check_output(args,cwd=cwd,text=True,timeout=60).strip()
def fsync_dir(path):
 fd=os.open(path,os.O_RDONLY|os.O_DIRECTORY)
 try: os.fsync(fd)
 finally: os.close(fd)
def review_inputs(prompt, review, state):
 begin='\nBEGIN_REVIEW_INPUTS_JSON\n';end='\nEND_REVIEW_INPUTS_JSON\n'
 require(prompt.count(begin)==1 and prompt.count(end)==1 and prompt.endswith(end),'invalid anchored review packet')
 data=json.loads(prompt.split(begin,1)[1][:-len(end)])
 require(set(data)=={'repo_files','context_files','private_files'},'invalid review packet sections')
 groups=[('repo_files',review['reviewed_file_sha256'],WT),('context_files',review['context_file_sha256'],WT),('private_files',review['private_file_sha256'],None)]
 require(len(groups[0][1])==9,'expected nine reviewed source files')
 require('scripts/bench_v1_summary.py' in groups[1][1],'summary context missing')
 require({str(P(__file__)),str(AUDIT),str(AUDIT.with_suffix('.md')),str(TMP/'freespace-register-cgroup-trace.py'),str(PRIOR)} <= set(groups[2][1]),'mandatory private evidence missing')
 for section,expected,root in groups:
  entries=data[section];require(isinstance(entries,dict) and set(entries)==set(expected),'review input set mismatch '+section)
  for name,h in expected.items():
   path=(root/name) if root else P(name);item=entries[name]
   require(isinstance(item,dict) and set(item)=={'sha256','content'} and isinstance(item['content'],str),'invalid reviewed item')
   encoded=item['content'].encode('utf-8');require(item['sha256']==h and hashlib.sha256(encoded).hexdigest()==h and path.read_bytes()==encoded,'review input bytes differ: '+name)
   if root: require(state['tracked_file_sha256'].get(name)==h,'review input differs from frozen tree: '+name)
 return data

def screen_binding(directory,audit):
 manifest,ledger,freeze=read(MANIFEST),read(LEDGER),read(FREEZE)
 require(not (TMP/'freespace-cgroup-trace-bookkeeping-pending.json').exists(),'pending bookkeeping recovery')
 require(manifest.get('status')=='registered' and manifest.get('research_only') is True and manifest.get('product_qualification') is False and digest(FREEZE)==manifest.get('source_hash_manifest_sha256'),'manifest or freeze invalid')
 require(digest(P(__file__))==freeze['admission_helper_sha256'] and digest(PRIOR)==freeze['prior_validator_sha256'] and digest(AUDIT)==freeze['prereg_audit_sha256'] and audit==read(AUDIT),'helper, prior or audit differs from freeze')
 plan=one(manifest['plans'],ORDER[1]);registered=one(ledger['runs'],ORDER[1]);head=freeze['states']['candidate']['head']
 require(plan.get('status')=='completed' and plan.get('conclusion')=='success' and registered.get('status')=='completed' and registered.get('conclusion')=='success' and plan.get('run_id')==registered.get('run_id') and type(plan.get('run_id')) is int and plan.get('revision')==registered.get('revision')==head==manifest.get('candidate_revision'),'screen registration invalid')
 fixed={'baseline':BASE,'comparison':'candidate','operations':['scan'],'files':1000000,'expected_entries':1004499,'pairs_per_operation':3,'subtree_entries':100,'scenario':'unchanged','memory_mib':4096,'setup_memory_mib':4096,'observer_memory_mib':4096,'swap_mib':0,'cpus':2,'workers':1,'target':TARGET,'io':'local','cgroup_trace':'contrast'}
 require(all(plan.get(k)==v and registered.get(k)==v for k,v in fixed.items()),'registered screen case mismatch')
 require(directory.resolve()==(P(plan['artifact_prefix'])/'scan/measurements').resolve(),'unregistered screen artifact path')
 require(command(['git','rev-parse','HEAD'],WT)==head and not command(['git','status','--porcelain','--untracked-files=no'],WT),'screen source head/state mismatch')
 for name,h in freeze['states']['candidate']['tracked_file_sha256'].items():require(digest(WT/name)==h,'screen source changed: '+name)
 require(manifest['screen_calibration_bars']==audit['bars'] and manifest['screen_metric_sources']==audit['metric_sources'] and manifest['arm_orientation']==audit['arm_orientation'] and manifest['screen_interpretation_math']==audit['interpretation_math'],'screen audit binding mismatch')
 sys.path.insert(0,str(WT/'scripts'))
 spec=importlib.util.spec_from_file_location('prior_admission',PRIOR);module=importlib.util.module_from_spec(spec);spec.loader.exec_module(module);module.verify_prior(plan,registered,BINARY)
 raw=read(directory/'manifest.json');require(raw.get('github',{}).get('GITHUB_SHA')==head and str(raw['github'].get('GITHUB_RUN_ID'))==str(plan['run_id']),'screen run identity mismatch')
 for arm,revision in [('baseline-v1',BASE),('candidate-v1',head)]:
  entry=raw['provenance'][arm];build=entry['build'];require(entry['source_revision']==revision and entry['sha256']==BINARY and build['source_revision']==revision and build['sha256']==BINARY and build['target']==TARGET and build['flags']['SOURCE_DATE_EPOCH']==EPOCH,'screen provenance mismatch')
  require(digest(P(plan['binary_artifact_prefix'])/arm.removesuffix('-v1'))==BINARY,'screen downloaded binary mismatch')
 return plan

def evaluate_screen(measurements_dir,audit):
 """Exact screen-only same-pair overhead bars; invalid evidence is inconclusive."""
 try:
  directory=P(measurements_dir);screen_binding(directory,audit)
  sys.path.insert(0,str(WT/'scripts'));from bench_v1_cgroup_diagnostic import analyze
  diagnostic=analyze(directory)
  require(diagnostic.get('valid') is True and diagnostic.get('issues')==[] and diagnostic==read(directory/'diagnostic-summary.json'),'diagnostic validation failed')
  ordinary=diagnostic['ordinary_summary'];require(ordinary==read(directory/'summary.json') and ordinary.get('valid') is True,'ordinary summary mismatch')
  manifest=read(directory/'manifest.json');require(manifest.get('operation')=='scan' and manifest.get('pairs')==3 and manifest.get('files')==1000000 and manifest.get('fixture_receipt',{}).get('expected_entries')==1004499,'not the designated screen')
  require(manifest.get('cgroup_trace_policy')=={'mode':'contrast','baseline-v1':False,'candidate-v1':True},'trace orientation mismatch')
  require(all(manifest['provenance'][arm]['sha256']==BINARY for arm in ('baseline-v1','candidate-v1')),'binary identity mismatch')
  require(audit['arm_orientation']=={'on':'candidate-v1','off':'baseline-v1','pairing':'Match on and off within the same pair.'},'audit orientation mismatch')
  expected_sources={'time':'metrics.json.elapsed_seconds (not time.elapsed_seconds)','rss':'metrics.json.time.peak_rss_kib','total_cgroup':'metrics.json.cgroup_after["memory.peak"]: ASCII decimal string parsed to integer bytes','app_disk':'metrics.json.app_disk_peak_bytes (not incremental filesystem usage)'}
  require(audit['metric_sources']==expected_sources,'audit metric sources mismatch')
  rows=[]
  for i in (1,2,3):
   values=[]
   for arm in ('baseline','candidate'):
    path=directory/f'p{i}-{arm}-v1'/'metrics.json';m=json.loads(path.read_text(),parse_float=Decimal);t=m['elapsed_seconds'];rss=m['time']['peak_rss_kib'];cg=m['cgroup_after']['memory.peak'];disk=m['app_disk_peak_bytes']
    require(type(t) in (int,Decimal) and t>0 and type(rss) is int and rss>=0 and isinstance(cg,str) and cg.isascii() and cg.isdecimal() and type(disk) is int and disk>=0,'invalid metric type')
    values.append((Fraction(t),rss,int(cg),disk))
   off,on=values;rows.append({'pair':i,'time_percent':(on[0]-off[0])*100/off[0],'rss_kib':on[1]-off[1],'cgroup_bytes':on[2]-off[2],'disk_bytes':on[3]-off[3]})
  def median(v):return sorted(v)[1]
  b=audit['bars'];time=[v['time_percent'] for v in rows];rss=[v['rss_kib'] for v in rows];cg=[v['cgroup_bytes'] for v in rows];disk=[v['disk_bytes'] for v in rows]
  checks={'time_median':abs(median(time))<=b['time_absolute_paired_median_percent_max'],'time_worst':max(map(abs,time))<=b['time_worst_absolute_pair_percent_max'],'rss_median':abs(median(rss))<=b['rss_absolute_paired_median_KiB_max'],'rss_worst':max(map(abs,rss))<=b['rss_worst_absolute_pair_KiB_max'],'cgroup_median':max(0,median(cg))<=b['cgroup_positive_paired_median_MiB_max']*1048576,'cgroup_worst':max(0,max(cg))<=b['cgroup_positive_worst_pair_MiB_max']*1048576,'disk_median':median(disk)==b['app_disk_paired_median_bytes'],'disk_worst':max(map(abs,disk))<=b['app_disk_worst_absolute_pair_bytes_max']}
  return {'decision':'pass' if all(checks.values()) else 'fail','checks':checks,'signed_pairs':[dict(v,time_percent=f"{v['time_percent'].numerator}/{v['time_percent'].denominator}") for v in rows],'metric_sources':expected_sources,'interpretation':'instrumentation contrast only; no product gain or H2 waiver'}
 except (OSError,ValueError,KeyError,TypeError,ArithmeticError,ImportError,subprocess.SubprocessError) as e:return {'decision':'inconclusive','error':str(e)}

def validate_previous(smoke,ledger,head,freeze):
 require(smoke.get('status')=='completed' and smoke.get('conclusion')=='success' and smoke.get('revision')==head,'smoke must be complete and same source')
 require(digest(PRIOR)==freeze['prior_validator_sha256'],'prior validator changed')
 spec=importlib.util.spec_from_file_location('prior_admission',PRIOR);module=importlib.util.module_from_spec(spec);spec.loader.exec_module(module)
 module.verify_prior(smoke,one(ledger['runs'],ORDER[0]),BINARY)
 directory=P(smoke['artifact_prefix'])/'scan/measurements';sys.path.insert(0,str(WT/'scripts'))
 from bench_v1_cgroup_diagnostic import analyze
 result=analyze(directory);require(result.get('valid') is True and result.get('issues')==[] and result==read(directory/'diagnostic-summary.json'),'diagnostic raw recomputation mismatch')
 manifest=read(directory/'manifest.json');provenance=manifest['provenance'];require(manifest.get('cgroup_trace_policy')=={'mode':'contrast','baseline-v1':False,'candidate-v1':True},'trace policy mismatch')
 for arm,revision in [('baseline-v1',BASE),('candidate-v1',head)]:
  entry=provenance[arm];build=entry['build'];require(entry['sha256']==BINARY and entry['source_revision']==revision and build['sha256']==BINARY and build['source_revision']==revision and build['target']==TARGET and build['flags']['SOURCE_DATE_EPOCH']==EPOCH,'binary provenance mismatch '+arm)
  require(digest(P(smoke['binary_artifact_prefix'])/arm.removesuffix('-v1'))==BINARY,'downloaded binary mismatch '+arm)
 for ident in manifest['expected_arms']:
  observer=read(directory/ident/'observer.json');require(observer.get('validated') is True and observer.get('current_entries')==100449 and observer.get('previous_entries')==100449,'observer invalid')
  require(observer.get('cgroup_trace_enabled') is None and observer.get('cgroup_trace_receipt') is None and not (directory/ident/'observer-cgroup-trace.jsonl').exists(),'unexpected observer trace')
 return result

def main():
 parser=argparse.ArgumentParser(description=__doc__);parser.add_argument('plan_id',choices=ORDER);parser.add_argument('--dispatch',action='store_true');args=parser.parse_args();lock=None;bookkeeping_lock=None
 if args.dispatch:
  lock=(TMP/'freespace-cgroup-trace-admission.lock').open('a+');fcntl.flock(lock,fcntl.LOCK_EX|fcntl.LOCK_NB)
  bookkeeping_lock=(TMP/'freespace-cgroup-trace-bookkeeping.lock').open('a+');fcntl.flock(bookkeeping_lock,fcntl.LOCK_EX|fcntl.LOCK_NB)
 require(not (TMP/'freespace-cgroup-trace-bookkeeping-pending.json').exists(),'pending bookkeeping recovery')
 manifest,ledger=read(MANIFEST),read(LEDGER)
 require(digest(FREEZE)==manifest.get('source_hash_manifest_sha256'),'source freeze hash mismatch')
 freeze,audit=read(FREEZE),read(AUDIT);plan=one(manifest['plans'],args.plan_id)
 require(manifest.get('status')=='registered' and manifest.get('research_only') is True and manifest.get('product_qualification') is False,'unregistered or non-research manifest')
 require([x.get('id') for x in manifest['plans']]==ORDER and manifest.get('baseline_revision')==BASE and manifest.get('branch')==BRANCH,'manifest identity mismatch')
 require(plan==one(ledger['planned_next_dispatches'],args.plan_id),'manifest and ledger records differ');require(not plan.get('run_id') and not any(x.get('id')==args.plan_id for x in ledger['runs']),'case already registered')
 receipt=TMP/('freespace-'+args.plan_id+'-dispatch.json');require(not receipt.exists(),'existing attempt; inspect it, do not retry')
 require(ledger['aggregate_cap_runner_seconds']==216000 and ledger['maximum_committed_seconds']<=216000 and ledger['remaining_unreserved_seconds']==216000-ledger['maximum_committed_seconds'] and ledger['remaining_unreserved_seconds']>=0,'campaign accounting mismatch');require(ledger['planned_reserved_seconds']==sum(x['maximum_job_seconds'] for x in ledger['planned_next_dispatches']),'reservation mismatch')
 require(not any(x.get('status')=='dispatch_attempted' or x.get('dispatch_outcome','').startswith('unknown') for x in ledger['runs']+ledger['planned_next_dispatches']),'unresolved dispatch attempt')
 run_total=0
 for row in ledger['runs']:
  value=row['completed_job_seconds'] if row.get('status')=='completed' else row['maximum_job_seconds']
  require(type(value) in (int,float) and value>=0,'invalid run accounting');run_total+=value
 require(ledger['maximum_committed_seconds']==run_total+ledger['planned_reserved_seconds'],'committed accounting does not match runs and reservations')
 expected=(100000,100449,1,'smoke',20,3300,900,1170.0) if args.plan_id==ORDER[0] else (1000000,1004499,3,'screen',55,5400,2400,3120.0)
 require(tuple(plan[k] for k in ('files','expected_entries','pairs_per_operation','stage','timeout_minutes','maximum_job_seconds','forecast_seconds','forecast_with_margin_seconds'))==expected,'case/forecast mismatch')
 fixed={'branch':BRANCH,'baseline':BASE,'comparison':'candidate','operations':['scan'],'subtree_entries':100,'scenario':'unchanged','memory_mib':4096,'swap_mib':0,'setup_memory_mib':4096,'observer_memory_mib':4096,'cpus':2,'workers':1,'target':TARGET,'io':'local','scan_profile':'disk','runner_preparation_policy':'sdk-space-v1','measurement_protocol':'v1-single-operation-pairs-v4','cgroup_trace':'contrast','research_only':True,'expected_baseline_sha256':BINARY,'expected_candidate_sha256':BINARY}
 require(all(plan.get(k)==v for k,v in fixed.items()),'fixed protocol mismatch');require(plan['forecast_with_margin_seconds']==plan['forecast_seconds']*1.3 and plan['forecast_with_margin_seconds']<plan['timeout_minutes']*60,'forecast margin or cap mismatch')
 require(audit['pre_data_disposition']['smoke'].startswith('One pair is protocol/trace-validity only') and manifest['screen_calibration_bars']==audit['bars'] and manifest['screen_interpretation_math']==audit['interpretation_math'] and manifest['screen_metric_sources']==audit['metric_sources'] and manifest['arm_orientation']==audit['arm_orientation'],'audit bars mismatch');require(manifest['smoke_numeric_bars'] is None,'smoke is validity only')
 state=freeze['states']['candidate'];head=state['head'];require(re.fullmatch('[0-9a-f]{40}',head or '') is not None and plan['revision']==head and manifest['candidate_revision']==head,'candidate source not frozen');require(freeze['baseline_revision']==BASE and freeze['baseline_source_epoch']==EPOCH and freeze['app_reference_revision']==BASE and freeze['app_equivalence_verified'] is True,'app reference freeze missing')
 require(digest(P(__file__))==freeze['admission_helper_sha256'],'admission helper not frozen');require(digest(PRIOR)==freeze['prior_validator_sha256'],'prior validator changed');require(digest(AUDIT)==freeze['prereg_audit_sha256'],'audit changed')
 review=freeze['source_review'];raw=P(review['raw_path']);prompt=P(review['prompt_path'])
 require(digest(raw)==review['raw_sha256'] and digest(prompt)==review['prompt_sha256'],'source review evidence changed')
 result=read(raw);require(result.get('status')=='completed' and result.get('exit_code')==0 and result.get('is_error') is not True and result.get('result','').strip()=='NO_FINDINGS' and set(result.get('modelUsage',{}))=={'claude-opus-5-5'},'required exact Opus review is not clean')
 review_inputs(prompt.read_text(),review,state)
 reviewed=review['reviewed_file_sha256'];require(isinstance(reviewed,dict) and len(reviewed)==9,'expected exact nine reviewed files')
 changed=set(command(['git','diff','--name-only','4f22bf8e3b67f7f59049a72116b90c061fb1328b',head],WT).splitlines());require(changed==set(reviewed),'review does not cover exact changed files')
 for p,h in reviewed.items():require(state['tracked_file_sha256'].get(p)==h and digest(WT/p)==h,'reviewed source mismatch: '+p)
 require(command(['git','rev-parse','HEAD'],WT)==head and not command(['git','status','--porcelain','--untracked-files=no'],WT),'source head or tracked state changed');require(command(['git','show','-s','--format=%ct',BASE],WT)==EPOCH,'source epoch mismatch')
 paths=set(filter(None,subprocess.check_output(['git','ls-files','-z'],cwd=WT,timeout=60).decode().split('\0')));require(paths==set(state['tracked_file_sha256']),'tracked set mismatch')
 for p,h in state['tracked_file_sha256'].items():require(digest(WT/p)==h,'tracked source changed: '+p)
 base_paths=set(filter(None,subprocess.check_output(['git','ls-tree','-r','--name-only','-z',BASE],cwd=WT,timeout=60).decode().split('\0')))
 root_paths=[p for p in paths|base_paths if '/' not in p and (p in ('Cargo.toml','Cargo.lock','VERSION','Makefile','makefile','GNUmakefile','Justfile','justfile','build.rs') or p.endswith(('.sh','.py','.mk')))]
 app_paths=['core','cli','.cargo','web','Cargo.toml','Cargo.lock','VERSION',*root_paths]
 require(not command(['git','diff','--name-only',BASE,head,'--',*app_paths],WT),'application or root build source differs from baseline')
 sys.path.insert(0,str(WT/'scripts'));from bench_v1_admission import stage_timeouts,qualification_case
 require(stage_timeouts(plan['stage'],plan['timeout_minutes'])['maximum_runner_minutes']*60==plan['maximum_job_seconds'],'job cap mismatch');qualification_case('100','unchanged','4096',['scan'],plan['files'])
 if args.plan_id==ORDER[1]:validate_previous(one(manifest['plans'],ORDER[0]),ledger,head,freeze)
 inputs={'stage':plan['stage'],'operation':'scan','target':TARGET,'subtree_entries':'100','scenario':'unchanged','memory_mib':'4096','io':'local','comparison':'candidate','baseline':BASE,'timeout_minutes':str(plan['timeout_minutes']),'forecast_seconds':'0','forecast_case_id':'','cgroup_trace':'contrast'}
 registrar=TMP/'freespace-register-cgroup-trace.py';require(digest(registrar)==freeze['registrar_sha256'] and review['private_file_sha256'].get(str(registrar))==freeze['registrar_sha256'],'registrar not frozen/reviewed')
 record={'registrar_sha256':freeze['registrar_sha256'],'registrar_contract':'register/refresh/recover with locked atomic journal; actual GitHub run identity verified','plan_id':args.plan_id,'expected_head_sha':head,'expected_both_binary_sha256':BINARY,'source_epoch':EPOCH,'inputs':inputs,'forecast_with_margin_seconds':plan['forecast_with_margin_seconds'],'maximum_job_seconds':plan['maximum_job_seconds'],'research_only':True,'dispatch_attempted_at':dt.datetime.now(dt.timezone.utc).isoformat(),'dispatched':False,'registration':'manual registration required'}
 if not args.dispatch:print(json.dumps({'mode':'dry-run','remote_head':'not checked in dry-run',**record},indent=2));return 0
 with receipt.open('x') as out:out.write(json.dumps(record,indent=2)+'\n');out.flush();os.fsync(out.fileno())
 fsync_dir(receipt.parent)
 try:
  ref='refs/heads/'+BRANCH;rows=command(['git','ls-remote','origin',ref]).splitlines();require(len(rows)==1 and rows[0].split()==[head,ref],'remote head mismatch')
  listing=command(['gh','run','list','--workflow','representative-bench.yml','--branch',BRANCH,'--event','workflow_dispatch','--limit','100','--json','databaseId,headSha,event,createdAt'])
  runs=json.loads(listing);require(isinstance(runs,list) and len(runs)<100,'truncated or invalid GitHub run listing')
  known={x['run_id'] for x in ledger['runs'] if args.plan_id==ORDER[1] and x.get('id')==ORDER[0] and x.get('status')=='completed' and x.get('conclusion')=='success' and type(x.get('run_id')) is int}
  for item in runs:
   require(isinstance(item,dict) and type(item.get('databaseId')) is int and isinstance(item.get('headSha'),str) and item.get('event')=='workflow_dispatch' and isinstance(item.get('createdAt'),str) and item['createdAt'],'malformed GitHub run listing')
   require(item['headSha']!=head or item['databaseId'] in known,'unknown same-head workflow dispatch; inspect before proceeding')
  gh=['gh','workflow','run','representative-bench.yml','--ref',BRANCH]
  for k,v in inputs.items():gh+=['-f',k+'='+v]
  result=subprocess.run(gh,cwd=ROOT,text=True,capture_output=True,timeout=60);record.update(dispatched=True if result.returncode==0 else None,dispatch_exit_code=result.returncode,stdout=result.stdout,stderr=result.stderr)
  if result.returncode!=0:record['dispatch_outcome']='unknown; inspect GitHub; no retry'
 except Exception as error:record.update(dispatched=None,error=type(error).__name__+': '+str(error),dispatch_outcome='unknown; inspect GitHub; no retry')
 with receipt.open('w') as out:out.write(json.dumps(record,indent=2)+'\n');out.flush();os.fsync(out.fileno())
 print(json.dumps(record,indent=2));return 0 if record['dispatched'] else 1
if __name__=='__main__':sys.exit(main())
