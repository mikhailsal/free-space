"""Register or refresh the two cgroup research runs; no workflow dispatch."""
import argparse
import datetime as dt
import fcntl
import hashlib
import json
import os
from pathlib import Path
import re
import subprocess
import tempfile

ROOT = Path('/home/tass/myprojects/corp_v2/free-space')
OUT = ROOT / 'docs/benchmark-results'
MANIFEST = OUT / 'v1-cgroup-memory-trace-manifest-2026-11-01.json'
LEDGER = OUT / 'v1-w1-campaign-2026-10-31.json'
JOURNAL = Path('/tmp/freespace-cgroup-trace-bookkeeping-pending.json')
LOCK = Path('/tmp/freespace-cgroup-trace-bookkeeping.lock')
RECEIPT_DIR = Path('/tmp')
FREEZE = Path('/tmp/freespace-cgroup-trace-all-source-hashes.json')
IDS = ('cgroup-trace-protocol-smoke', 'cgroup-trace-overhead-screen')
BRANCH = 'perf/v1-cgroup-memory-trace'
WORKFLOW = '.github/workflows/representative-bench.yml'
CAP = 216000


def require(condition, message):
    if not condition:
        raise ValueError(message)


def read(path):
    return json.loads(path.read_bytes())


def encoded(value):
    return (json.dumps(value, indent=2, allow_nan=False) + '\n').encode()


def digest(value):
    return hashlib.sha256(value).hexdigest()


def sync_dir(directory):
    fd = os.open(directory, os.O_RDONLY | os.O_DIRECTORY)
    try:
        os.fsync(fd)
    finally:
        os.close(fd)


def atomic_write(path, data):
    fd, temporary = tempfile.mkstemp(prefix='.' + path.name + '.', dir=path.parent)
    try:
        with os.fdopen(fd, 'wb') as out:
            out.write(data)
            out.flush()
            os.fsync(out.fileno())
        os.replace(temporary, path)
        sync_dir(path.parent)
    finally:
        if os.path.exists(temporary):
            os.unlink(temporary)


def recover():
    if not JOURNAL.exists():
        return False
    journal = read(JOURNAL)
    entries = journal['entries']
    require(journal.get('version') == 1 and len(entries) == 3, 'invalid journal')
    paths = [LEDGER, MANIFEST, RECEIPT_DIR / ('freespace-' + journal['plan_id'] + '-dispatch.json')]
    require(journal['plan_id'] in IDS and [entry['path'] for entry in entries] == list(map(str, paths)),
            'journal paths invalid')
    for path, entry in zip(paths, entries):
        new = entry['new'].encode()
        require(digest(new) == entry['new_sha256'] and digest(path.read_bytes()) in
                (entry['old_sha256'], entry['new_sha256']), 'journal conflict: ' + str(path))
    for path, entry in zip(paths, entries):
        if digest(path.read_bytes()) != entry['new_sha256']:
            atomic_write(path, entry['new'].encode())
    JOURNAL.unlink()
    sync_dir(JOURNAL.parent)
    return True


def one(rows, ident):
    found = [row for row in rows if row.get('id') == ident]
    require(len(found) == 1, 'expected exactly one ' + ident)
    return found[0]


def gh_json(args):
    raw = subprocess.check_output(['gh', *args], cwd=ROOT, timeout=60)
    require(len(raw) <= 8 * 1024 * 1024, 'GitHub response too large')
    return json.loads(raw)


def fetch_run(run_id):
    repo = gh_json(['repo', 'view', '--json', 'nameWithOwner'])['nameWithOwner']
    require(re.fullmatch(r'[A-Za-z0-9_.-]+/[A-Za-z0-9_.-]+', repo) is not None, 'invalid repository')
    run = gh_json(['api', f'repos/{repo}/actions/runs/{run_id}'])
    pages = gh_json(['api', '--paginate', '--slurp', f'repos/{repo}/actions/runs/{run_id}/jobs?per_page=100'])
    require(isinstance(pages, list), 'invalid jobs pages')
    jobs = [job for page in pages for job in page['jobs']]
    require(len(jobs) <= 1000, 'too many jobs')
    return run, jobs


def seconds(jobs):
    total = 0.0
    for job in jobs:
        if job.get('status') != 'completed' or job.get('conclusion') == 'skipped':
            continue
        start = dt.datetime.fromisoformat(job['started_at'].replace('Z', '+00:00'))
        end = dt.datetime.fromisoformat(job['completed_at'].replace('Z', '+00:00'))
        require(start.tzinfo is not None and end.tzinfo is not None, 'job timestamps must be aware')
        total += max(0, (end - start).total_seconds())
    return total


def active_seconds(jobs, now):
    total = 0.0
    for job in jobs:
        if job.get('status') != 'in_progress' or not job.get('started_at'):
            continue
        start = dt.datetime.fromisoformat(job['started_at'].replace('Z', '+00:00'))
        require(start.tzinfo is not None, 'job timestamps must be aware')
        total += max(0, (now - start).total_seconds())
    return total


def accounting(ledger):
    require(ledger['aggregate_cap_runner_seconds'] == CAP, 'unexpected aggregate cap')
    planned = sum(p['maximum_job_seconds'] for p in ledger['planned_next_dispatches'])
    completed = sum(p.get('completed_job_seconds', 0) for p in ledger['runs'])
    committed = planned + sum(p['completed_job_seconds'] if p['status'] == 'completed'
                              else p['maximum_job_seconds'] for p in ledger['runs'])
    require(0 <= committed <= CAP, 'aggregate cap exceeded')
    active = sum(p.get('running_job_seconds_observed', 0) for p in ledger['runs'])
    ledger.update(planned_reserved_seconds=planned, completed_job_seconds=completed,
                  running_job_seconds_observed=active, used_runner_seconds_observed=completed + active,
                  maximum_committed_seconds=committed, remaining_unreserved_seconds=CAP - committed)


def update(mode, plan_id, run_id, run, jobs):
    require(plan_id in IDS and type(run_id) is int and run_id > 0, 'invalid case or run')
    ledger, manifest = read(LEDGER), read(MANIFEST)
    require(manifest.get('status') == 'registered' and manifest.get('research_only') is True
            and manifest.get('product_qualification') is False, 'manifest is not registered research')
    freeze_bytes = FREEZE.read_bytes()
    require(digest(freeze_bytes) == manifest.get('source_hash_manifest_sha256'), 'source freeze hash mismatch')
    manifest_plan = one(manifest['plans'], plan_id)
    if mode == 'register':
        plan = one(ledger['planned_next_dispatches'], plan_id)
        require(plan == manifest_plan and plan.get('status') == 'planned', 'planned records differ')
        require(not any(p.get('id') == plan_id or p.get('run_id') == run_id for p in ledger['runs'])
                and run_id not in ledger['run_ids'], 'duplicate case or run')
    else:
        require(mode == 'refresh', 'invalid mode')
        plan = one(ledger['runs'], plan_id)
        require(plan == manifest_plan and plan.get('run_id') == run_id, 'registered records differ')
        require(ledger['run_ids'].count(run_id) == 1, 'run id ledger mismatch')
    revision = plan.get('revision')
    freeze = json.loads(freeze_bytes)
    require(digest(Path(__file__).read_bytes()) == freeze.get('registrar_sha256'), 'registrar hash mismatch')
    require(isinstance(revision, str) and re.fullmatch('[0-9a-f]{40}', revision) is not None
            and freeze['states']['candidate']['head'] == revision
            and plan.get('branch') == BRANCH and manifest.get('candidate_revision') == revision,
            'frozen plan identity invalid')
    require(type(run.get('id')) is int and run.get('id') == run_id and run.get('head_sha') == revision and run.get('head_branch') == BRANCH
            and run.get('event') == 'workflow_dispatch' and run.get('path') == WORKFLOW
            and type(run.get('run_attempt')) is int and run['run_attempt'] == 1, 'GitHub run identity mismatch')
    require(run.get('status') in ('queued', 'in_progress', 'completed', 'waiting', 'pending', 'requested')
            and isinstance(run.get('created_at'), str) and run['created_at'], 'invalid GitHub run status')
    if run['status'] == 'completed':
        require(len(jobs) == 2 and {job.get('name') for job in jobs} == {'build', 'paired'}
                and all(job.get('status') == 'completed' for job in jobs),
                'terminal run jobs incomplete')
    if mode == 'refresh':
        require(plan['created_at'] == run['created_at'], 'run creation time changed')
        if plan['status'] == 'completed':
            require(run['status'] == 'completed' and plan['conclusion'] == run['conclusion'], 'completed run changed')
    receipt_path = RECEIPT_DIR / ('freespace-' + plan_id + '-dispatch.json')
    receipt = read(receipt_path)
    require('dispatched' in receipt and receipt.get('plan_id') == plan_id and receipt.get('expected_head_sha') == revision
            and receipt.get('dispatched') is not False and receipt.get('dispatch_attempted_at'),
            'dispatch receipt mismatch')
    require(receipt.get('run_id') in (None, run_id), 'receipt run id mismatch')
    now = dt.datetime.now(dt.timezone.utc)
    active = active_seconds(jobs, now) if run['status'] != 'completed' else 0
    plan.update(run_id=run_id, created_at=run['created_at'], status=run['status'], conclusion=run['conclusion'],
                head_sha_verified=True, completed_job_seconds=seconds(jobs),
                running_job_seconds_observed=active, usage_observed_at=now.isoformat())
    if run['status'] == 'completed':
        plan['job_seconds'] = plan['completed_job_seconds']
    if mode == 'register':
        ledger['runs'].append(plan.copy())
        ledger['run_ids'].append(run_id)
        ledger['planned_next_dispatches'] = [p for p in ledger['planned_next_dispatches'] if p['id'] != plan_id]
    manifest_plan.update(plan)
    accounting(ledger)
    now_text = now.isoformat()
    ledger['updated_at'] = manifest['updated_at'] = now_text
    receipt.update(run_id=run_id, registration_head_sha=revision, registration_verified_at=now_text,
                   registration_run_status=run['status'])
    states = [(LEDGER, ledger), (MANIFEST, manifest), (receipt_path, receipt)]
    entries = []
    for path, state in states:
        old, new = path.read_bytes(), encoded(state)
        entries.append({'path': str(path), 'old_sha256': digest(old), 'new_sha256': digest(new), 'new': new.decode()})
    require(not JOURNAL.exists(), 'pending journal exists')
    atomic_write(JOURNAL, encoded({'version': 1, 'plan_id': plan_id, 'entries': entries}))
    recover()
    return {'run_id': run_id, 'plan_id': plan_id, 'status': run['status'],
            'maximum_committed_seconds': ledger['maximum_committed_seconds']}


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument('mode', choices=('register', 'refresh', 'recover'))
    parser.add_argument('plan_id', nargs='?', choices=IDS)
    parser.add_argument('run_id', nargs='?', type=int)
    args = parser.parse_args()
    with LOCK.open('a+') as lock:
        fcntl.flock(lock, fcntl.LOCK_EX | fcntl.LOCK_NB)
        recovered = recover()
        if args.mode == 'recover':
            require(args.plan_id is None and args.run_id is None, 'recover takes no arguments')
            print(json.dumps({'recovered': recovered}))
            return
        require(args.plan_id is not None and args.run_id is not None, 'case and run required')
        run, jobs = fetch_run(args.run_id)
        print(json.dumps(update(args.mode, args.plan_id, args.run_id, run, jobs)))


if __name__ == '__main__':
    main()
