# v1-single-operation-pairs-v4

Case: {"case_policy": "qualification-v1", "memory_mib": 1024, "mutation_receipt": null, "observer_memory_mib": 4096, "scenario": "unchanged", "setup_memory_mib": 4096, "subtree_entries": 100}


Descriptive paired results; no automatic promotion or uncertainty estimate.
Application disk peak is sampled; RSS excludes the observer.

| Pair | Elapsed baseline → candidate (s) | RSS baseline → candidate (MiB) | App disk baseline → candidate (GiB) |
|---:|---:|---:|---:|
| 1 | 79.367 → 78.527 (Δ -0.841) | 36.531 → 35.707 (Δ -0.824) | 0.428 → 0.428 (Δ -0.000) |
| 2 | 79.740 → 78.022 (Δ -1.718) | 36.262 → 36.453 (Δ +0.191) | 0.428 → 0.428 (Δ +0.000) |
| 3 | 85.844 → 71.809 (Δ -14.036) | 34.676 → 36.469 (Δ +1.793) | 0.428 → 0.428 (Δ +0.000) |

Identical binaries: observed maximum absolute paired differences (descriptive band):
- elapsed_seconds: median Δ -1.718; max |Δ| 14.036
- peak_rss_kib: median Δ +196.000; max |Δ| 1836.000
- app_disk_peak_bytes: median Δ +12288.000; max |Δ| 12288.000

VALID
