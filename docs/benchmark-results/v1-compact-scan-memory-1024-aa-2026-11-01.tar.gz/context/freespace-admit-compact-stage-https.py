"""One-shot compact-stage admission; dry-run by default, no automatic retries."""
import argparse
import datetime as dt
import fcntl
import hashlib
import json
import os
from pathlib import Path
import subprocess
import sys

ROOT = Path('/home/tass/myprojects/corp_v2/free-space')
OUT = ROOT / 'docs/benchmark-results'
TMP = Path('/tmp')
MANIFEST = OUT / 'v1-compact-stage-https-manifest-2026-11-01.json'
LEDGER = OUT / 'v1-w1-campaign-2026-10-31.json'
BASE = 'e8265778ef78ec4acd9da1375eedb0be37a123f5'
CANDIDATE = '471c4d14ed4881106ce1d0b6cd5d6361839b2bc8'
CONTROL = '4f22bf8e3b67f7f59049a72116b90c061fb1328b'
BASE_BIN = 'ed2a1cb138b1e48e70a388a4a8fda3e79fcfd2e37fd0c061d41d2d6363f8e980'
ORDER = ['compact-stage-https-changed-full-smoke', 'compact-stage-https-matched-control-screen', 'compact-stage-https-candidate-screen']
TREES = {'8m_primary': TMP / 'free-space-v1-memory-candidate-default-cache',
         'control': TMP / 'free-space-v1-memory-candidate-control'}

def read(path):
    return json.loads(path.read_text())

def require(ok, message):
    if not ok:
        raise ValueError(message)

def one(rows, ident):
    matches = [row for row in rows if row.get('id') == ident]
    require(len(matches) == 1, ident + ': expected exactly one record')
    return matches[0]

def verify_prior(plan, registered, candidate_bin):
    require(plan.get('run_id') == registered.get('run_id') and plan.get('conclusion') == 'success'
            and registered.get('conclusion') == 'success' and plan.get('status') == 'completed'
            and registered.get('status') == 'completed', 'prior run not completed successfully')
    prefix = Path(plan['artifact_prefix'])
    gh = read(Path(str(prefix) + '-github.json'))
    require(gh.get('headSha') == plan['revision'] and gh.get('conclusion') == 'success'
            and gh.get('status') == 'completed', 'prior GitHub identity/state invalid')
    require({j.get('name') for j in gh['jobs']} == {'build', 'paired'}
            and all(j.get('conclusion') == 'success' for j in gh['jobs']), 'prior jobs invalid')
    if gh.get('databaseId') is not None:
        require(gh['databaseId'] == plan['run_id'], 'prior run ID mismatch')
    from bench_v1_summary import summarize
    from bench_v1_profile import analyze
    for operation in plan['operations']:
        directory = prefix / operation / 'measurements'
        raw, checked = read(directory / 'summary.json'), summarize(directory)
        require(raw == checked and checked.get('valid') is True and not checked.get('issues')
                and len(checked.get('pairs', [])) == plan['pairs_per_operation'], 'prior strict summary invalid')
        manifest = read(directory / 'manifest.json')
        require(manifest.get('github', {}).get('GITHUB_SHA') == plan['revision']
                and str(manifest['github'].get('GITHUB_RUN_ID')) == str(plan['run_id']), 'prior artifact GitHub mismatch')
        for key in ('operation', 'scenario', 'memory_mib', 'files', 'subtree_entries'):
            require(manifest.get(key) == (operation if key == 'operation' else plan[key]), 'prior case mismatch: ' + key)
        require(manifest.get('pairs') == plan['pairs_per_operation']
                and manifest.get('fixture_receipt', {}).get('expected_entries') == plan['expected_entries'], 'prior fixture size mismatch')
        prov = manifest['provenance']
        require(prov['baseline-v1']['source_revision'] == BASE and prov['baseline-v1']['sha256'] == BASE_BIN,
                'prior baseline actual binary mismatch')
        observed = prov['candidate-v1']['sha256']
        require(prov['candidate-v1']['source_revision'] == plan['revision']
                and observed == (BASE_BIN if plan['revision'] == CONTROL else candidate_bin),
                'prior candidate actual binary mismatch')
        expected_arms = {f'p{i}-{arm}-v1' for i in range(1, plan['pairs_per_operation'] + 1)
                         for arm in ('baseline', 'candidate')}
        require(set(manifest['expected_arms']) == expected_arms, 'prior arm set mismatch')
        for arm in expected_arms:
            row = read(directory / arm / 'metrics.json')
            events = dict(line.split() for line in row['cgroup_after']['memory.events'].splitlines())
            require(row.get('exit_code') == 0 and row.get('timed_out') is False and row.get('validated') is True
                    and row.get('memory_mib') == plan['memory_mib']
                    and all(events.get(k) == '0' for k in ('oom', 'oom_kill', 'oom_group_kill')), 'prior worker failure or OOM')
        if operation == 'refresh':
            profile = analyze(directory)
            require(profile.get('valid_structure') is True and not profile.get('issues'), 'prior profile structure invalid')
    return True

def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument('plan_id', choices=ORDER)
    parser.add_argument('--dispatch', action='store_true')
    args = parser.parse_args()
    lock = None
    if args.dispatch:
        lock = open('/tmp/freespace-compact-stage-admission.lock', 'a+')
        fcntl.flock(lock, fcntl.LOCK_EX | fcntl.LOCK_NB)
    manifest, ledger = read(MANIFEST), read(LEDGER)
    plan = one(manifest['plans'], args.plan_id)
    require(plan == one(ledger['planned_next_dispatches'], args.plan_id), 'ledger and preregistration differ')
    require(not plan.get('run_id') and not any(r.get('id') == args.plan_id for r in ledger['runs']), 'case already registered')
    receipt_path = TMP / ('freespace-' + args.plan_id + '-dispatch.json')
    require(not receipt_path.exists(), 'existing attempt; inspect rather than retry')
    require(ledger['aggregate_cap_runner_seconds'] == 216000
            and ledger['maximum_committed_seconds'] <= 216000
            and ledger['remaining_unreserved_seconds'] == 216000 - ledger['maximum_committed_seconds']
            and ledger['remaining_unreserved_seconds'] >= 0, 'campaign cap invalid')
    require(ledger['planned_reserved_seconds'] == sum(p['maximum_job_seconds'] for p in ledger['planned_next_dispatches']), 'reservation mismatch')
    freeze = read(TMP / 'freespace-integrated-https-all-source-hashes.json')
    for key, tree in TREES.items():
        expected_head = CANDIDATE if key == '8m_primary' else CONTROL
        head = subprocess.check_output(['git', 'rev-parse', 'HEAD'], cwd=tree, text=True).strip()
        require(head == expected_head, 'published source head changed')
        for name, digest in freeze['states'][key]['tracked_file_sha256'].items():
            require(hashlib.sha256((tree / name).read_bytes()).hexdigest() == digest, 'source hash mismatch: ' + name)
        ref = 'refs/heads/' + plan['branch'] if plan['revision'] == expected_head else 'refs/heads/' + ('perf/v1-memory-candidate-default-cache' if key == '8m_primary' else 'perf/v1-memory-candidate-control')
        rows = subprocess.check_output(['git', 'ls-remote', 'origin', ref], cwd=ROOT, text=True).splitlines()
        require(len(rows) == 1 and rows[0].split() == [expected_head, ref], 'published remote changed')
    sys.path.insert(0, str(TREES['8m_primary'] / 'scripts'))
    from bench_v1_admission import stage_timeouts, qualification_case, validate_changed_full_baseline
    require(plan['baseline'] == BASE and plan['comparison'] == 'candidate'
            and plan['target'] == 'x86_64-unknown-linux-musl' and plan['io'] == 'local'
            and plan['cpus'] == 2 and plan['workers'] == 1
            and plan['runner_preparation_policy'] == 'sdk-space-v1', 'unexpected case envelope')
    timeouts = stage_timeouts(plan['stage'], plan['timeout_minutes'])
    require(timeouts['maximum_runner_minutes'] * 60 == plan['maximum_job_seconds'], 'job maximum mismatch')
    require(plan['forecast_seconds'] * 1.3 == plan['forecast_with_margin_seconds']
            and plan['forecast_with_margin_seconds'] < timeouts['step_minutes'] * 60, 'forecast does not fit')
    qualification_case(str(plan['subtree_entries']), plan['scenario'], str(plan['memory_mib']), plan['operations'], plan['files'])
    validate_changed_full_baseline(plan['scenario'], plan['comparison'], plan['baseline'])
    candidate_bin = None
    if args.plan_id != ORDER[0]:
        smoke = one(manifest['plans'], ORDER[0])
        prov = read(Path(smoke['artifact_prefix']) / 'refresh/measurements/manifest.json')['provenance']
        candidate_bin = prov['candidate-v1']['sha256']
    for ident in ORDER[:ORDER.index(args.plan_id)]:
        previous = one(manifest['plans'], ident)
        verify_prior(previous, one(ledger['runs'], ident), candidate_bin)
    inputs = dict(stage=plan['stage'], operation=plan['operations'][0] if len(plan['operations']) == 1 else 'auto',
                  target=plan['target'], subtree_entries=str(plan['subtree_entries']), scenario=plan['scenario'],
                  memory_mib=str(plan['memory_mib']), io=plan['io'], comparison='candidate', baseline=BASE,
                  timeout_minutes=str(plan['timeout_minutes']), forecast_seconds='0', forecast_case_id='')
    now = dt.datetime.now(dt.timezone.utc).isoformat()
    receipt = dict(plan_id=args.plan_id, expected_head_sha=plan['revision'], inputs=inputs,
                   source_hashes_verified=True, forecast_with_margin_seconds=plan['forecast_with_margin_seconds'],
                   maximum_job_seconds=plan['maximum_job_seconds'], campaign_remaining_unreserved_seconds=ledger['remaining_unreserved_seconds'],
                   dispatch_attempted_at=now, dispatched=False, registration='separate manual registration required')
    if not args.dispatch:
        print(json.dumps(dict(mode='dry-run', **receipt), indent=2)); return
    with receipt_path.open('x') as out:
        out.write(json.dumps(receipt, indent=2) + '\n'); out.flush(); os.fsync(out.fileno())
    for obj in (plan, one(ledger['planned_next_dispatches'], args.plan_id)):
        obj.update(status='dispatch_attempted', admitted_at=now, dispatch_receipt=str(receipt_path))
    manifest['updated_at'] = now; ledger['updated_at'] = now
    MANIFEST.write_text(json.dumps(manifest, indent=2) + '\n')
    LEDGER.write_text(json.dumps(ledger, indent=2) + '\n')
    command = ['gh', 'workflow', 'run', 'representative-bench.yml', '--ref', plan['branch']]
    for key, value in inputs.items():
        command += ['-f', key + '=' + value]
    result = subprocess.run(command, cwd=ROOT, text=True, capture_output=True)
    receipt.update(dispatched=result.returncode == 0, dispatch_exit_code=result.returncode,
                   stdout=result.stdout, stderr=result.stderr)
    receipt_path.write_text(json.dumps(receipt, indent=2) + '\n')
    print(json.dumps(receipt, indent=2))
    raise SystemExit(result.returncode)

if __name__ == '__main__':
    main()
