# Proposed compact-source scan memory ladder

This is a proposal only. Four scan-only 1m-file cases would test whether the new compact candidate has a higher minimum *tested successful* budget under D3. Previous 512 MiB success used older 0adc/f0 sources and does not establish capacity for the new binary. The 8 MiB candidate remains unpromoted.

| Order | Case | 1m worker limit | Head | Comparison | Gate |
| --- | --- | ---: | --- | --- | --- |
| 1 | control-1024 | 1 GiB | `4f22bf8` | A/A | Fresh 4 GiB A/A valid; live admission |
| 2 | candidate-1024 | 1 GiB | `471c4d` | baseline vs candidate | Case 1 valid; current 4 GiB candidate screen valid and useful with no confirmed regression |
| 3 | control-512 | 512 MiB | `4f22bf8` | A/A | Candidate 1024 valid; fresh control before candidate; live admission |
| 4 | candidate-512 | 512 MiB | `471c4d` | baseline vs candidate | Cases 2 and 3 valid; live admission |

Each case has three scan pairs, one worker, two CPUs, no swap, 4 GiB setup/observers, musl/local I/O, and the unchanged 100-entry fixture setting. The exact expected hashes and source-manifest hash are in the companion JSON. Any ordinary OOM, timeout, invalid semantics or cleanup failure stops descent; D11's expected-OOM exception does not apply. Confirmed D2–D6 regression stops candidate progression. A successful 512 MiB run is still floor-censored and establishes no full-scale capacity or code RAM benefit by itself.

The proposed 1,949-second whole-step allowance plus 30% is 2,533.7 seconds, below the 3,300-second step cap. For context, the fresh 4 GiB A/A paired job took 1,256 seconds for both scan and refresh, while older-source scan-only 1 GiB jobs took 645 and 768 seconds and 512 MiB jobs took 908 and 847 seconds. These are cross-run and partly cross-source timing observations, not proof of the new candidate's behavior; recheck the forecast against its completed 4 GiB screen. Each case reserves at most 5,400 aggregate runner-seconds, or 21,600 total. The current ledger snapshot has sufficient unreserved capacity, but this proposal reserves nothing and the live ledger and active jobs must be checked again before registration or dispatch.
