"""One-shot scan memory ladder admission; dry-run default, explicit dispatch only."""
import argparse
import datetime as dt
import fcntl
import hashlib
import importlib.util
import json
import os
from pathlib import Path
import subprocess
import sys

ROOT = Path('/home/tass/myprojects/corp_v2/free-space')
OUT = ROOT / 'docs/benchmark-results'
TMP = Path('/tmp')
MANIFEST = OUT / 'v1-compact-stage-scan-memory-manifest-2026-11-01.json'
PREVIOUS = OUT / 'v1-compact-stage-https-manifest-2026-11-01.json'
LEDGER = OUT / 'v1-w1-campaign-2026-10-31.json'
FREEZE = TMP / 'freespace-integrated-https-all-source-hashes.json'
PRIOR_HELPER = TMP / 'freespace-admit-compact-stage-https.py'
BASE = 'e8265778ef78ec4acd9da1375eedb0be37a123f5'
CONTROL = '4f22bf8e3b67f7f59049a72116b90c061fb1328b'
CANDIDATE = '471c4d14ed4881106ce1d0b6cd5d6361839b2bc8'
BASE_BIN = 'ed2a1cb138b1e48e70a388a4a8fda3e79fcfd2e37fd0c061d41d2d6363f8e980'
CANDIDATE_BIN = '2d2fd14fc97dcdc3737523a0ec24616448b2315f2c6ae2d9cb95718515d18c5b'
ORDER = ['compact-scan-memory-1024-aa', 'compact-scan-memory-1024-candidate',
         'compact-scan-memory-512-aa', 'compact-scan-memory-512-candidate']
TREES = {'8m_primary': TMP / 'free-space-v1-memory-candidate-default-cache',
         'control': TMP / 'free-space-v1-memory-candidate-control'}


def read(path):
    return json.loads(path.read_text())


def require(ok, message):
    if not ok:
        raise ValueError(message)


def one(rows, ident):
    result = [x for x in rows if x.get('id') == ident]
    require(len(result) == 1, ident + ': expected exactly one record')
    return result[0]


def pair_seconds(plan):
    gh = read(Path(plan['artifact_prefix'] + '-github.json'))
    jobs = [j for j in gh['jobs'] if j['name'] == 'paired']
    require(len(jobs) == 1, 'missing paired job duration')
    parse = lambda s: dt.datetime.fromisoformat(s.replace('Z', '+00:00'))
    seconds = (parse(jobs[0]['completedAt']) - parse(jobs[0]['startedAt'])).total_seconds()
    require(0 < seconds <= plan['maximum_job_seconds'], 'invalid prior paired duration')
    return seconds


def validate_plan(plan, ident):
    is_candidate = ident.endswith('-candidate')
    expected = {'id': ident, 'scientific_kind': 'candidate' if is_candidate else 'AA',
                'branch': 'perf/v1-memory-candidate-default-cache' if is_candidate else 'perf/v1-memory-candidate-control',
                'revision': CANDIDATE if is_candidate else CONTROL, 'baseline': BASE,
                'comparison': 'candidate', 'stage': 'screen', 'files': 1000000,
                'expected_entries': 1004499, 'pairs_per_operation': 3, 'operations': ['scan'],
                'subtree_entries': 100, 'scenario': 'unchanged',
                'memory_mib': 1024 if '-1024-' in ident else 512,
                'setup_memory_mib': 4096, 'observer_memory_mib': 4096, 'cpus': 2, 'workers': 1,
                'target': 'x86_64-unknown-linux-musl', 'io': 'local', 'scan_profile': 'disk',
                'swap': 'disabled', 'runner_preparation_policy': 'sdk-space-v1',
                'measurement_protocol': 'v1-single-operation-pairs-v4', 'timeout_minutes': 55,
                'maximum_job_seconds': 5400, 'forecast_seconds': 2156,
                'forecast_with_margin_seconds': 2802.8, 'expected_baseline_sha256': BASE_BIN,
                'expected_candidate_sha256': CANDIDATE_BIN if is_candidate else BASE_BIN,
                'artifact_prefix': '/tmp/freespace-' + ident}
    for key, value in expected.items():
        require(type(plan.get(key)) is type(value) and plan[key] == value, ident + ': bad ' + key)
    require(plan.get('status') == 'planned' and not plan.get('run_id'), 'case not planned')
    if is_candidate:
        require(plan.get('advance_disposition') == 'approved', 'explicit parent advance disposition required')
    else:
        require(plan.get('advance_disposition') == 'not_required', 'invalid control disposition')


def verify_local_sources(manifest):
    require(hashlib.sha256(FREEZE.read_bytes()).hexdigest() == manifest['source_hash_manifest_sha256'],
            'source manifest changed')
    frozen = read(FREEZE)
    for key, tree in TREES.items():
        expected = CANDIDATE if key == '8m_primary' else CONTROL
        head = subprocess.check_output(['git', 'rev-parse', 'HEAD'], cwd=tree, text=True).strip()
        require(head == expected, 'local source head changed')
        for name, digest in frozen['states'][key]['tracked_file_sha256'].items():
            file = tree / name
            require(file.is_file() and not file.is_symlink() and hashlib.sha256(file.read_bytes()).hexdigest() == digest,
                    'source hash mismatch: ' + name)


def verify_remotes():
    for key, tree in TREES.items():
        expected = CANDIDATE if key == '8m_primary' else CONTROL
        branch = 'perf/v1-memory-candidate-default-cache' if key == '8m_primary' else 'perf/v1-memory-candidate-control'
        ref = 'refs/heads/' + branch
        rows = subprocess.check_output(['git', 'ls-remote', '--heads', 'origin', ref], cwd=ROOT, text=True).splitlines()
        require(len(rows) == 1 and rows[0].split() == [expected, ref], 'published remote changed')


def sync_write(file, value):
    file.seek(0)
    file.write(json.dumps(value, indent=2) + '\n')
    file.truncate()
    file.flush()
    os.fsync(file.fileno())


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument('plan_id', choices=ORDER)
    parser.add_argument('--dispatch', action='store_true')
    args = parser.parse_args()
    lock = None
    if args.dispatch:
        lock = open('/tmp/freespace-compact-scan-memory-admission.lock', 'a+')
        fcntl.flock(lock, fcntl.LOCK_EX | fcntl.LOCK_NB)
    manifest, ledger, previous = read(MANIFEST), read(LEDGER), read(PREVIOUS)
    require(manifest.get('schema') == 'compact-scan-memory-ladder-v1' and manifest.get('status') == 'registered',
            'manifest not registered')
    require(manifest.get('maximum_reserved_seconds') == 21600, 'incorrect ladder maximum')
    require([p['id'] for p in manifest['plans']] == ORDER, 'unexpected plan order')
    plan = one(manifest['plans'], args.plan_id)
    validate_plan(plan, args.plan_id)
    require(plan == one(ledger['planned_next_dispatches'], args.plan_id), 'ledger and manifest plan differ')
    require(not any(r.get('id') == args.plan_id for r in ledger['runs']), 'case already registered as run')
    receipt_path = TMP / ('freespace-' + args.plan_id + '-dispatch.json')
    require(not receipt_path.exists(), 'attempt already exists; no retry')
    require(ledger.get('aggregate_cap_runner_seconds') == 216000
            and type(ledger.get('maximum_committed_seconds')) in (int, float)
            and ledger['maximum_committed_seconds'] <= 216000
            and ledger.get('remaining_unreserved_seconds') == 216000 - ledger['maximum_committed_seconds']
            and ledger['remaining_unreserved_seconds'] >= 0, 'campaign cap invalid')
    require(ledger.get('planned_reserved_seconds') == sum(p['maximum_job_seconds'] for p in ledger['planned_next_dispatches']),
            'reservation mismatch')
    for ident in ORDER:
        p = one(manifest['plans'], ident)
        if p.get('status') == 'planned':
            require(p == one(ledger['planned_next_dispatches'], ident), 'unreserved ladder case: ' + ident)
    require(manifest.get('source_hash_manifest') == str(FREEZE), 'incorrect source manifest path')
    require(manifest.get('prior_verifier', {}).get('path') == str(PRIOR_HELPER)
            and hashlib.sha256(PRIOR_HELPER.read_bytes()).hexdigest() == manifest['prior_verifier'].get('sha256'),
            'prior verifier changed')
    verify_local_sources(manifest)
    sys.path.insert(0, str(TREES['8m_primary'] / 'scripts'))
    spec = importlib.util.spec_from_file_location('compact_prior_verifier', PRIOR_HELPER)
    module = importlib.util.module_from_spec(spec)
    spec.loader.exec_module(module)
    prior_ids = ['compact-stage-https-changed-full-smoke', 'compact-stage-https-matched-control-screen']
    if args.plan_id.endswith('-candidate') or ORDER.index(args.plan_id) >= 2:
        prior_ids.append('compact-stage-https-candidate-screen')
    prior = []
    for ident in prior_ids:
        p = one(previous['plans'], ident)
        module.verify_prior(p, one(ledger['runs'], ident), CANDIDATE_BIN)
        prior.append(p)
    for ident in ORDER[:ORDER.index(args.plan_id)]:
        p = one(manifest['plans'], ident)
        module.verify_prior(p, one(ledger['runs'], ident), CANDIDATE_BIN)
        prior.append(p)
    from bench_v1_admission import stage_timeouts, qualification_case
    timeouts = stage_timeouts(plan['stage'], str(plan['timeout_minutes']))
    require(timeouts['step_minutes'] == 55 and timeouts['maximum_runner_minutes'] * 60 == 5400, 'workflow cap mismatch')
    qualification_case('100', 'unchanged', str(plan['memory_mib']), ['scan'], 1000000)
    forecast = max(2156, max(pair_seconds(p) for p in prior) + 900)
    require(forecast * 1.3 < 3300, 'updated prior-duration forecast exceeds fixed step cap')
    inputs = dict(stage='screen', operation='scan', target=plan['target'], subtree_entries='100',
                  scenario='unchanged', memory_mib=str(plan['memory_mib']), io='local', comparison='candidate',
                  baseline=BASE, timeout_minutes='55', forecast_seconds='0', forecast_case_id='')
    now = dt.datetime.now(dt.timezone.utc).isoformat()
    receipt = dict(plan_id=args.plan_id, expected_head_sha=plan['revision'], inputs=inputs,
                   forecast_seconds=forecast, forecast_with_margin_seconds=forecast * 1.3,
                   maximum_job_seconds=5400, source_hashes_verified=True,
                   dispatch_attempted_at=now, dispatched=False, registration='manual run registration required')
    if not args.dispatch:
        verify_remotes()
        print(json.dumps(dict(mode='dry-run', **receipt), indent=2))
        return
    # Exclusive and durable before ANY network call in dispatch mode. If later
    # validation or dispatch fails, leave the receipt to block automatic retry.
    with receipt_path.open('x+') as out:
        sync_write(out, receipt)
        parent_fd = os.open(receipt_path.parent, os.O_RDONLY | os.O_DIRECTORY)
        try:
            os.fsync(parent_fd)
        finally:
            os.close(parent_fd)
        verify_remotes()
        command = ['gh', 'workflow', 'run', 'representative-bench.yml', '--ref', plan['branch']]
        for key, value in inputs.items():
            command += ['-f', key + '=' + value]
        result = subprocess.run(command, cwd=ROOT, text=True, capture_output=True, timeout=60)
        receipt.update(dispatched=result.returncode == 0, dispatch_exit_code=result.returncode,
                       stdout=result.stdout, stderr=result.stderr)
        sync_write(out, receipt)
    print(json.dumps(receipt, indent=2))
    raise SystemExit(result.returncode)


if __name__ == '__main__':
    main()
