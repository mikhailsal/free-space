# v1-single-operation-pairs-v3

Descriptive paired results; no automatic promotion or uncertainty estimate.
Application disk peak is sampled; RSS excludes the observer.

| Pair | Elapsed baseline → candidate (s) | RSS baseline → candidate (MiB) | App disk baseline → candidate (GiB) |
|---:|---:|---:|---:|
| 1 | 9.574 → 9.594 (Δ +0.020) | 367.734 → 367.859 (Δ +0.125) | 0.349 → 0.349 (Δ +0.000) |
| 2 | 9.620 → 9.637 (Δ +0.017) | 367.977 → 367.977 (Δ +0.000) | 0.349 → 0.349 (Δ +0.000) |
| 3 | 9.665 → 9.656 (Δ -0.009) | 368.008 → 367.891 (Δ -0.117) | 0.349 → 0.349 (Δ +0.000) |

Identical binaries: observed maximum absolute paired differences (descriptive band):
- elapsed_seconds: median Δ +0.017; max |Δ| 0.020
- peak_rss_kib: median Δ +0.000; max |Δ| 128.000
- app_disk_peak_bytes: median Δ +0.000; max |Δ| 0.000

VALID
