# v1-single-operation-pairs-v3

Descriptive paired results; no automatic promotion or uncertainty estimate.
Application disk peak is sampled; RSS excludes the observer.

| Pair | Elapsed baseline → candidate (s) | RSS baseline → candidate (MiB) | App disk baseline → candidate (GiB) |
|---:|---:|---:|---:|
| 1 | 55.244 → 55.384 (Δ +0.141) | 36.656 → 36.738 (Δ +0.082) | 0.430 → 0.430 (Δ +0.000) |
| 2 | 54.992 → 55.270 (Δ +0.278) | 36.738 → 36.820 (Δ +0.082) | 0.430 → 0.430 (Δ +0.000) |
| 3 | 55.254 → 54.589 (Δ -0.665) | 36.703 → 36.645 (Δ -0.059) | 0.430 → 0.430 (Δ +0.000) |

Identical binaries: observed maximum absolute paired differences (descriptive band):
- elapsed_seconds: median Δ +0.141; max |Δ| 0.665
- peak_rss_kib: median Δ +84.000; max |Δ| 84.000
- app_disk_peak_bytes: median Δ +0.000; max |Δ| 4096.000

VALID
