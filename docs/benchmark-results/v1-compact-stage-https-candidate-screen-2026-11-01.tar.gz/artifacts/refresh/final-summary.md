# v1-single-operation-pairs-v4

Case: {"case_policy": "qualification-v1", "memory_mib": 4096, "mutation_receipt": null, "observer_memory_mib": 4096, "scenario": "unchanged", "setup_memory_mib": 4096, "subtree_entries": 100}


Descriptive paired results; no automatic promotion or uncertainty estimate.
Application disk peak is sampled; RSS excludes the observer.

| Pair | Elapsed baseline → candidate (s) | RSS baseline → candidate (MiB) | App disk baseline → candidate (GiB) |
|---:|---:|---:|---:|
| 1 | 10.698 → 10.707 (Δ +0.009) | 369.145 → 281.066 (Δ -88.078) | 0.349 → 0.349 (Δ +0.000) |
| 2 | 10.636 → 10.661 (Δ +0.025) | 369.078 → 281.180 (Δ -87.898) | 0.349 → 0.349 (Δ +0.000) |
| 3 | 10.688 → 10.725 (Δ +0.037) | 369.117 → 281.180 (Δ -87.938) | 0.349 → 0.349 (Δ +0.000) |

VALID
