# v1-single-operation-pairs-v4

Case: {"case_policy": "qualification-v1", "memory_mib": 4096, "mutation_receipt": null, "observer_memory_mib": 4096, "scenario": "unchanged", "setup_memory_mib": 4096, "subtree_entries": 100}


Descriptive paired results; no automatic promotion or uncertainty estimate.
Application disk peak is sampled; RSS excludes the observer.

| Pair | Elapsed baseline → candidate (s) | RSS baseline → candidate (MiB) | App disk baseline → candidate (GiB) |
|---:|---:|---:|---:|
| 1 | 65.974 → 47.368 (Δ -18.606) | 36.863 → 36.465 (Δ -0.398) | 0.430 → 0.426 (Δ -0.004) |
| 2 | 65.875 → 47.489 (Δ -18.386) | 36.977 → 36.730 (Δ -0.246) | 0.430 → 0.426 (Δ -0.004) |
| 3 | 65.850 → 47.518 (Δ -18.332) | 36.969 → 36.531 (Δ -0.438) | 0.430 → 0.426 (Δ -0.004) |

VALID
