[P3] **The screen forecast does not scale the idle cases' entry-dependent host work** (`scripts/cause_forecast.py:34-36`, `projected = ... + 4 * times['smoke-idle']`).

The comment justifies this as "Idle retains four one-second controls." The value used, however, is the idle case's whole `host-timing.json` `total_seconds`. Each idle case in `scripts/cause_host.py:execute` does more than the one-second sleep:

- It copies the seed with `shutil.copytree(seed, case)` and runs `seed_hash` on the copy.
- It runs `helper.flush_caches`, which does `os.sync()` on the freshly written copy, then `drop_caches`.
- It runs `verify_seed_integrity`, which reads and hashes the whole copied snapshot.
- It removes the copy with `shutil.rmtree(case)`.

All of this grows with snapshot size, roughly tenfold from 100k to 1m. The 1m retained snapshot is about 244 MiB per generation, with current and previous both copied.

The names and stat cases include the same work and are scaled by 10. Idle is the only per-case term left at 100k scale. This contradicts the stated method ("scales entry-dependent work by ten") in `docs/designs/resource-cause-proof-plan-2026-11-02.md` and the disposition row "Smoke cannot derive forecast."

The effect is a systematic, non-conservative underestimate of `host_forecast_seconds`. Four idle cases each miss roughly 9× their copy, hash, flush and verify time. This feeds all three admission inequalities (2100 / 2700 / +240 cleanup). A borderline screen could then be admitted and hit the hard host deadline, charging up to 3600 runner-seconds for an invalid campaign.

Fix: split the idle receipt into constant parts (worker and capture time) and scaled parts (`copy_and_seed_hash_seconds`, `cache_flush_seconds`, the seed-integrity time, `case_cleanup_seconds`), and project `4 × (constant + 10 × scaled)`. A simpler, more conservative option is to scale the idle total by 10 like the other cases.

This forecast runs after source freeze and must be fixed before freeze. Adjust `test_screen_forecast_uses_every_fixed_case_and_both_caps`, whose expected 234 s encodes the current formula.

No other material RAM-scope findings. These parts were checked and look consistent:

- **Probe:** dirent ABI and record bounds, DT_UNKNOWN rejection, inode/type parity, and the multiset digest.
- **Worker sampler:** the 250 ms coverage with boundary gaps, and the frozen pre/post cgroup brackets.
- **Raw counters:** required counters, events and events.local, and the pgscan/pgsteal censoring check.
- **Validator:** cross-checks of schedule, counts, Docker caps and I/O.
- **Outcomes:** support and rejection rules, the collector bounds and the 0.75 ratios, all matching the plan.
- **Forecast:** case multiplicities of 4/4/4/7/3/1.

Outside this part's packet, and not reviewed: `cause_observe.capture_cgroup`, `cause_lifetime`, `bench_v1_fixture.prepare` (fixture entry-type composition), `cause_runner.sh` and `v2-balance.yml`.
