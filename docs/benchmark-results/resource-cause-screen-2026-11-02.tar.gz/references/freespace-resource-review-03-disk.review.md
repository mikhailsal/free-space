**[P3] Named-file vanish races during traversal count as hard errors, which can fail the disk group.**
- **Where:** `scripts/cause_observe.py` (`record_inventory` → `walk`), `scripts/cause_lifetime.py` (`poll`), and `scripts/cause_validate.py` (`lifetime_ok`).
- **What happens:**
  - `walk` puts every `OSError` from `entry.stat(...)` or a subdirectory `os.open` into `errors`. That includes `FileNotFoundError` when a name disappears between `readdir` and `fstatat`.
  - `LifetimeWatch.poll` then reports each inventory error as `self._issue("errors", ...)`, the true-error kind, not `races`.
  - `lifetime_ok` requires `counts['errors'] - counts['races'] - counts['limits'] == 0`.
- **When it triggers:** an ordinary unlink or rename during a watched poll. Examples are the stage removal, the `snapshot.prev.tmp` link-then-rename, the output rename over current, or anything created and unlinked under `snapshot/tmp`.
- **Consequence:** the declared "races are not absence/errors" contract breaks, and `disk-pin` becomes invalid. Because failed measurements are never rerun, the smoke is invalid and the screen cannot be admitted. That costs a new source, review and reservation.
- **Probability:** low per run, since each window is microseconds per 50 ms poll. But it is a deterministic misclassification on a one-shot path.
- **Fix:**
  - In `walk`, classify `FileNotFoundError` separately as a race, and still mark the inventory incomplete.
  - In `poll`, map those entries to `_issue("races", ...)`.
  - Keep treating any error as fatal in the quiescent inventories inside `disk_capture` (held, unlinked and final).

**[P3] The "stage retirement observed" check is vacuous.**
- **Where:** `scripts/cause_validate.py` (`lifetime_ok`, last `need`), together with `scripts/cause_lifetime.py` (`poll`, `present.setdefault("named:" + path, absent)`).
- **What happens:**
  - On the first complete poll, before the stage exists, `_transition` records `named:snapshot.stage.tmp` going from `None` to `{"state": "absent"}`. `test_identity_transitions_and_deduplicated_maxima` asserts exactly this as `stage_changes[0]`.
  - `lifetime_ok` only checks that some transition for that path has `current.state == 'absent'`, so the first poll satisfies it every time.
- **Consequence:**
  - The lifetime receipt is accepted even if the watcher never observed the stage existing and then retiring. That could happen if the watch started late or every poll during the stage lifetime was incomplete.
  - The retirement itself is still verified by `disk_capture` (`path_state == 'absent'` and `naturally_unlinked`). So this is a misleading evidence claim, not a missing gate.
- **Fix:** require a transition whose `previous` carries an `inode` and whose `current` is `absent`, with the inode equal to the pinned stage inode. Alternatively, drop the claim.

**[P3] The pinned baseline artifact likely expires about seven days after its build run, and nothing before dispatch checks the remaining lifetime.**
- **Where:** `.github/workflows/representative-bench.yml` (`representative-binary` upload, `retention-days: 7`) and `.github/workflows/v2-balance.yml` (provenance step asserts `artifact['expired'] is False`; download uses `run-id: 41277463149`).
- **Why it matters:**
  - Run 41277463149 is adjacent to the 2026-11-01 canonical run, so expiry is probably around 2026-11-08.
  - Smoke, the forecast, any repair-and-review cycle and the screen all have to finish before then.
  - The in-workflow check fails closed, but only after a runner job has started and been charged.
  - Because source identity is frozen to this artifact ID and run, an expiry forces a new source and review rather than a simple redispatch.
- **Fix:** have the root admission procedure read `expires_at` and refuse dispatch unless the smoke, plus the screen if it remains possible, fits before expiry. Alternatively, archive the verified ED2 payload under a durable identity before freezing.
