# Review: resource-cause-v1 diagnostic harness and causal protocol

I found no P1 execution blockers by inspection. The harness fails closed in almost every path, and the existing contracts are consistent with each other:

- receipt identity and nonces
- Docker caps, mounts and `io.max`
- host-PID cgroup capture
- the fixed schedule
- the fixture count formula (449 directories at 100k, 4,499 at 1m)
- seed integrity
- semantic and probe digest uniqueness
- unique-inode sums

The budget arithmetic is also correct: 216,000 − 50,644 − 34,800 = 130,556.

The material problems fall into two groups:

- **Budget risk:** the deadlines and the smoke receipts cannot support the screen-admission rule.
- **Research-goal risk:** the screen has no pre-registered decision rule, and the disk pass cannot attribute peak disk to specific files.

## Findings

**[P2] Deadlines do not nest inside the 45-minute step**

Where: `representative-bench.yml` (`timeout-minutes: 45`), `scripts/cause_runner.sh`, and `scripts/cause_host.py:main`.

- Before the host starts, several stages run inside the same step: preparation (up to 270 s), `mkfs.ext4 -E lazy_itable_init=0` on 40 GiB, `docker build` (apt over the network, no timeout) and four fio calibration jobs.
- The host then arms a fresh 2,100-second timer when Python starts.
- After that, the host cleanup and the shell `cleanup()` run. The shell cleanup alone can take `docker rm` 60 s per container, umount 30 s, losetup 15 s, sync 15 s, plus the summary.
- 270 + build/mkfs/calibration + 2,100 + cleanup can exceed 2,700 s.
- If it does, GitHub's step timeout interrupts the EXIT trap. `runner-cleanup.json` and `summary.json` are then lost, and the run is charged anyway.

Action:
- Compute an absolute deadline in the shell at step start and pass it to `cause_host.py`.
- Set the host budget to `min(2100, deadline − now − cleanup_reserve)`.
- Wrap `docker build`, `mkfs` and calibration in `timeout`.

**[P2] The smoke run cannot produce the per-phase forecast that screen admission requires**

Where: `scripts/cause_host.py:execute`, `scripts/cause_case.py:run_case`.

The plan requires checking the 1,800-second screen forecast against smoke. The code does not record timing for any of these phases:

- fixture `prepare` (the old `bench_v1_pair` stored `setup_seconds`)
- `copytree` plus `seed_hash`
- the cache flush
- the `run_case` wall time (`host.json` has no start or end stamps)
- `rmtree`
- the observer container wall time; only the observer's internal elapsed time is kept

The screen contains:
- 11 full 1m scans
- 11 observers, each running `quick_check` and a full row digest of two databases
- 12 probes
- 2 seed scans
- 1m-file fixture generation

Given that load, the 1,800-second figure is not derived from anything. Hitting the deadline invalidates the entire screen.

Action:
- Record monotonic stamps for every phase and for the fixture.
- Derive the screen forecast from the smoke components, with explicit ×10 scaling for the parts that grow with entry count, plus 30%.
- Freeze that forecast before the screen is dispatched.

**[P2] No pre-registered decision rule exists, so the "reject or unresolved" outcome is chosen after the data**

Where: `scripts/cause_summary.py:comparisons`, and the plan section "Reject a proposed cause if … variation is large enough".

- The summary emits raw per-round differences and medians only.
- No primary outcome, threshold or noise reference is defined.
- Each round has one run per mode, so the only available noise estimate is the spread across rounds.

Action, to be frozen before smoke:
- Primary outcomes, for example post-CLI `slab_reclaimable` and `memory.peak` for `stat − names`.
- A support criterion, for example the same sign in 4 of 4 rounds and a minimum effect above both a stated absolute floor and the cross-round range of the `names` arm.
- The labels `supported`, `unresolved` and `rejected`, encoded in the summary.

**[P2] The disk pass cannot answer "peak disk" beyond the sizes of two inodes**

Where: `scripts/cause_case.py:disk_capture`, `scripts/cause_observe.py:record_inventory`.

- The worker sets `SQLITE_TMPDIR=/scratch/snapshot/tmp`. SQLite unlinks its temp and sorter files at open, so neither `PinSet` nor the inventory (named files plus explicit pins) can see them.
- The full sampler's statvfs peak does include those files. When reconciling, that gap could be wrongly attributed to stage/previous overlap.
- No timestamps are recorded for when the stage file disappears or when `prev` and `current` are replaced. The source-code overlap argument therefore stays unverified.

Action:
- In the existing 50-ms host poll during `disk-pin`, record path-state transitions with monotonic stamps.
- Find the application PID through the container's `cgroup.procs`, and sample `/proc/<pid>/fd` entries marked `(deleted)` using `os.stat` (same uid) to measure unnamed temporary bytes.
- Otherwise, label the residual explicitly as "unattributed, includes SQLite temporaries".

**[P2] Two requirement rows have no evidence planned in this campaign**

Where: `docs/designs/resource-cause-proof-plan-2026-11-02.md`, the "Required outcome" table.

- "Explain refresh RAM" and "Explain v2 growth" (including returning bytes after GC) get no intervention here.
- The "fair prototype" in the stack-alternatives row is deferred.
- This is a gap in answering the research goal, not an honesty problem, but only if it is written down.

Action:
- State for each row what this campaign can establish.
- Mark refresh RAM and v2 growth as open hypotheses supported only by the existing evidence, so the final report cannot present them as explained.

**[P2] Unverified CLI output contracts could void every scan case**

Where: `scripts/cause_worker.py:validate_report` and `scripts/cause_validate.py:report_ok` both require `report['workers'] == 1`. Separately, `cause_worker.read_json` caps `stdout.json` at 64 KiB.

- The earlier harness (`measured_command`, `bench_v1_summary`) never required a `workers` field and read stdout without a size bound.
- Only the synthetic tests cover these checks.
- If the baseline v1 JSON lacks `workers`, or exceeds 64 KiB, every scan fails and the smoke run is charged.

Action: check against the baseline CLI source at `e8265778`, or against a `stdout.json` from a prior artifact. If the field is not there, drop the check.

**[P3] Database receipts are not bound to the pinned inodes, and stale WAL content is not detected**

Where: `cause_case.disk_capture`, `cause_validate.disk_ok`.

- Neither function compares `databases[*]['source_identity']['inode']` against the pin or named-inventory inodes.
- In `db_breakdown`, the sidecar check runs against the alias directory, where no sidecars ever exist. For the aliases it is therefore a no-op.
- As a result, a stage file in WAL mode or with a hot journal would be read with `immutable=1` and report stale pages while still passing `page_size*page_count == size`.

Action:
- Assert the inode identities.
- Record the journal mode from header bytes 18–19, and whether `snapshot.stage.tmp-wal` or `-journal` existed at pin time and at the held inventory.

**[P3] The page-category equality breaks above 1 GiB or with auto_vacuum**

Where: `cause_validate.disk_ok`, the check `sum(dbstat pages) + freelist == page_count`.

- dbstat never counts the lock-byte page (present when a database exceeds 1 GiB) or pointer-map pages (present with auto_vacuum).
- The 100k smoke cannot reveal either case.

Action: record `PRAGMA auto_vacuum`, and account for the lock-byte page explicitly when it applies.

**[P3] A racy stage pin can invalidate an otherwise complete RAM screen**

Where: `cause_case.run_case` (the `exists()` check followed by `pin_stage()`), and `cause_summary.summarize`, which is all-or-nothing.

- `disk-pin` runs last. A `FileNotFoundError` from that race, or a stage file whose lifetime is shorter than the pre-PID `docker inspect` latency, discards valid latin and collector evidence.

Action:
- Retry the pin within the polling loop when that error occurs.
- Pre-register group-level statuses (`ram`, `collector`, `disk`) alongside the campaign status.

**[P3] The stop rule "unexpected background work" is not implemented**

No step records host load, PSI, other containers, or I/O on the backing disk.

Action: in `capture_global`, add `/proc/pressure/*`, `loadavg`, a `docker ps` count and host `io.stat`, with a pre-registered threshold.

**[P3] SIGALRM can fire inside `run_case`'s `finally` block**

Where: `cause_host.execute`, `cause_case.run_case`.

- A case can legitimately run for about timeout + 150 + 15 + 30 s, plus the hold and the disk capture. The timeout is sized as `remaining − 180`, so this can exceed the remaining time.
- If the alarm fires there, it skips `docker rm`, `host.json` and closing the pins.
- `execute` then runs `rmtree` on the case directory while the container is still live, with `preserve` still False.

Action: block SIGALRM during cleanup and size each case so its worst-case duration fits the remaining time. If an exception escapes `run_case`, treat it as `preserve=True`.

**[P3] Toolchain provenance is incomplete**

- The image is built from a floating `ubuntu:24.04` tag with unpinned apt packages.
- The container's python and sqlite produce the semantic digests. The host's sqlite produces dbstat.
- `db_breakdown` records the compile options but not `sqlite_version`.

Action: pin the base image by digest, and record the python, sqlite and fio versions in `provenance/`.

**[P3] The cyclic Latin square is not balanced for carryover**

- `names` immediately precedes `stat` in 3 of 4 rounds, and `scan→idle` is fixed.
- Cold caches mitigate this, but a Williams square removes it at no cost: `idle,names,scan,stat` / `names,stat,idle,scan` / `stat,scan,names,idle` / `scan,idle,stat,names`. In this design each ordered pair of modes occurs exactly once.
- Changing it means updating `build_schedule`, `expected_schedule`, the plan and the test together.

**[P3] Repository hygiene and gates**

- `scripts/__pycache__/` and `scripts/tests/__pycache__/` are untracked; add them to `.gitignore` before committing.
- The new Python is covered by no lint or size gate.
- `execute`, `run_case` and `measure` exceed the 80-line function default in your global rules.

**[P3] Screen admission is procedural only**

The workflow will dispatch `screen` without checking for a valid smoke run.

Action: add a `smoke_run_id` input and verify, through the API, that run's artifact and its `summary.valid`.

## Missing context, to confirm before dispatch

- Whether any `test_bench*.py` asserts on the original `representative-bench.yml`. This branch replaces that file, and the workflow runs those tests.
- That dispatching the master-registered workflow with `ref=perf/resource-cause-proof` uses the branch's file and inputs.
- The format of `snapshot.stage.tmp` (SQLite? which journal mode?) and the expected database sizes at 1m.
- The authoritative ledger entry for the 7,200-second reservation.

## Conclusion

These are acceptable, honestly documented diagnostic limitations:

- post-CLI categories are endpoint observations, not a decomposition of the peak
- global slab data is not attributed to a cgroup
- the pin pass is not an ordinary peak measurement
- `scan − stat` is not additive
- n = 4 is exploratory

These are failures to answer the research goal as currently written:

- the missing decision rule
- the disk-lifetime and temp-file attribution gap
- the unmapped refresh-RAM and v2-growth requirements

The admission and deadline findings put the 7,200-second reservation at risk without producing evidence. Fix the P2 items before freezing the source and dispatching smoke.
