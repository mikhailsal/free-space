# Independent RAM arithmetic check

Checks passed: 146/146. Failures: []. All 23 replay source bodies and 22 available original source bodies match manifest hashes; the saved baseline matches pinned ED2. The original artifact omitted the hidden workflow source; replay restored it from the immutable source revision and records this in transport-recovery.json.

Fixture: 1,000,000 regular files and 4,499 directories, 1,004,499 entries. Stat probes make 1,004,498 entry stat calls; names probes make zero. All eight probes share path-kind digest `a2edb340208f201a5ec292d494b1bff94a82b80833619f5b89b060ca576142cb`.

| Mode | Median kernel peak bytes | Median CLI RSS KiB | Median elapsed seconds |
|---|---:|---:|---:|
| idle | 35,491,840 | 16,002 | 1.066 |
| names | 233,547,776 | 16,118 | 20.596 |
| stat | 1,698,191,360 | 16,234 | 34.215 |
| scan | 1,940,717,568 | 37,792 | 54.324 |

| Round | Stat − names reclaimable slab bytes | Stat − names kernel peak bytes | Stat / scan slab | Stat / scan peak |
|---:|---:|---:|---:|---:|
| 1 | 1,342,598,504 | 1,465,077,760 | 99.721% | 87.513% |
| 2 | 1,342,595,456 | 1,464,676,352 | 99.720% | 87.488% |
| 3 | 1,342,587,024 | 1,464,340,480 | 99.720% | 87.494% |
| 4 | 1,342,583,096 | 1,464,619,008 | 99.720% | 87.537% |

Largest idle/names cross-round ranges: 14,296 bytes slab and 647,168 bytes peak. All four effects exceed these controls and the fixed 64 MiB floor. All stat/scan ratios exceed 0.75; combined with the collector controls, the fixed-policy metadata effect and comparability outcomes are supported.

| Collector pair | Full − reserve peak bytes (bound) | RSS KiB (bound) | Seconds (bound) |
|---:|---:|---:|---:|
| 1 | -143,360 (38,819,103) | -152 (1,024) | -0.000917 (2.705) |
| 2 | +348,160 (38,810,173) | -92 (1,024) | +0.201343 (2.702) |
| 3 | +65,536 (38,810,583) | -100 (1,024) | +0.051342 (2.707) |

All 23 cases show the requested 4 GiB memory limit, two CPUs, no swap, and four I/O controls. Frozen before/after cgroup records show no OOM or OOM-kill increment, swap current/peak, or pgscan increment.

The four scan post-CLI anonymous-memory readings span 9,146,368–9,166,848 bytes. These are worker cgroup endpoint readings after the Rust CLI exited, not its live heap; CLI peak RSS is separate. Global dentry and ext4 inode slab changes in the JSON are host-wide context, not cgroup object attribution. The roughly 87.5% peak and 99.7% endpoint slab ratios compare distinct interventions and observation times; they are not additive peak decompositions. The three collector pairs are exploratory, not confidence intervals, and the diagnostic is not product qualification.

In the host-wide slab observations, the four stat cases show dentry active-object increases of 1,005,000–1,005,420 and ext4 inode-cache increases of 1,003,764–1,004,160. The names cases show increases of 4,920–5,100 and 4,752–4,776 respectively. These bracketed host totals support the metadata-cache interpretation without assigning those objects to the worker cgroup.
