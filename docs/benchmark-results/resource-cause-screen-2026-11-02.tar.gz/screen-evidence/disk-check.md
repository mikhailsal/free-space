# Independent disk arithmetic check — 1m run 41373680085

This is a bounded arithmetic/evidence check of the real raw receipts, not a formal model review or a new measurement. Only this report and its JSON companion were written. No application, Docker workload, build, real proc scan, source edit, ledger update or dispatch ran.

## Provenance and method

Raw root: `/tmp/freespace-resource-screen-artifacts`; replay root: `/tmp/freespace-resource-screen-replay`. Manifest source is unchanged `51ff2065e49184583932c2ef6d90152c1a586671`, application E826 `e8265778ef78ec4acd9da1375eedb0be37a123f5`, run `41373680085`/attempt 1. I freshly hashed `provenance/baseline`: actual binary ED2 `ed2a1cb138b1e48e70a388a4a8fda3e79fcfd2e37fd0c061d41d2d6363f8e980`. Four relevant raw harness sources match the immutable manifest hashes. Sixteen critical raw/replay files—including the four Latin scan metrics/specs, disk diagnostic metrics/spec, manifest, disk/lifetime captures, observer and ready/ack—are byte-identical. The recovered hidden workflow matches the exact immutable Git source and receipt hash; transport recovery did not alter the measurement payloads checked here.

The fixture is 1,000,000 files / 1,004,499 entries with 4,499 directories, fixed mixed shape and seed, one worker, two CPUs, 4 GiB RAM and no swap. The runner loop-device I/O envelope remains the recorded 32 MiB/s read/write, 2,200/3,600 read/write IOPS. These are synthetic runner conditions, not the user's local disk performance.

Primary anchors are `measurements/disk-pin/{disk,lifetime,metrics,observer}.json`, `measurements/disk-pin.json`, and `measurements/lat{1,2,3,4}-scan/{metrics.json}` plus the corresponding top-level case specs. Arithmetic below was recomputed from those raw fields. The independent-summary validity flag was not used as a substitute for checking them. Full input hashes, per-object categories and recomputed release comparisons are in the companion JSON.

## Held budget: four distinct payload inodes

`disk.json.held` is complete, race-free and quiescent, after worker ready but before inspection aliases are removed. All listed payloads are on device 1792:

| Held role | Inode | SQLite logical bytes | Inode allocated bytes | Allocated MiB |
| --- | ---: | ---: | ---: | ---: |
| Published current, formerly replacement | 4789891 | 128,012,288 | 128,012,288 | 122.082031 |
| Published previous, formerly current | 4789887 | 128,012,288 | 128,016,384 | 122.085938 |
| Pinned old previous | 4789885 | 128,012,288 | 128,012,288 | 122.082031 |
| Pinned stage | 4789890 | 75,714,560 | 75,718,656 | 72.210938 |
| `state.json` | 4789889 | 163 | 4,096 | 0.003906 |
| `.lock` | 4789886 | 0 | 0 | 0 |
| **Unique-inode total** | **6** | **459,751,587** | **459,763,712** | **438.464844** |

The allocation sum is directly over this single held inventory's distinct inode keys. App names, explicit pins, private hardlink aliases and container FD references do not create duplicate payload entries. The four DB page images total 459,751,424 B; their inode allocations total 459,759,616 B. The extra 8,192 B belongs to two recorded inode-allocation surpluses, followed by the state file's 4,096 B in the regular-file total.

Held filesystem use is identical at both bracket boundaries: 808,050,688 B. It includes fixture/filesystem/directory allocation outside the inventoried regular files. It is not the application-file total.

All four `disk.json.databases` records match the held device/inode/size/allocation observations exactly and preserve identical before/after source identity. Every query connection is closed before alias removal and release. The identity chain is concrete: old current 4789887 becomes published previous; replacement 4789891, first seen as `snapshot.3.tmp`, becomes current; old previous 4789885 remains a separate diagnostic-held inode. There is no fourth copied database caused by `snapshot.prev.tmp` hardlink rotation.

## SQLite page images and allocation surpluses

Every inspected DB reports SQLite 3.45.1, a valid 100-byte header with write/read versions 1/1, 4,096-byte pages, `auto_vacuum=0`, `freelist_count=0`, immutable/read-only inspection and stable source identity. Every logical image is below 1 GiB. For each file, the sum of `dbstat` page bytes exactly equals `page_count × page_size` and its logical length.

| Database(s) | Total pages | Table pages / bytes | Index pages / bytes | Schema | Logical image | Extra inode allocation beyond page image |
| --- | ---: | ---: | ---: | ---: | ---: | ---: |
| Stage 4789890 | 18,485 | 10,349 / 42,389,504 | 8,135 / 33,320,960 | 1 / 4,096 B | 75,714,560 B | **4,096 B** |
| Old previous 4789885 | 31,253 | 16,968 / 69,500,928 | 14,284 / 58,507,264 | 1 / 4,096 B | 128,012,288 B | 0 |
| Published current 4789891 | 31,253 | 16,968 / 69,500,928 | 14,284 / 58,507,264 | 1 / 4,096 B | 128,012,288 B | 0 |
| Published previous 4789887 | 31,253 | 16,968 / 69,500,928 | 14,284 / 58,507,264 | 1 / 4,096 B | 128,012,288 B | **4,096 B** |

Stage table/index page budgets are 40.425781 / 31.777344 MiB; each snapshot's table/index page budgets are 66.281250 / 55.796875 MiB. No additional SQLite pages are missing from these categories. However, `dbstat` does **not** account for the two extra 4,096-byte inode allocations: they are outside the logical SQLite page images. They are compatible with filesystem allocation/extent metadata or other inode block accounting, but the receipts do not identify their exact filesystem mechanism. Since logical lengths are already multiples of 4,096 B, ordinary last-page rounding does not explain them. Do not silently attribute them to an additional SQLite table/index/freelist page.

Snapshot object detail, identical in allocated page sizes across the three generations:

| Object | Pages | Bytes |
| --- | ---: | ---: |
| `entries` table | 16,951 | 69,431,296 |
| `entries_alloc` index | 2,389 | 9,785,344 |
| `entries_mtime` index | 3,648 | 14,942,208 |
| `entries_parent_alloc` index | 3,635 | 14,888,960 |
| `entries_path_hash` index | 4,603 | 18,853,888 |
| `hardlinks_inode` index | 9 | 36,864 |

The remaining snapshot table pages cover hardlinks, metadata, roots, denied/mount/refresh records and SQLite statistics; schema adds its own page. Metadata payload bytes vary by generation, so equal allocation categories do not imply byte-identical DB contents.

Stage object detail: `raw` 10,303 pages / 42,201,088 B; `raw_children` 8,081 / 33,099,776 B; `links` 44 / 180,224 B; `links_owner` 54 / 221,184 B; `jobs`, `mount_info` and `sqlite_schema` each one 4,096-byte page. The companion JSON retains complete payload/unused sums for every object. In-page `unused` is neither freelist allocation nor directly returnable filesystem space. Alias inspection also cannot discover hypothetical sidecars beside another pathname; the E826 journal-OFF source contract, quiescence, measured headers and identity binding are necessary context for these immutable reads.

## Sequential release counterfactuals

At held capture, old previous and stage each have `nlink=1` from the deliberate private alias. Their original app names are respectively replaced and absent. Alias deletion succeeds with no errors/remaining links. `disk.json.unlinked` then records **the same inodes at nlink 0**, while the unique regular-file allocation remains 459,763,712 B.

Filesystem use decreases by 4,096 B during alias removal, from 808,050,688 to 808,046,592 B. Regular-file allocation does not change; this is compatible with private directory/metadata release, not uniquely localized by this inventory. Both payload-release baselines are taken after that change.

I recomputed every comparison from the raw baseline/sample `free_bytes`, rather than trusting the stored residual fields:

| Released pin | Inode | Expected allocated bytes | Measured free increase: immediate and all 11 samples | Residual |
| --- | ---: | ---: | ---: | ---: |
| Stage | 4789890 | 75,718,656 B / 72.210938 MiB | 75,718,656 B | 0 B in every sample |
| Old previous | 4789885 | 128,012,288 B / 122.082031 MiB | 128,012,288 B | 0 B in every sample |

Each series spans approximately 0.5 s. Recorded block and fragment sizes are 4,096 B. Stage release reclaims its allocated-byte amount, including the 4,096 B beyond its logical page image; using its logical length alone would leave a 4,096-byte residual. Residual zero is measured at filesystem block quantization, not sub-block precision or a universal concurrency bound.

The two sequential release steps reclaim **203,730,944 B / 194.292969 MiB**. Final complete allocation is recomputed as `459,763,712 − 75,718,656 − 128,012,288 = 256,032,768 B` / **244.171875 MiB**. Final current/previous identities and allocations remain unchanged. The filesystem residual outside inventoried regular files is a stable 348,282,880 B after alias removal, after stage release and after previous release; this reconciles the controlled byte changes.

This establishes actual retention/reclamation amounts in the diagnostic pass. It is not a semantics-preserving product saving, an ordinary unpinned peak measurement, or evidence of lower RAM/speed cost.

## Ordinary Latin scans versus the pin diagnostic

Using the frozen formula requested for this check:

`app metric = sampling.filesystem_used_peak − endpoint_before.filesystem_used_bytes + case_spec.initial_snapshot_allocated_bytes`

| Case | Sampled filesystem peak | Start filesystem use | Frozen initial allocation | Recomputed app metric | Separately sampled named maximum |
| --- | ---: | ---: | ---: | ---: | ---: |
| `lat1-scan` | 808,054,784 | 604,311,552 | 256,028,672 | **459,771,904** | 459,771,904 |
| `lat2-scan` | 808,054,784 | 604,311,552 | 256,028,672 | **459,771,904** | 459,771,904 |
| `lat3-scan` | 808,054,784 | 604,311,552 | 256,028,672 | **459,771,904** | 459,771,904 |
| `lat4-scan` | 808,054,784 | 604,311,552 | 256,028,672 | **459,771,904** | 459,771,904 |
| `disk-pin` | 808,062,976 | 604,319,744 | 256,028,672 | **459,771,904** | **459,776,000** |

All five adjusted metrics equal **438.472656 MiB**. The diagnostic's absolute filesystem peak and start are each 8,192 B larger than ordinary, so those increases cancel in this formula. Its named maximum is 4,096 B larger. Its actual endpoint-before regular-file allocation is 256,032,768 B—4,096 B above the frozen initial specification—whereas each ordinary endpoint matches the frozen 256,028,672 B exactly. The diagnostic's remaining 4,096 B filesystem-start difference lies outside the regular-file inventory, compatible with the private alias directory. These differences must stay visible; replacing the frozen input with a different baseline would silently change the metric.

All five worker samplers report valid 20 ms coverage, zero missed/late ticks and no capture errors; ordinary scan tick counts are 2,722/2,714/2,721/2,714, diagnostic 2,731. These are sampled filesystem-use metrics, not true-peak guarantees. Equality of their adjusted values or agreement with ordinary named maxima does not prove identical temporal allocations or isolate every component's causal share.

## Live overlap and incomplete temporal evidence

The host watcher records **1,073 polls**, **672 complete**, **432 race events**, **176 dropped error-detail records**, no traversal/FD/poll limit event, no dropped transition record and no estimated missed 50 ms interval. Thus 401 polls are incomplete; `coverage_complete=false` is retained. Maximum poll gap is 62.922079 ms; maximum observation duration 4.148025 ms. The bounded detail list preserves only the first 256 events, so it cannot support a complete frequency breakdown or individual explanation of all 432 races.

Among retained details: 218 cross named/pin/FD observation mismatches, 30 within-traversal named/pin mismatches, seven disappearing FDs and one descriptor-identity change. The later 176 details are absent by design. These are recorded race categories; their underlying physical events cannot all be reconstructed, and no absence claim or complete temporal attribution follows.

The largest combined and named inventories share the same bracket, monotonic **1349117894555–1349118787291 ns** (about 0.893 ms), and each totals **459,776,000 B / 438.476563 MiB**. Four distinct payload inodes are app-named in that bracket: current 4789887, previous 4789885, replacement `snapshot.3.tmp` 4789891 and stage 4789890. FD/pin/hardlink references deduplicate to those payloads. Four 4,096-byte live auxiliary blocks—state, lock, progress and progress temp—account for the remaining 16,384 B; the held capture later has only the state block, explaining its 12,288-byte smaller total. File-source filesystem readings within the selected bracket are stable at 808,062,976 B.

This supplies a direct **bracketed observation of live representation overlap**, not an atomic sum at the exact ordinary true peak. Different per-object observation times and the extensive race record prevent stronger simultaneity/temporal claims. Separate maxima were not added.

The maximum recorded open-deleted allocated total is zero; this cannot establish that all short-lived deleted temporaries were absent. The stage/old-previous aliases deliberately maintained positive link counts while watching. Their zero-link release states were captured later, after watcher finish. The selected live maximum also observes denied-spool inode 4789892 at nlink 0 with zero blocks, which establishes that particular empty spool observation, not absence of the spool mechanism or all spills.

Identity transitions show stage 4789890 present after its initial absent state and later absent after a present observation; replacement 4789891 is observed under `snapshot.3.tmp` and later as current, while previous changes to old current 4789887. The final app-name retirement/publication changes fall in the same sampled inter-poll interval. Exact event ordering/durations require separate source lifetime evidence; they cannot be reconstructed fully from this trace.

The separate observer validates both retained generations at 1,004,499 entries, logical content unchanged, semantic digest `81c7205d56d28dc16618230c2e14fc3161d20bb2701d8c742f0f1ee8856dca74`. This corroborates preservation within the controlled case. It does not establish a production optimization, full-scale qualification, minimum capacity, or that dropping indexes/history would preserve required behavior.
