# v1-single-operation-pairs-v4

Case: {"case_policy": "qualification-v1", "memory_mib": 4096, "mutation_receipt": null, "observer_memory_mib": 4096, "scenario": "unchanged", "setup_memory_mib": 4096, "subtree_entries": 100}


Descriptive paired results; no automatic promotion or uncertainty estimate.
Application disk peak is sampled; RSS excludes the observer.

| Pair | Elapsed baseline → candidate (s) | RSS baseline → candidate (MiB) | App disk baseline → candidate (GiB) |
|---:|---:|---:|---:|
| 1 | 10.612 → 10.605 (Δ -0.007) | 369.066 → 369.055 (Δ -0.012) | 0.349 → 0.349 (Δ +0.000) |
| 2 | 10.618 → 10.653 (Δ +0.035) | 369.090 → 369.047 (Δ -0.043) | 0.349 → 0.349 (Δ +0.000) |
| 3 | 10.617 → 10.641 (Δ +0.024) | 369.035 → 369.113 (Δ +0.078) | 0.349 → 0.349 (Δ +0.000) |

Identical binaries: observed maximum absolute paired differences (descriptive band):
- elapsed_seconds: median Δ +0.024; max |Δ| 0.035
- peak_rss_kib: median Δ -12.000; max |Δ| 80.000
- app_disk_peak_bytes: median Δ +0.000; max |Δ| 4096.000

VALID
