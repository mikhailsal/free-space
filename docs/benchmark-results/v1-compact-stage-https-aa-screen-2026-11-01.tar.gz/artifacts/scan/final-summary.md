# v1-single-operation-pairs-v4

Case: {"case_policy": "qualification-v1", "memory_mib": 4096, "mutation_receipt": null, "observer_memory_mib": 4096, "scenario": "unchanged", "setup_memory_mib": 4096, "subtree_entries": 100}


Descriptive paired results; no automatic promotion or uncertainty estimate.
Application disk peak is sampled; RSS excludes the observer.

| Pair | Elapsed baseline → candidate (s) | RSS baseline → candidate (MiB) | App disk baseline → candidate (GiB) |
|---:|---:|---:|---:|
| 1 | 68.391 → 68.617 (Δ +0.226) | 36.773 → 36.590 (Δ -0.184) | 0.429 → 0.429 (Δ +0.000) |
| 2 | 68.595 → 68.620 (Δ +0.024) | 36.625 → 36.598 (Δ -0.027) | 0.429 → 0.429 (Δ +0.000) |
| 3 | 68.651 → 68.496 (Δ -0.156) | 36.676 → 36.863 (Δ +0.188) | 0.429 → 0.429 (Δ +0.000) |

Identical binaries: observed maximum absolute paired differences (descriptive band):
- elapsed_seconds: median Δ +0.024; max |Δ| 0.226
- peak_rss_kib: median Δ -28.000; max |Δ| 192.000
- app_disk_peak_bytes: median Δ +0.000; max |Δ| 0.000

VALID
