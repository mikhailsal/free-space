# v1-single-operation-pairs-v4

Case: {"case_policy": "qualification-v1", "memory_mib": 1024, "mutation_receipt": null, "observer_memory_mib": 4096, "scenario": "unchanged", "setup_memory_mib": 4096, "subtree_entries": 100}


Descriptive paired results; no automatic promotion or uncertainty estimate.
Application disk peak is sampled; RSS excludes the observer.

| Pair | Elapsed baseline → candidate (s) | RSS baseline → candidate (MiB) | App disk baseline → candidate (GiB) |
|---:|---:|---:|---:|
| 1 | 1116.836 → 1303.922 (Δ +187.085) | 34.172 → 34.180 (Δ +0.008) | 3.126 → 3.126 (Δ +0.000) |

Identical binaries: observed maximum absolute paired differences (descriptive band):
- elapsed_seconds: median Δ +187.085; max |Δ| 187.085
- peak_rss_kib: median Δ +8.000; max |Δ| 8.000
- app_disk_peak_bytes: median Δ +8192.000; max |Δ| 8192.000

VALID
