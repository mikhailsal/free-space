# v1-single-operation-pairs-v4

Case: {"case_policy": "qualification-v1", "memory_mib": 2048, "mutation_receipt": null, "observer_memory_mib": 4096, "scenario": "unchanged", "setup_memory_mib": 4096, "subtree_entries": 100}


Descriptive paired results; no automatic promotion or uncertainty estimate.
Application disk peak is sampled; RSS excludes the observer.

| Pair | Elapsed baseline → candidate (s) | RSS baseline → candidate (MiB) | App disk baseline → candidate (GiB) |
|---:|---:|---:|---:|
| 1 | 57.721 → 46.312 (Δ -11.409) | 36.758 → 36.992 (Δ +0.234) | 0.428 → 0.428 (Δ -0.000) |
| 2 | 57.699 → 45.899 (Δ -11.800) | 36.848 → 36.812 (Δ -0.035) | 0.428 → 0.428 (Δ -0.000) |
| 3 | 57.109 → 46.075 (Δ -11.033) | 36.691 → 36.844 (Δ +0.152) | 0.428 → 0.428 (Δ -0.000) |

VALID
