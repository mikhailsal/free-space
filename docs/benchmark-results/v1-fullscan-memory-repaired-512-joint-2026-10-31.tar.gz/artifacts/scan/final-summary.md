# v1-single-operation-pairs-v4

Case: {"case_policy": "qualification-v1", "memory_mib": 512, "mutation_receipt": null, "observer_memory_mib": 4096, "scenario": "unchanged", "setup_memory_mib": 4096, "subtree_entries": 100}


Descriptive paired results; no automatic promotion or uncertainty estimate.
Application disk peak is sampled; RSS excludes the observer.

| Pair | Elapsed baseline → candidate (s) | RSS baseline → candidate (MiB) | App disk baseline → candidate (GiB) |
|---:|---:|---:|---:|
| 1 | 82.224 → 66.288 (Δ -15.936) | 34.293 → 34.438 (Δ +0.145) | 0.428 → 0.428 (Δ +0.000) |
| 2 | 82.994 → 66.579 (Δ -16.415) | 33.145 → 33.512 (Δ +0.367) | 0.428 → 0.428 (Δ +0.000) |
| 3 | 86.763 → 65.517 (Δ -21.246) | 34.199 → 34.387 (Δ +0.188) | 0.428 → 0.428 (Δ -0.000) |

VALID
