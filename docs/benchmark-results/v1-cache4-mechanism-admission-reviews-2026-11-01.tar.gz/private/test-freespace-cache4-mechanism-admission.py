import importlib.util
import json
import pathlib
import tempfile
import unittest
from unittest.mock import patch

spec = importlib.util.spec_from_file_location('cache4', '/tmp/freespace-admit-cache4-mechanism.py')
m = importlib.util.module_from_spec(spec); spec.loader.exec_module(m)


class Cache4Tests(unittest.TestCase):
    def setUp(self):
        # Fail before any accidental network subprocess; source checks may use read-only git.
        original_run=m.subprocess.run; original_output=m.subprocess.check_output
        def guard_run(args,*a,**kw):
            if not isinstance(args,(list,tuple)) or not args or args[0] != 'git':
                raise AssertionError('unmocked subprocess forbidden: '+repr(args))
            return original_run(args,*a,**kw)
        def guard_output(args,*a,**kw):
            if not isinstance(args,(list,tuple)) or not args or args[0] != 'git':
                raise AssertionError('unmocked subprocess forbidden: '+repr(args))
            return original_output(args,*a,**kw)
        for target, effect in (('run',guard_run),('check_output',guard_output)):
            guard=patch.object(m.subprocess,target,side_effect=effect);guard.start();self.addCleanup(guard.stop)

    def make_freeze(self):
        paths = m.command(['git', 'ls-files', 'scripts', '.github/workflows']).splitlines()
        f = {'helper_sha256': m.digest(pathlib.Path(m.__file__).read_bytes()), 'baseline_revision': m.BASE,
             'candidate_revision': m.CANDIDATE, 'baseline_source_epoch': m.EPOCH,
             'protocol_sha256': {p: m.digest((m.WT / p).read_bytes()) for p in paths}}
        for key, path in [('review_path','/tmp/freespace-root-cache4-source-closure-review.json'),
                          ('review_validation_path','/tmp/freespace-root-cache4-source-closure-validation.json'),
                          ('review_disposition_path','/tmp/freespace-root-cache4-source-review-disposition.json'),
                          ('review_prompt_path','/tmp/freespace-root-cache4-source-closure-prompt.txt')]:
            f[key] = path; f[key + '_sha256'] = m.digest(pathlib.Path(path).read_bytes())
        return f

    def test_actual_review_and_source_binding(self):
        freeze = self.make_freeze(); m.source_checks(freeze)
        freeze['baseline_source_epoch'] = '0'
        with self.assertRaises(ValueError): m.source_checks(freeze)

    def test_protocol_tamper_rejected(self):
        freeze = self.make_freeze(); freeze['protocol_sha256']['scripts/bench_v1_summary.py'] = 'bad'
        with self.assertRaises(ValueError): m.source_checks(freeze)

    def test_fixed_case_rejects_control_wrong_head(self):
        plan = dict(id=m.IDS[0], branch=m.BRANCHES[0], revision=m.BASE, baseline=m.BASE,
                    comparison='candidate', stage='screen', operations=['scan','refresh'], files=1000000,
                    expected_entries=1004499, pairs_per_operation=3, subtree_entries=100, scenario='unchanged',
                    memory_mib=4096, swap_mib=0, setup_memory_mib=4096, observer_memory_mib=4096, cpus=2, workers=1,
                    target=m.TARGET, io='local', timeout_minutes=55, forecast_seconds=1950,
                    forecast_with_margin_seconds=2535, maximum_job_seconds=5400, research_only=True,
                    artifact_prefix='/tmp/freespace-'+m.IDS[0], binary_artifact_prefix='/tmp/freespace-'+m.IDS[0]+'-binaries')
        m.fixed_case(plan, 0); plan['revision'] = m.CANDIDATE
        with self.assertRaises(ValueError): m.fixed_case(plan, 0)

    def test_journal_conflict_fails_closed(self):
        with tempfile.TemporaryDirectory() as directory:
            root = pathlib.Path(directory); journal = root / 'pending'; ledger = root / 'ledger'; mf = root / 'manifest'
            receipt = root / ('freespace-' + m.IDS[0] + '-dispatch.json')
            for p in (ledger, mf, receipt): p.write_text('changed')
            entries = [dict(path=str(p), old_sha256='wrong', new_sha256=m.digest(b'new'), new='new') for p in (ledger,mf,receipt)]
            journal.write_text(json.dumps(dict(version=1, plan_id=m.IDS[0], entries=entries)))
            with patch.multiple(m, JOURNAL=journal, LEDGER=ledger, MANIFEST=mf, RECEIPT_DIR=root):
                with self.assertRaises(ValueError): m.recover()
            self.assertTrue(journal.exists()); self.assertEqual(ledger.read_text(), 'changed')

    def test_budget_counts_running_maximum(self):
        ledger = dict(aggregate_cap_runner_seconds=m.CAP, planned_next_dispatches=[dict(maximum_job_seconds=5400)],
                      runs=[dict(status='in_progress', maximum_job_seconds=5400, completed_job_seconds=20)])
        m.accounting(ledger)
        self.assertEqual(ledger['maximum_committed_seconds'], 10800)

    def test_successful_control_recomputes_both_operations_and_rejects_oom(self):
        import sys, types
        from contextlib import ExitStack
        plan = dict(id=m.IDS[0], status='completed', conclusion='success', measurement_validation='valid', run_id=123,
                    artifact_prefix='/tmp/freespace-'+m.IDS[0], binary_artifact_prefix='/tmp/freespace-'+m.IDS[0]+'-binaries')
        manifest = dict(operation='scan', scenario='unchanged', files=1000000, memory_mib=4096,
                        subtree_entries=100, pairs=3, fixture_receipt={'expected_entries':1004499},
                        github={'GITHUB_SHA':m.BASE,'GITHUB_RUN_ID':'123'},environment={'image':[{'RepoTags':['representative-calibration:123-paired-local']}]},
                        expected_arms=[f'p{i}-{a}-v1' for i in (1,2,3) for a in ('baseline','candidate')],
                        provenance={a:dict(source_revision=m.BASE,sha256='hash',build=dict(source_revision=m.BASE,
                            sha256='hash',target=m.TARGET,flags={'SOURCE_DATE_EPOCH':m.EPOCH}))
                                    for a in ('baseline-v1','candidate-v1')})
        gh = dict(status='completed',conclusion='success',headSha=m.BASE,databaseId=123,
                  jobs=[{'name':'build','conclusion':'success'},{'name':'paired','conclusion':'success'}])
        metric = dict(exit_code=0,timed_out=False,validated=True,memory_mib=4096,timeout_seconds=1200,cpus=2,
                      cgroup_after={'memory.events':'oom 0\noom_kill 0\noom_group_kill 0'})
        summary = dict(valid=True,issues=[],pairs=[1,2,3])
        def fake_read(path):
            name=str(path)
            if name.endswith('-github.json'): return gh
            if name.endswith('summary.json'): return json.loads(json.dumps(summary))
            if name.endswith('manifest.json'): return dict(manifest,operation='refresh' if '/refresh/' in name else 'scan')
            if name.endswith('metrics.json'): return metric
            raise AssertionError(name)
        modules={'bench_v1_summary':types.SimpleNamespace(summarize=lambda _, require_runner_cleanup: summary if require_runner_cleanup else None),
                 'bench_v1_profile':types.SimpleNamespace(analyze=lambda _:dict(valid_structure=True,issues=[]))}
        with ExitStack() as stack:
            stack.enter_context(patch.dict(sys.modules,modules));stack.enter_context(patch.object(m,'read',side_effect=fake_read))
            stack.enter_context(patch.object(m,'fixed_case'));stack.enter_context(patch.object(m,'digest',return_value='hash'))
            stack.enter_context(patch.object(m,'fetch_run',return_value=({'id':123,'head_sha':m.BASE,'head_branch':m.BRANCHES[0], 'event':'workflow_dispatch','path':m.WORKFLOW,'run_attempt':1,'status':'completed','conclusion':'success'},[{'name':'build','status':'completed','conclusion':'success'},{'name':'paired','status':'completed','conclusion':'success'}])))
            stack.enter_context(patch.object(m,'fetch_log',return_value='mock log'));stack.enter_context(patch.object(m,'validate_log'));stack.enter_context(patch.object(m,'evidence_hashes',return_value={'input':'hash'}))
            stack.enter_context(patch.object(pathlib.Path,'read_bytes',return_value=b'binary'))
            self.assertEqual(m.valid_control(plan,{'runs':[plan]}),'hash')
            with patch.object(sys.modules['bench_v1_summary'], 'summarize', return_value=dict(summary, runner_cleanup_pending=True)):
                with self.assertRaises(ValueError):m.valid_control(plan,{'runs':[plan]})
            metric['cgroup_after']['memory.events']='oom 1\noom_kill 0\noom_group_kill 0'
            with self.assertRaises(ValueError):m.valid_control(plan,{'runs':[plan]})
            candidate=dict(plan,id=m.IDS[1]);live={'id':123,'head_sha':m.CANDIDATE,'head_branch':m.BRANCHES[1],
                 'event':'workflow_dispatch','path':m.WORKFLOW,'run_attempt':1,'status':'completed','conclusion':'success'}
            jobs=[{'name':'build','status':'completed','conclusion':'success'},{'name':'paired','status':'completed','conclusion':'success'}]
            with patch.object(m,'fetch_run',return_value=(live,jobs)),patch.object(m,'read',side_effect=lambda p:dict(gh,headSha=m.CANDIDATE)):
                with self.assertRaisesRegex(ValueError,'baseline'):m.validate_artifacts(candidate,{'runs':[candidate]},1,'wrong')
            metric['cgroup_after']['memory.events']='oom 0\noom_kill 0\noom_group_kill 0'
            gh['headSha']=m.CANDIDATE;manifest['github']['GITHUB_SHA']=m.CANDIDATE
            for arm,revision,binary in [('baseline-v1',m.BASE,'basehash'),('candidate-v1',m.CANDIDATE,'candidatehash')]:
                manifest['provenance'][arm].update(source_revision=revision,sha256=binary)
                manifest['provenance'][arm]['build'].update(source_revision=revision,sha256=binary)
            with patch.object(m,'fetch_run',return_value=(live,jobs)),patch.object(m,'digest',side_effect=['basehash','candidatehash']):
                self.assertEqual(m.validate_artifacts(candidate,{'runs':[candidate]},1,'basehash')[:2],('basehash','candidatehash'))

    def test_outside_review_exact_inputs_and_tampering(self):
        with tempfile.TemporaryDirectory() as directory:
            root=pathlib.Path(directory);draft=root/'draft.json';audit=root/'audit.json';draft.write_text('{}');audit.write_text('{}')
            paths=[pathlib.Path(m.__file__),pathlib.Path('/tmp/test-freespace-cache4-mechanism-admission.py'),draft,audit]
            entries={str(p):dict(content=p.read_text(),sha256=m.digest(p.read_bytes())) for p in paths}
            prompt=root/'prompt';prompt.write_text('review\nBEGIN_REVIEW_INPUTS_JSON\n'+json.dumps({'private_files':entries})+'\nEND_REVIEW_INPUTS_JSON\n')
            raw=root/'raw';raw.write_text(json.dumps(dict(status='completed',exit_code=0,result='NO_FINDINGS',modelUsage={'claude-opus-5-5':{}})))
            validation=root/'validation';validation.write_text(json.dumps(dict(valid=True,result='NO_FINDINGS',checked={'completed':True,'gate':'pass'})))
            review={}
            for key,path in [('prompt_path',prompt),('raw_path',raw),('validation_path',validation)]:
                review[key]=str(path);review[key+'_sha256']=m.digest(path.read_bytes())
            freeze=dict(outside_review=review,draft_manifest_path=str(draft),prereg_audit_path=str(audit))
            m.outside_review_checks(freeze)
            good=json.loads(raw.read_text())
            for altered in (dict(good,modelUsage={'wrong':{}}),dict(good,result='[P2] issue')):
                raw.write_text(json.dumps(altered));review['raw_path_sha256']=m.digest(raw.read_bytes())
                with self.assertRaises(ValueError):m.outside_review_checks(freeze)
            raw.write_text(json.dumps(good));review['raw_path_sha256']=m.digest(raw.read_bytes())
            validation.write_text(json.dumps(dict(valid=True,result='different',checked={'completed':True,'gate':'pass'})))
            review['validation_path_sha256']=m.digest(validation.read_bytes())
            with self.assertRaises(ValueError):m.outside_review_checks(freeze)
            validation.write_text(json.dumps(dict(valid=True,result='NO_FINDINGS',checked={'completed':True,'gate':'pass'})))
            review['validation_path_sha256']=m.digest(validation.read_bytes())
            for altered in (dict(list(entries.items())[:-1]), dict(entries, **{str(root/'extra'):{'content':'','sha256':m.digest(b'')}})):
                prompt.write_text('review\nBEGIN_REVIEW_INPUTS_JSON\n'+json.dumps({'private_files':altered})+'\nEND_REVIEW_INPUTS_JSON\n')
                review['prompt_path_sha256']=m.digest(prompt.read_bytes())
                with self.assertRaises(ValueError):m.outside_review_checks(freeze)
            prompt.write_text('review\nBEGIN_REVIEW_INPUTS_JSON\n'+json.dumps({'private_files':entries})+'\nEND_REVIEW_INPUTS_JSON\n')
            review['prompt_path_sha256']=m.digest(prompt.read_bytes())
            draft.write_text('{"tampered":true}')
            with self.assertRaises(ValueError):m.outside_review_checks(freeze)

    def test_historical_allowlist_and_unknown_run(self):
        row=dict(databaseId=11,headSha=m.BASE,event='workflow_dispatch',createdAt='2026-11-01T01:00:00Z')
        freeze=dict(launch_cutoff='2026-11-01T02:00:00Z',historical_workflow_runs=[dict(row,branch=m.BRANCHES[0])])
        m.check_historical_runs([row],freeze,0,{'runs':[]})
        with self.assertRaises(ValueError):
            m.check_historical_runs([row,dict(row,databaseId=12)],freeze,0,{'runs':[]})
        with self.assertRaises(ValueError):m.check_historical_runs([],freeze,0,{'runs':[]})
        bad=dict(freeze, launch_cutoff='2026-11-01T00:00:00Z')
        with self.assertRaises(ValueError):m.check_historical_runs([row],bad,0,{'runs':[]})

    def test_register_recovery_and_failed_terminal_refresh(self):
        from contextlib import ExitStack
        with tempfile.TemporaryDirectory() as directory:
            root=pathlib.Path(directory); ledger=root/'ledger'; mf=root/'manifest'; freeze=root/'freeze'; journal=root/'pending'
            receipt=root/('freespace-'+m.IDS[0]+'-dispatch.json')
            plan=dict(id=m.IDS[0],status='planned',branch=m.BRANCHES[0],revision=m.BASE,maximum_job_seconds=5400)
            frozen={'helper_sha256':m.digest(pathlib.Path(m.__file__).read_bytes()),'historical_workflow_runs':[]}
            freeze.write_text(json.dumps(frozen)); mf.write_text(json.dumps(dict(status='registered',research_only=True,
                product_qualification=False,candidate_revision=m.CANDIDATE,source_hash_manifest_sha256=m.digest(freeze.read_bytes()),plans=[plan])))
            ledger.write_text(json.dumps(dict(aggregate_cap_runner_seconds=m.CAP,planned_next_dispatches=[plan],runs=[],run_ids=[])))
            receipt.write_text(json.dumps(dict(plan_id=m.IDS[0],expected_head_sha=m.BASE,dispatched=True,dispatch_attempted_at='2026-11-01T00:00:00Z')))
            run=dict(id=123,head_sha=m.BASE,head_branch=m.BRANCHES[0],event='workflow_dispatch',path=m.WORKFLOW,
                     run_attempt=1,status='queued',created_at='2026-11-01T00:00:01Z',conclusion=None)
            with ExitStack() as stack:
                stack.enter_context(patch.multiple(m,LEDGER=ledger,MANIFEST=mf,FREEZE=freeze,JOURNAL=journal,RECEIPT_DIR=root))
                stack.enter_context(patch.object(m,'fixed_case'));stack.enter_context(patch.object(m,'source_checks'));stack.enter_context(patch.object(m,'outside_review_checks'));stack.enter_context(patch.object(m,'bind_manifest'));stack.enter_context(patch.object(m,'registered_identity'))
                earlier=dict(run,created_at='2026-10-31T23:59:59Z')
                with self.assertRaisesRegex(ValueError, 'predates'):m.update('register',m.IDS[0],123,earlier,[])
                frozen['historical_workflow_runs']=[{'databaseId':123}];freeze.write_text(json.dumps(frozen))
                data=json.loads(mf.read_text());data['source_hash_manifest_sha256']=m.digest(freeze.read_bytes());mf.write_text(json.dumps(data))
                with self.assertRaisesRegex(ValueError, 'historical'):m.update('register',m.IDS[0],123,run,[])
                frozen['historical_workflow_runs']=[];freeze.write_text(json.dumps(frozen))
                data['source_hash_manifest_sha256']=m.digest(freeze.read_bytes());mf.write_text(json.dumps(data))
                with patch.object(m,'recover',side_effect=RuntimeError('interrupted after durable journal')):
                    with self.assertRaises(RuntimeError):m.update('register',m.IDS[0],123,run,[])
                self.assertTrue(journal.exists());m.recover();self.assertFalse(journal.exists())
                current=json.loads(ledger.read_text());self.assertEqual(current['runs'][0],json.loads(mf.read_text())['plans'][0])
                self.assertEqual(current['maximum_committed_seconds'],5400);self.assertEqual(current['planned_next_dispatches'],[])
                run.update(status='completed',conclusion='failure')
                jobs=[dict(name='build',status='completed',conclusion='failure',started_at='2026-11-01T00:00:01Z',completed_at='2026-11-01T00:01:41Z'),
                      dict(name='paired',status='completed',conclusion='skipped',started_at=None,completed_at=None)]
                m.update('refresh',m.IDS[0],123,run,jobs)
                current=json.loads(ledger.read_text());self.assertEqual(current['runs'][0],json.loads(mf.read_text())['plans'][0])
                self.assertEqual(current['maximum_committed_seconds'],100);self.assertEqual(current['planned_reserved_seconds'],0)
                self.assertFalse(journal.exists())

    def test_uncertain_dispatch_is_durable_and_cannot_replay(self):
        from contextlib import ExitStack
        with tempfile.TemporaryDirectory() as directory:
            root=pathlib.Path(directory);mf=root/'manifest';ledger=root/'ledger';freeze=root/'freeze'
            plan=dict(id=m.IDS[0],status='planned',maximum_job_seconds=5400,forecast_seconds=1950,
                      forecast_with_margin_seconds=2535,scan_profile='disk',runner_preparation_policy='sdk-space-v1',
                      measurement_protocol='v1-single-operation-pairs-v4')
            freeze.write_text('{}');mf.write_text(json.dumps(dict(status='registered',research_only=True,product_qualification=False,
                candidate_revision=m.CANDIDATE,source_hash_manifest_sha256=m.digest(freeze.read_bytes()),plans=[plan,dict(id=m.IDS[1])])))
            ledger.write_text(json.dumps(dict(aggregate_cap_runner_seconds=m.CAP,planned_next_dispatches=[plan],runs=[],
                planned_reserved_seconds=5400,maximum_committed_seconds=5400,remaining_unreserved_seconds=m.CAP-5400)))
            def command(args,cwd=m.WT):
                ref=args[-1];index=m.BRANCHES.index(ref.removeprefix('refs/heads/'));return m.HEADS[index]+'\t'+ref
            with ExitStack() as stack:
                stack.enter_context(patch.multiple(m,MANIFEST=mf,LEDGER=ledger,FREEZE=freeze,RECEIPT_DIR=root,JOURNAL=root/'pending'))
                stack.enter_context(patch.object(m,'fixed_case'));stack.enter_context(patch.object(m,'source_checks'));stack.enter_context(patch.object(m,'outside_review_checks'));stack.enter_context(patch.object(m,'bind_manifest'))
                stack.enter_context(patch.object(m,'command',side_effect=command));stack.enter_context(patch.object(m,'gh_json',side_effect=TimeoutError('uncertain')))
                result=m.admit(m.IDS[0],True);self.assertIs(result['dispatched'],False)
                receipt=root/('freespace-'+m.IDS[0]+'-dispatch.json');self.assertTrue(receipt.exists())
                with self.assertRaises(ValueError):m.admit(m.IDS[0],True)
                self.assertEqual(json.loads(receipt.read_text())['dispatch_outcome'],'not_dispatched')

    def test_registration_unique_window_and_historical_exclusion(self):
        freeze={'historical_workflow_runs':[],'launch_cutoff':'2026-11-01T00:00:00Z'}
        receipt={'dispatch_attempted_at':'2026-11-01T01:00:00.999999+00:00'}
        row={'databaseId':123,'headSha':m.BASE,'event':'workflow_dispatch','createdAt':'2026-11-01T01:00:00Z'}
        run={'created_at':row['createdAt']};ledger={'runs':[]}
        with patch.object(m,'listing_for',return_value=[row]):m.registered_identity(123,run,receipt,freeze,ledger,0)
        with patch.object(m,'listing_for',return_value=[row,dict(row,databaseId=124)]):
            with self.assertRaises(ValueError):m.registered_identity(123,run,receipt,freeze,ledger,0)
        earlier=dict(row,databaseId=125,createdAt='2026-11-01T00:59:59Z')
        with patch.object(m,'listing_for',return_value=[row,earlier]):
            with self.assertRaises(ValueError):m.registered_identity(123,run,receipt,freeze,ledger,0)
        late=dict(row,createdAt='2026-11-01T01:05:02Z')
        with patch.object(m,'listing_for',return_value=[late]):
            with self.assertRaises(ValueError):m.registered_identity(123,{'created_at':late['createdAt']},receipt,freeze,ledger,0)

    def test_manifest_policy_and_extra_keys_are_bound(self):
        import copy
        draft={'status':'registered','plans':[{'id':'x','status':'planned','policy':'safe'}],'gates':['strict']}
        with tempfile.TemporaryDirectory() as directory:
            path=pathlib.Path(directory)/'draft';path.write_text(json.dumps(draft));freeze={'draft_manifest_path':str(path)}
            live=copy.deepcopy(draft);live['source_hash_manifest_sha256']='hash';m.bind_manifest(live,freeze)
            live['gates']=['relaxed']
            with self.assertRaises(ValueError):m.bind_manifest(live,freeze)
            live=copy.deepcopy(draft);live['plans'][0]['undocumented']=True
            with self.assertRaises(ValueError):m.bind_manifest(live,freeze)

    def test_partial_journal_recovery(self):
        with tempfile.TemporaryDirectory() as directory:
            root=pathlib.Path(directory);ledger=root/'ledger';mf=root/'manifest';journal=root/'pending';receipt=root/('freespace-'+m.IDS[0]+'-dispatch.json')
            paths=(ledger,mf,receipt)
            for p in paths:p.write_text('old')
            entries=[dict(path=str(p),old_sha256=m.digest(b'old'),new_sha256=m.digest(b'new'),new='new') for p in paths]
            journal.write_text(json.dumps(dict(version=1,plan_id=m.IDS[0],entries=entries)));ledger.write_text('new')
            with patch.multiple(m,JOURNAL=journal,LEDGER=ledger,MANIFEST=mf,RECEIPT_DIR=root):self.assertTrue(m.recover())
            self.assertTrue(all(p.read_text()=='new' for p in paths));self.assertFalse(journal.exists())

    def test_truncated_listing_rejected(self):
        with patch.object(m,'gh_json',return_value=[{}]*100):
            with self.assertRaises(ValueError):m.listing_for(0)

    def test_dispatch_success_and_nonzero_uncertain(self):
        import types
        from contextlib import ExitStack
        for code in (0,1):
            with self.subTest(code=code), tempfile.TemporaryDirectory() as directory:
                root=pathlib.Path(directory);mf=root/'manifest';ledger=root/'ledger';freeze=root/'freeze'
                plan=dict(id=m.IDS[0],status='planned',maximum_job_seconds=5400,forecast_seconds=1950,forecast_with_margin_seconds=2535,
                          scan_profile='disk',runner_preparation_policy='sdk-space-v1',measurement_protocol='v1-single-operation-pairs-v4')
                freeze.write_text('{}');mf.write_text(json.dumps(dict(status='registered',research_only=True,product_qualification=False,
                    candidate_revision=m.CANDIDATE,source_hash_manifest_sha256=m.digest(freeze.read_bytes()),plans=[plan,dict(id=m.IDS[1])])))
                ledger.write_text(json.dumps(dict(aggregate_cap_runner_seconds=m.CAP,planned_next_dispatches=[plan],runs=[],
                    planned_reserved_seconds=5400,maximum_committed_seconds=5400,remaining_unreserved_seconds=m.CAP-5400)))
                def command(args,cwd=m.WT):
                    ref=args[-1];index=m.BRANCHES.index(ref.removeprefix('refs/heads/'));return m.HEADS[index]+'\t'+ref
                with ExitStack() as stack:
                    stack.enter_context(patch.multiple(m,MANIFEST=mf,LEDGER=ledger,FREEZE=freeze,RECEIPT_DIR=root,JOURNAL=root/'pending'))
                    for name in ('fixed_case','source_checks','outside_review_checks','bind_manifest','check_historical_runs'):stack.enter_context(patch.object(m,name))
                    stack.enter_context(patch.object(m,'command',side_effect=command));stack.enter_context(patch.object(m,'gh_json',return_value={'nameWithOwner':'x/y'}))
                    stack.enter_context(patch.object(m,'listing_for',return_value=[]))
                    submit=stack.enter_context(patch.object(m.subprocess,'run',return_value=types.SimpleNamespace(returncode=code,stdout='',stderr='')))
                    result=m.admit(m.IDS[0],True);self.assertEqual(submit.call_count,1)
                    self.assertEqual(result['dispatched'],True if code==0 else None)
                    self.assertEqual(json.loads((root/('freespace-'+m.IDS[0]+'-dispatch.json')).read_text())['dispatched'],result['dispatched'])
                    with self.assertRaises(ValueError):m.admit(m.IDS[0],True)
                    self.assertEqual(submit.call_count,1)

    def test_candidate_prerequisite_and_remote_and_budget(self):
        from contextlib import ExitStack
        with tempfile.TemporaryDirectory() as directory:
            root=pathlib.Path(directory);mf=root/'manifest';ledger=root/'ledger';freeze=root/'freeze'
            control=dict(id=m.IDS[0],status='completed',conclusion='success',measurement_validation='valid')
            plan=dict(id=m.IDS[1],status='planned',maximum_job_seconds=5400,forecast_seconds=1950,forecast_with_margin_seconds=2535,
                      scan_profile='disk',runner_preparation_policy='sdk-space-v1',measurement_protocol='v1-single-operation-pairs-v4')
            freeze.write_text('{}');mf.write_text(json.dumps(dict(status='registered',research_only=True,product_qualification=False,
                candidate_revision=m.CANDIDATE,source_hash_manifest_sha256=m.digest(freeze.read_bytes()),plans=[control,plan])))
            data=dict(aggregate_cap_runner_seconds=m.CAP,planned_next_dispatches=[plan],runs=[dict(control,completed_job_seconds=100)],
                planned_reserved_seconds=5400,maximum_committed_seconds=5500,remaining_unreserved_seconds=m.CAP-5500)
            ledger.write_text(json.dumps(data))
            def command(args,cwd=m.WT):
                ref=args[-1];index=m.BRANCHES.index(ref.removeprefix('refs/heads/'));return m.HEADS[index]+'\t'+ref
            with ExitStack() as stack:
                stack.enter_context(patch.multiple(m,MANIFEST=mf,LEDGER=ledger,FREEZE=freeze,RECEIPT_DIR=root,JOURNAL=root/'pending'))
                for name in ('fixed_case','source_checks','outside_review_checks','bind_manifest'):stack.enter_context(patch.object(m,name))
                control_check=stack.enter_context(patch.object(m,'valid_control',return_value='observed'))
                remote=stack.enter_context(patch.object(m,'command',side_effect=command))
                result=m.admit(m.IDS[1],False);self.assertEqual(result['expected_baseline_binary_sha256'],'observed')
                control_check.assert_called_once();self.assertEqual(remote.call_count,2)
                remote.side_effect=lambda *a,**k:'mismatch'
                with self.assertRaises(ValueError):m.admit(m.IDS[1],False)
                data['maximum_committed_seconds']=m.CAP+1;ledger.write_text(json.dumps(data))
                with self.assertRaises(ValueError):m.admit(m.IDS[1],False)

    def test_invalid_measurement_is_journalled_without_losing_accounting(self):
        from contextlib import ExitStack
        with tempfile.TemporaryDirectory() as directory:
            root=pathlib.Path(directory);ledger=root/'ledger';mf=root/'manifest';freeze=root/'freeze';journal=root/'pending'
            receipt=root/('freespace-'+m.IDS[0]+'-dispatch.json')
            plan=dict(id=m.IDS[0],status='completed',conclusion='failure',measurement_validation='unverified',completed_job_seconds=100)
            freeze.write_text('{}');mf.write_text(json.dumps(dict(source_hash_manifest_sha256=m.digest(freeze.read_bytes()),plans=[plan])))
            ledger.write_text(json.dumps(dict(runs=[plan],maximum_committed_seconds=100)));receipt.write_text('{}')
            with ExitStack() as stack:
                stack.enter_context(patch.multiple(m,LEDGER=ledger,MANIFEST=mf,FREEZE=freeze,JOURNAL=journal,RECEIPT_DIR=root))
                for name in ('bind_manifest','source_checks','outside_review_checks'):stack.enter_context(patch.object(m,name))
                stack.enter_context(patch.object(m,'validate_artifacts',side_effect=m.EvidenceMismatch('hash mismatch')))
                self.assertEqual(m.validate_result(m.IDS[0])['measurement_validation'],'invalid')
                l=json.loads(ledger.read_text());self.assertEqual(l['maximum_committed_seconds'],100)
                self.assertEqual(l['runs'][0],json.loads(mf.read_text())['plans'][0]);self.assertFalse(journal.exists())

    def test_real_historical_log_parser_and_mismatch(self):
        raw=pathlib.Path('/tmp/freespace-root-reuse-candidate-screen-gh.log').read_text()
        with patch.object(m,'BASE','e8265778ef78ec4acd9da1375eedb0be37a123f5'):
            m.validate_log(raw,1)
            with self.assertRaises(m.EvidenceMismatch):m.validate_log(raw.replace('BENCH_IO: local','BENCH_IO: missing'),1)

    def test_infrastructure_failure_stays_unverified_then_validation_is_idempotent(self):
        from contextlib import ExitStack
        with tempfile.TemporaryDirectory() as directory:
            root=pathlib.Path(directory);ledger=root/'ledger';mf=root/'manifest';freeze=root/'freeze';journal=root/'pending'
            receipt=root/('freespace-'+m.IDS[0]+'-dispatch.json')
            plan=dict(id=m.IDS[0],status='completed',conclusion='success',measurement_validation='unverified',completed_job_seconds=100)
            freeze.write_text('{}');mf.write_text(json.dumps(dict(source_hash_manifest_sha256=m.digest(freeze.read_bytes()),plans=[plan])))
            ledger.write_text(json.dumps(dict(runs=[plan],maximum_committed_seconds=100)));receipt.write_text('{}')
            with ExitStack() as stack:
                stack.enter_context(patch.multiple(m,LEDGER=ledger,MANIFEST=mf,FREEZE=freeze,JOURNAL=journal,RECEIPT_DIR=root))
                for name in ('bind_manifest','source_checks','outside_review_checks'):stack.enter_context(patch.object(m,name))
                for error in (FileNotFoundError('missing'),m.subprocess.TimeoutExpired('gh',60)):
                    with patch.object(m,'validate_artifacts',side_effect=error):
                        with self.assertRaises(type(error)):m.validate_result(m.IDS[0])
                    self.assertEqual(json.loads(ledger.read_text())['runs'][0]['measurement_validation'],'unverified')
                    self.assertFalse(journal.exists())
                with patch.object(m,'validate_artifacts',return_value=('b','b',{'input':'sha'})):
                    self.assertEqual(m.validate_result(m.IDS[0])['measurement_validation'],'valid')
                with patch.object(m,'validate_artifacts',side_effect=AssertionError('must not repeat')):
                    self.assertEqual(m.validate_result(m.IDS[0])['measurement_validation'],'valid')

    def test_candidate_validation_success_records_both_hashes(self):
        from contextlib import ExitStack
        with tempfile.TemporaryDirectory() as directory:
            root=pathlib.Path(directory);ledger=root/'ledger';mf=root/'manifest';freeze=root/'freeze';journal=root/'pending'
            receipt=root/('freespace-'+m.IDS[1]+'-dispatch.json')
            control=dict(id=m.IDS[0],status='completed',measurement_validation='valid')
            candidate=dict(id=m.IDS[1],status='completed',measurement_validation='unverified',completed_job_seconds=100)
            freeze.write_text('{}');mf.write_text(json.dumps(dict(source_hash_manifest_sha256=m.digest(freeze.read_bytes()),plans=[control,candidate])))
            ledger.write_text(json.dumps(dict(runs=[control,candidate],maximum_committed_seconds=100)))
            receipt.write_text(json.dumps({'expected_baseline_binary_sha256':'base'}))
            with ExitStack() as stack:
                stack.enter_context(patch.multiple(m,LEDGER=ledger,MANIFEST=mf,FREEZE=freeze,JOURNAL=journal,RECEIPT_DIR=root))
                for name in ('bind_manifest','source_checks','outside_review_checks'):stack.enter_context(patch.object(m,name))
                stack.enter_context(patch.object(m,'valid_control',return_value='base'))
                validate=stack.enter_context(patch.object(m,'validate_artifacts',return_value=('base','candidate',{})))
                self.assertEqual(m.validate_result(m.IDS[1])['measurement_validation'],'valid')
                self.assertEqual(validate.call_args.args[3],'base')
                recorded=json.loads(ledger.read_text())['runs'][1]
                self.assertEqual((recorded['observed_baseline_sha256'],recorded['observed_candidate_sha256']),('base','candidate'))
                self.assertTrue(recorded['evidence_sha256'])

    def test_failed_control_stops_before_raw_read(self):
        plan = dict(id=m.IDS[0], status='completed', conclusion='failure')
        with self.assertRaises(ValueError): m.valid_control(plan, {'runs':[plan]})


if __name__ == '__main__': unittest.main()
