#!/usr/bin/env python3
"""Planning estimates and fail-closed admission for the v1 benchmark.

These are explicit planning allowances, not measured peaks or universal filesystem
upper bounds. They apply only to the mixed metadata fixture described below;
filesystem overhead and SQLite growth must be checked against observations.
"""
import math
import os
import re
import subprocess

GIB = 1024 ** 3
V1_VOLUME_GIB = 40
V1_HARD_FLOOR_GIB = 42
V1_PREP_HEADROOM_GIB = 2
RUNNER_PREPARATION_POLICY = 'sdk-space-v1'
CANONICAL_BASELINE = 'e8265778ef78ec4acd9da1375eedb0be37a123f5'


def validate_changed_full_baseline(scenario, comparison, revision):
    if scenario == 'changed-full' and (comparison != 'candidate' or revision != CANONICAL_BASELINE):
        raise ValueError('changed-full requires candidate comparison and canonical baseline')


def valid_runner_preparation(context):
    try:
        return (isinstance(context, dict) and context.get('success') is True
                and type(context.get('acted')) is bool and type(context.get('freed_bytes')) is int
                and isinstance(context.get('duration_seconds'), (int, float))
                and not isinstance(context.get('duration_seconds'), bool)
                and math.isfinite(context['duration_seconds']) and context['duration_seconds'] >= 0
                and type(context.get('floor_bytes')) is int and context['floor_bytes'] == V1_HARD_FLOOR_GIB * GIB
                and type(context.get('target_bytes')) is int
                and context['target_bytes'] == (V1_HARD_FLOOR_GIB + V1_PREP_HEADROOM_GIB) * GIB)
    except (KeyError, OverflowError):
        return False


def runner_preparation_context(receipt):
    if not isinstance(receipt, dict) or receipt.get('success') is not True or not isinstance(receipt.get('actions'), list):
        raise ValueError('runner preparation did not succeed')
    try:
        before, after = receipt['before']['available_bytes'], receipt['after']['available_bytes']
        if type(before) is not int or type(after) is not int or min(before, after) < 0 or after < (V1_HARD_FLOOR_GIB + V1_PREP_HEADROOM_GIB) * GIB:
            raise ValueError('invalid preparation disk counters')
        if any(not isinstance(action, dict) or action.get('status') not in ('removed', 'skipped-unsafe-or-absent') for action in receipt['actions']):
            raise ValueError('invalid preparation actions')
        # On successful runs, acted means a removal completed. Failure-step
        # summaries use possibly_modified to include partial or interrupted work.
        context = dict(success=True, acted=any(action['status'] == 'removed' for action in receipt['actions']),
                       freed_bytes=after - before, duration_seconds=receipt['duration_seconds'],
                       floor_bytes=receipt['floor_bytes'], target_bytes=receipt['target_bytes'])
    except (KeyError, TypeError) as error:
        raise ValueError('invalid preparation receipt') from error
    if not valid_runner_preparation(context):
        raise ValueError('invalid preparation context')
    return context


def baseline_epoch(ref):
    """Resolve one commit safely and derive the common reproducible build epoch."""
    resolved = subprocess.check_output(
        ['git', 'rev-parse', '--verify', '--end-of-options', ref + '^{commit}'], text=True).strip()
    if not re.fullmatch(r'[0-9a-f]{40,64}', resolved):
        raise ValueError('invalid resolved baseline commit')
    stamp = subprocess.check_output(['git', 'show', '-s', '--format=%ct', resolved], text=True).strip()
    if not stamp.isascii() or not stamp.isdecimal():
        raise ValueError('invalid baseline commit timestamp')
    return resolved, int(stamp)


def _count(name, value):
    if isinstance(value, bool) or not isinstance(value, int) or value < 0:
        raise ValueError(f"{name} must be a nonnegative integer")


def estimate_capacity(files: int, expected_entries: int, seed_bytes: int = 0,
                      reserve_bytes: int = 2 * GIB) -> dict:
    """Estimate additional space, including all potentially coexisting copies.

    Assumes at most 1% of files allocate a 4 KiB payload block, plus 16 MiB
    for sparse extents; 512 bytes per entry for inode/directory metadata; and
    512 bytes per entry for each of four snapshot-sized files (current,
    previous, stage and output). The original seed remains present in addition
    to those files. Reserve covers other transient overhead. These constants are
    planning assumptions, not guarantees for arbitrary filesystems or schemas.
    """
    for name, value in (("files", files), ("expected_entries", expected_entries),
                        ("seed_bytes", seed_bytes), ("reserve_bytes", reserve_bytes)):
        _count(name, value)
    if expected_entries < files:
        raise ValueError("expected_entries must include all fixture files")
    components = {
        "fixture_metadata_bytes": expected_entries * 512,
        "fixture_payload_bytes": ((files + 99) // 100) * 4096,
        "sparse_extent_bytes": 16 * 1024 ** 2,
        "current_snapshot_bytes": expected_entries * 512,
        "previous_snapshot_bytes": expected_entries * 512,
        "stage_snapshot_bytes": expected_entries * 512,
        "output_snapshot_bytes": expected_entries * 512,
        "retained_seed_bytes": seed_bytes,
        "reserve_bytes": reserve_bytes,
    }
    return {
        "files": files,
        "expected_entries": expected_entries,
        "components": components,
        "required_bytes": sum(components.values()),
        "required_inodes": expected_entries + 10000,
        "assumptions": "Planning allowances, not measured peaks or filesystem-independent upper bounds; "
                       "1% allocated 4 KiB payload blocks, 16 MiB sparse extents, "
                       "512 bytes per fixture entry and per entry in each of four coexisting snapshots; "
                       "seed retained separately, plus byte and inode reserves.",
    }


def check_capacity(path, files: int, expected_entries: int, seed_bytes: int = 0,
                   reserve_bytes: int = 2 * GIB) -> dict:
    """Compare planning requirements with available blocks and inodes at path."""
    estimate = estimate_capacity(files, expected_entries, seed_bytes, reserve_bytes)
    receipt = dict(estimate, path=os.fspath(path), success=False)
    try:
        stats = os.statvfs(path)
        block_size = stats.f_frsize or stats.f_bsize
        if block_size <= 0 or stats.f_bavail < 0 or stats.f_favail < 0:
            raise ValueError("invalid statvfs availability")
        receipt["available_bytes"] = stats.f_bavail * block_size
        receipt["available_inodes"] = stats.f_favail
        receipt["success"] = (receipt["available_bytes"] >= estimate["required_bytes"] and
                              receipt["available_inodes"] >= estimate["required_inodes"])
        if not receipt["success"]:
            receipt["error"] = "insufficient available bytes or inodes"
    except (OSError, ValueError, AttributeError) as error:
        receipt["error"] = str(error)
    return receipt


def admit_time(remaining_seconds, estimated_seconds, margin=0.3) -> dict:
    """Fail closed when time is unknown or cannot accommodate the margin."""
    receipt = dict(remaining_seconds=remaining_seconds, estimated_seconds=estimated_seconds,
                   margin=margin, success=False)
    values = (remaining_seconds, estimated_seconds, margin)
    if any(isinstance(v, bool) or not isinstance(v, (int, float)) or not math.isfinite(v)
           for v in values) or remaining_seconds <= 0 or estimated_seconds <= 0 or margin < 0:
        receipt["error"] = "time estimate and remaining time must be positive and margin nonnegative"
        return receipt
    receipt["required_seconds"] = estimated_seconds * (1 + margin)
    receipt["success"] = math.isfinite(receipt["required_seconds"]) and remaining_seconds >= receipt["required_seconds"]
    if not receipt["success"]:
        receipt["error"] = "insufficient remaining time"
    return receipt


def benchmark_target(requested) -> str:
    """Validate the explicit compilation target for both benchmark arms."""
    if not isinstance(requested, str) or requested not in (
            "x86_64-unknown-linux-gnu", "x86_64-unknown-linux-musl"):
        raise ValueError("unknown benchmark target")
    return requested


def stage_files(stage):
    sizes = {'smoke': 100000, 'screen': 1000000, 'local-scale': 7264383}
    if stage not in sizes:
        raise ValueError('unknown benchmark stage')
    return sizes[stage]


def forecast_case_id(target, io, operations, subtree, scenario, memory):
    benchmark_target(target)
    if io not in ('native', 'local', 'limited') or operations not in (['scan'], ['refresh'], ['scan', 'refresh']):
        raise ValueError('invalid case I/O or operations')
    qualification_case(subtree, scenario, memory, operations, 8000000)
    return '|'.join((target, io, '+'.join(operations), subtree, scenario, memory))


def qualification_case(subtree, scenario, memory, operations, files) -> dict:
    """Validate one ordinary successful-operation case before allocation."""
    if subtree not in ('100', '10000', '100000') or int(subtree) > files:
        raise ValueError('invalid subtree size for stage')
    if scenario not in ('unchanged', 'changed', 'changed-full'):
        raise ValueError('invalid scenario')
    if memory not in ('512', '1024', '2048', '4096'):
        raise ValueError('invalid ordinary memory budget')
    if scenario != 'unchanged' and operations != ['refresh']:
        raise ValueError('changed scenario requires refresh only')
    return dict(subtree_entries=int(subtree), scenario=scenario, memory_mib=int(memory))


def stage_operations(stage, requested='auto') -> list:
    """Return the validated, ordered operations for a campaign stage."""
    defaults = {"smoke": ["scan"], "screen": ["scan", "refresh"], "local-scale": ["scan"]}
    if not isinstance(stage, str) or stage not in defaults:
        raise ValueError("unknown benchmark stage")
    if not isinstance(requested, str) or requested not in ("auto", "scan", "refresh"):
        raise ValueError("unknown benchmark operation selector")
    return defaults[stage] if requested == "auto" else [requested]


def stage_timeouts(stage, requested_minutes=None) -> dict:
    """Return bounded step, job and total runner budgets for a campaign stage."""
    caps = {"smoke": 30, "screen": 65, "local-scale": 120}
    if not isinstance(stage, str) or stage not in caps:
        raise ValueError("unknown benchmark stage")
    if requested_minutes is None or requested_minutes == "":
        minutes = caps[stage]
    elif isinstance(requested_minutes, bool):
        raise ValueError("requested minutes must be an integer within the stage cap")
    elif isinstance(requested_minutes, int):
        minutes = requested_minutes
    elif isinstance(requested_minutes, str) and requested_minutes.isascii() and requested_minutes.isdecimal():
        minutes = int(requested_minutes)
    else:
        raise ValueError("requested minutes must be an integer within the stage cap")
    if not 1 <= minutes <= caps[stage]:
        raise ValueError("requested minutes must be an integer within the stage cap")
    return dict(step_minutes=minutes, job_minutes=minutes + 10, build_minutes=25,
                maximum_runner_minutes=minutes + 35)
