#!/usr/bin/env python3
"""GitHub-runner Docker benchmark. Never use the loaded development host.

Host: --baseline BIN --candidate BIN --output DIR [--steps 100000,1000000]
      [--memory 128|256|512|4096] [--repeats 2] [--include-v1]
      [--current-backends] [--scan-profile disk|memory|both]
      [--keep-previous both|true|false] [--cpus 2] [--workers 1] [--refreshes 1]
      [--io-device /dev/DEVICE --read-bps N --write-bps N --read-iops N --write-iops N]
Each comparison arm receives a fresh configurable CPU, no-swap cgroup; bind-mounted fixtures
and snapshots bypass overlayfs. On a dedicated ephemeral GitHub-hosted VM,
host fixture setup is synced and caches dropped before each arm container.
Peaks sampled at 20ms are lower bounds; cgroup memory.peak is arm-cumulative
for CLI/helper/observations, excluding host setup. RSS covers each CLI process.
"""

from contextlib import closing
import hashlib
import json
import os
from pathlib import Path
import platform
import shutil
import signal
import sqlite3
import stat
import subprocess
import sys
import tempfile
import threading
import time
import uuid

from bench_v2_config import parse_arguments, profile_arguments


def dump(path, value):
    path.write_text(json.dumps(value, indent=2) + "\n")


def capture(command, **kwargs):
    return subprocess.check_output(command, text=True, timeout=120, **kwargs).strip()


def occupancy(snapshot):
    result = {name: {"logical_bytes": 0, "allocated_bytes": 0}
              for name in ("db", "wal", "shm", "stage", "other", "total")}
    for file in snapshot.rglob("*"):
        try:
            stat = file.stat()
            if not file.is_file():
                continue
        except FileNotFoundError:
            continue
        name = file.name
        kind = ("stage" if ".stage.tmp" in name else "wal" if name.endswith("-wal")
                else "shm" if name.endswith("-shm") else "db" if name.endswith(".db") else "other")
        for key in (kind, "total"):
            result[key]["logical_bytes"] += stat.st_size
            result[key]["allocated_bytes"] += stat.st_blocks * 512
    return result


def filesystem_used(path):
    """Allocated bytes across the filesystem, including open unlinked files."""
    usage = os.statvfs(path)
    return (usage.f_blocks - usage.f_bfree) * usage.f_frsize


def file_occupancy(snapshot):
    result = {}
    for file in snapshot.rglob("*"):
        try:
            stat = file.stat()
            if file.is_file():
                result[str(file.relative_to(snapshot))] = dict(logical_bytes=stat.st_size,
                                                              allocated_bytes=stat.st_blocks * 512)
        except FileNotFoundError:
            pass
    return result


def snapshot_integrity(snapshot):
    """Hash named regular files in bounded chunks, outside command timing."""
    result = {}
    for file in sorted(snapshot.rglob("*")):
        if not file.is_file():
            continue
        before = file.stat()
        digest = hashlib.sha256()
        with file.open("rb") as stream:
            for chunk in iter(lambda: stream.read(1024 * 1024), b""):
                digest.update(chunk)
        after = file.stat()
        if before.st_size != after.st_size:
            raise RuntimeError(f"file size changed while hashing {file}")
        result[str(file.relative_to(snapshot))] = dict(logical_bytes=after.st_size,
                                                       sha256=digest.hexdigest())
    return result


def observer_comparison(before_integrity, after_integrity, before_allocation, after_allocation):
    # st_blocks can settle asynchronously after a writer exits. It remains a
    # measurement, not a substitute for logical/content mutation detection.
    return dict(integrity_before=before_integrity, integrity_after=after_integrity,
                files_before=before_allocation, files_after=after_allocation,
                logical_content_unchanged=before_integrity == after_integrity,
                files_unchanged=before_allocation == after_allocation,
                allocation_drift={name: dict(before=before_allocation.get(name),
                                             after=after_allocation.get(name))
                                  for name in sorted(before_allocation.keys() | after_allocation.keys())
                                  if before_allocation.get(name) != after_allocation.get(name)})


def cgroup():
    relative = next(line[3:] for line in Path("/proc/self/cgroup").read_text().splitlines()
                    if line.startswith("0::"))
    # Docker's private cgroup namespace exposes the container group at its root.
    candidates = [Path("/sys/fs/cgroup") / relative.lstrip("/"), Path("/sys/fs/cgroup")]
    return next(folder for folder in candidates if (folder / "memory.max").exists())


def cg_read(folder):
    return {name: (folder / name).read_text().strip() for name in (
        "memory.current", "memory.peak", "memory.max", "memory.stat", "memory.events",
        "memory.swap.current", "memory.swap.peak", "memory.swap.max", "memory.pressure",
        "cpu.max", "cpu.stat", "io.max", "io.stat", "io.pressure") if (folder / name).exists()}


def verify_io(metrics, spec):
    """Abort before timing if Docker did not install every requested limit."""
    limits = spec.get("io_limits", {})
    if not limits:
        return
    if "io.max" not in metrics or "io.stat" not in metrics:
        raise RuntimeError("requested I/O limits require readable cgroup v2 io.max and io.stat")
    devices = {}
    for line in metrics["io.max"].splitlines():
        device, *fields = line.split()
        devices[device] = dict(field.split("=", 1) for field in fields)
    actual = devices.get(spec["io_device_number"], {})
    if any(actual.get(key) != str(value) for key, value in limits.items()):
        raise RuntimeError(f"requested I/O limits were not installed: {limits}; io.max={metrics['io.max']}")


def measured_command(spec):
    output = Path("/results") / spec["id"]
    output.mkdir(exist_ok=spec.get("single_operation", False))
    group = cgroup()
    before = cg_read(group)
    expected_max = str(spec["memory_mib"] * 1024 * 1024)
    if before.get("memory.max") != expected_max or before.get("memory.swap.max") != "0":
        raise RuntimeError(f"container is not in the requested no-swap cgroup: {before}")
    quota, period = before.get("cpu.max", "max 1").split()
    if quota == "max" or int(quota) != spec.get("cpus", 2) * int(period):
        raise RuntimeError("CPU quota does not match requested CPUs")
    dump(output / "cgroup-start.json", dict(path=str(group), metrics=before))
    verify_io(before, spec)
    command = ["/binary", "--backend", spec["backend"], spec["operation"], spec["target"],
               "--workers", str(spec.get("workers", 1)), "--json"]
    if spec["operation"] == "scan" and spec.get("scan_profile", "disk") == "disk":
        command.append("--low-memory")
    env = dict(os.environ, LC_ALL="C", FREESPACE_CONFIG="/scratch/config.toml",
               FREESPACE_SNAPSHOT_DIR="/scratch/snapshot",
               SQLITE_TMPDIR="/scratch/snapshot/tmp")
    peaks = occupancy(Path("/scratch/snapshot"))
    file_peaks = {}
    sampled_memory = 0
    filesystem_used_start = filesystem_used("/scratch/snapshot")
    filesystem_used_peak = filesystem_used_start
    stopped = threading.Event()
    timed_out = threading.Event()
    sampler_errors = []
    proc = None

    def sample():
        nonlocal sampled_memory, filesystem_used_peak
        try:
            while not stopped.is_set():
                filesystem_used_peak = max(filesystem_used_peak, filesystem_used("/scratch/snapshot"))
                available = os.statvfs("/scratch/snapshot")
                if available.f_bavail * available.f_frsize < spec.get("minimum_free_bytes", 0):
                    sampler_errors.append("free-space reserve exhausted")
                    if proc is not None and proc.poll() is None:
                        os.killpg(proc.pid, signal.SIGKILL)
                    return
                current = occupancy(Path("/scratch/snapshot"))
                for name, values in file_occupancy(Path("/scratch/snapshot")).items():
                    prior = file_peaks.setdefault(name, dict(logical_bytes=0, allocated_bytes=0))
                    for key, value in values.items():
                        prior[key] = max(prior[key], value)
                for kind in peaks:
                    for key in peaks[kind]:
                        peaks[kind][key] = max(peaks[kind][key], current[kind][key])
                sampled_memory = max(sampled_memory, int((group / "memory.current").read_text()))
                stopped.wait(0.02)
        except Exception as error:
            sampler_errors.append(repr(error))

    print(f'command start {spec["id"]}', flush=True)
    sampler = threading.Thread(target=sample, name="allocation-sampler")
    sampler.start()
    try:
        with (output / "stdout.json").open("w") as out, (output / "stderr.log").open("w") as err:
            started = time.monotonic()
            proc = subprocess.Popen(["/usr/bin/time", "-f",
                '{"elapsed_seconds":%e,"peak_rss_kib":%M,"inputs":%I,"outputs":%O,"exit_code":%x}',
                "-o", str(output / "time.log"), *command], stdout=out, stderr=err,
                env=env, start_new_session=True)

            def expire():
                if proc.poll() is None:
                    timed_out.set()
                    try:
                        os.killpg(proc.pid, signal.SIGKILL)
                    except ProcessLookupError:
                        pass

            watchdog = threading.Timer(spec["timeout_seconds"], expire)
            watchdog.start()
            try:
                # POSIX Popen.wait(timeout=...) itself polls with sleeps. A
                # watchdog keeps the bound while blocking waitpid wakes on exit.
                proc.wait()
                finished = time.monotonic()
            finally:
                watchdog.cancel()
                watchdog.join()
    finally:
        stopped.set()
        sampler.join()
    filesystem_used_end = filesystem_used("/scratch/snapshot")
    filesystem_used_peak = max(filesystem_used_peak, filesystem_used_end)
    elapsed = finished - started
    print(f'command end {spec["id"]}: exit={proc.returncode} elapsed={elapsed:.6f}s', flush=True)
    after = cg_read(group)
    dump(output / "cgroup-end.json", dict(path=str(group), metrics=after))
    verify_io(after, spec)
    endpoint = occupancy(Path("/scratch/snapshot"))
    for kind in peaks:
        for key in peaks[kind]:
            peaks[kind][key] = max(peaks[kind][key], endpoint[kind][key])
    for name, values in file_occupancy(Path("/scratch/snapshot")).items():
        prior = file_peaks.setdefault(name, dict(logical_bytes=0, allocated_bytes=0))
        for key, value in values.items():
            prior[key] = max(prior[key], value)
    row = dict(spec, command=command, exit_code=proc.returncode, timed_out=timed_out.is_set(),
               sampler_errors=sampler_errors, elapsed_seconds=elapsed, cgroup_path=str(group),
               cgroup_before=before, cgroup_after=after, sampled_memory_peak=sampled_memory,
               sampled_disk_peak=peaks, endpoint_disk=endpoint, sample_interval_seconds=0.02)
    row["filesystem_used_start"] = filesystem_used_start
    row["filesystem_used_end"] = filesystem_used_end
    row["filesystem_used_peak"] = filesystem_used_peak
    row["filesystem_used_incremental_peak"] = filesystem_used_peak - filesystem_used_start
    row["filesystem_used_scope"] = (
        "bytes from (statvfs.f_blocks - statvfs.f_bfree) * statvfs.f_frsize; "
        "entire filesystem containing /scratch/snapshot, including fixture, metadata, "
        "and open unlinked allocated temporary files; includes unrelated activity if "
        "filesystem is not exclusive; sampled peak is a lower bound; incremental "
        "peak is relative to command start, not total snapshot size")
    row["memory_peak_scope"] = ("single CLI and sampler; observer excluded" if spec.get("single_operation")
                                else "arm cumulative CLI, helper and prior observations; excludes host fixture generation")
    if spec.get("single_operation"):
        row["app_disk_peak_bytes"] = (filesystem_used_peak - filesystem_used_start
                                      + spec["initial_snapshot_allocated_bytes"])
    row["sampled_memory_peak_scope"] = "current command sampled memory.current; lower bound"
    row["sampled_file_peaks"] = file_peaks
    row["endpoint_files"] = file_occupancy(Path("/scratch/snapshot"))
    try:
        row["time"] = json.loads((output / "time.log").read_text().splitlines()[-1])
        report = json.loads((output / "stdout.json").read_text())
        row["report"] = report
        if report["entries"] != spec["expected_entries"] or report.get("errors") or report.get("incomplete"):
            raise ValueError("incomplete or unexpected full entry count")
        if spec["operation"] == "refresh" and report["subtree_entries"] != spec.get("expected_subtree_entries", 18):
            raise ValueError("refresh rescanned an unexpected number of entries")
        row["validated"] = proc.returncode == 0 and not timed_out.is_set() and not sampler_errors
    except (OSError, ValueError, KeyError) as error:
        row["validation_error"] = str(error)
        row["validated"] = False
    dump(output / "metrics.json", row)
    return 0 if row["validated"] else 1


def db_breakdown(snapshot, timeout_seconds=120):
    """Read-only observation after CLI exit, outside timed span; cache is retained."""
    result = {}
    deadline = time.monotonic() + timeout_seconds
    for path in sorted(snapshot.rglob("*.db")):
        key = str(path.relative_to(snapshot))
        wal = path.with_name(path.name + "-wal")
        # immutable ignores WAL entirely and never performs sidecar cleanup.
        # It is safe here only after the closed CLI has emptied/removed WAL.
        if wal.exists() and wal.stat().st_size:
            result[key] = {"unavailable": "nonempty WAL: immutable observer would omit committed data",
                           "wal_logical_bytes": wal.stat().st_size}
            continue
        try:
            with closing(sqlite3.connect(path.as_uri() + "?mode=ro&immutable=1", uri=True, timeout=10)) as db:
                db.set_progress_handler(lambda: int(time.monotonic() > deadline), 10000)
                schema = db.execute("SELECT type,name,tbl_name,sql FROM sqlite_schema ORDER BY type,name").fetchall()
                tables = [row[1] for row in schema if row[0] == "table"]
                counts = {name: db.execute('SELECT count(*) FROM "' + name.replace('"', '""') + '"').fetchone()[0]
                          for name in tables}
                result[key] = dict(schema=schema, row_counts=counts,
                    page_size=db.execute("PRAGMA page_size").fetchone()[0],
                    page_count=db.execute("PRAGMA page_count").fetchone()[0],
                    freelist_count=db.execute("PRAGMA freelist_count").fetchone()[0],
                    dbstat_columns=["name", "pages", "bytes", "payload", "unused"])
                try:
                    result[key]["dbstat"] = db.execute("SELECT name,count(*),sum(pgsize),sum(payload),sum(unused) FROM dbstat GROUP BY name ORDER BY name").fetchall()
                except sqlite3.Error as error:
                    result[key]["dbstat_error"] = str(error)
        except sqlite3.Error as error:
            result[key] = {"error": str(error)}
    return result


def generate(root, start, stop, checkpoint):
    """Create deterministic fixtures with constant Python state and bounded batches.

    Host preparation happens outside the measured container. Sync drains dirty
    metadata before the dedicated VM cache flush; no setup memory is CLI RAM.
    """
    fixed_time = (1700000000, 1700000000)
    checkpoint(root.name, start, "start")
    for index in range(start, stop):
        if index == start or index % 1000 == 0:
            directory = root / f"d{index // 1000:06}"
            directory.mkdir(exist_ok=True)
        file = directory / f"f{index:09}"
        file.touch(exist_ok=False)
        os.utime(file, fixed_time)
        if (index + 1) % 1000 == 0 or index + 1 == stop:
            os.utime(directory, fixed_time)
        if (index + 1) % 10000 == 0:
            checkpoint(root.name, index + 1, "before_sync")
            os.sync()
            checkpoint(root.name, index + 1, "after_sync")
    os.utime(root, fixed_time)
    checkpoint(root.name, stop, "before_final_sync")
    os.sync()
    checkpoint(root.name, stop, "complete")


def prepare_fixture(case, output, ident, files):
    """Prepare once per file count, outside every measured cgroup."""
    def checkpoint(subtree, created, phase):
        row = dict(subtree=subtree, created_files=created, phase=phase,
                   unix_seconds=time.time(), scope="host setup outside measured container")
        with (output / (ident + ".fixture-progress.jsonl")).open("a") as stream:
            stream.write(json.dumps(row) + "\n")
            stream.flush()
            os.fsync(stream.fileno())
        print(f"host fixture {ident} {subtree} {created} {phase}", flush=True)

    tree = case / "tree"
    (tree / "small").mkdir(parents=True)
    (tree / "unrelated").mkdir()
    generate(tree / "small", 0, 16, checkpoint)
    generate(tree / "unrelated", 0, files, checkpoint)
    os.utime(tree, (1700000000, 1700000000))
    checkpoint("tree", files + 16, "before_final_sync")
    os.sync()
    checkpoint("tree", files + 16, "complete")


def flush_caches(output, ident):
    """Cold-start each arm, including arms sharing the immutable fixture."""
    command = ["sudo", "-n", "tee", "/proc/sys/vm/drop_caches"]
    receipt = dict(arm=ident, policy="sync then drop_caches=3 on this dedicated ephemeral GitHub-hosted VM only",
                   runner_environment=os.environ["RUNNER_ENVIRONMENT"],
                   sync_command="os.sync()", flush_command=command, flush_input="3\n",
                   started_unix_seconds=time.time(), success=False)
    receipt_path = output / (ident + ".cache-flush.json")
    dump(receipt_path, receipt)
    # The progress receipt was written after the final fixture sync. Flush it
    # too, with every fixture/progress file closed before dropping VM caches.
    os.sync()
    try:
        subprocess.run(command, input="3\n", text=True, stdout=subprocess.DEVNULL,
                       check=True, timeout=60)
        receipt["success"] = True
    except (OSError, subprocess.SubprocessError) as error:
        receipt["error"] = repr(error)
        raise
    finally:
        receipt["finished_unix_seconds"] = time.time()
        dump(receipt_path, receipt)


def inside(spec_path):
    spec = json.loads(spec_path.read_text())
    group = cgroup()
    dump(Path("/results") / (spec["id"] + ".arm-start.json"), cg_read(group))
    for index, operation in enumerate(spec["operations"]):
        command_spec = dict(spec, id=f'{spec["id"]}-{index}-{operation}', operation=operation,
                            target="/scratch/tree/small" if operation == "refresh" else "/scratch/tree")
        code = measured_command(command_spec)
        # SQLite uses a read-only connection and no checkpoint PRAGMA. This
        # observation can warm/evict cache; record it rather than reset cache.
        snapshot = Path("/scratch/snapshot")
        before_integrity = snapshot_integrity(snapshot)
        before_files = file_occupancy(snapshot)
        observation = dict(cache_policy="bounded full-file integrity reads then immutable observer then integrity reads; outside CLI timing, cache retained in arm cgroup",
                           cgroup_before=cg_read(group),
                           timeout_seconds=spec["timeout_seconds"],
                           databases=db_breakdown(snapshot, timeout_seconds=spec["timeout_seconds"]),
                           cgroup_after=cg_read(group))
        after_integrity = snapshot_integrity(snapshot)
        after_files = file_occupancy(snapshot)
        observation.update(observer_comparison(before_integrity, after_integrity, before_files, after_files))
        observation["errors"] = {
            name: {key: details[key] for key in ("error", "unavailable", "dbstat_error") if key in details}
            for name, details in observation["databases"].items()
            if any(key in details for key in ("error", "unavailable", "dbstat_error"))}
        if not observation["logical_content_unchanged"]:
            observation["errors"]["integrity"] = "SQLite observation changed snapshot names, logical sizes or bytes"
        observation["validated"] = not observation["errors"]
        command_output = Path("/results") / command_spec["id"]
        dump(command_output / "dbstat.json", observation)
        metrics_path = command_output / "metrics.json"
        metrics = json.loads(metrics_path.read_text())
        metrics["cli_validated"] = metrics["validated"]
        metrics["observer_validated"] = observation["validated"]
        metrics["validated"] = metrics["cli_validated"] and metrics["observer_validated"]
        if observation["errors"]:
            metrics["observer_errors"] = observation["errors"]
        dump(metrics_path, metrics)
        if not observation["validated"] and not code:
            raise RuntimeError(f"SQLite observation failed: {observation['errors']}")
        if code:
            return code
    final = cg_read(group)
    dump(Path("/results") / (spec["id"] + ".arm-end.json"), final)
    events = dict(line.split() for line in final["memory.events"].splitlines())
    return 1 if int(events.get("oom_kill", 0)) or int(events.get("oom", 0)) else 0


def host(args):
    if os.environ.get("GITHUB_ACTIONS") != "true" or os.environ.get("RUNNER_ENVIRONMENT") != "github-hosted":
        raise RuntimeError("Setup, cache flushing and measurements require an ephemeral GitHub-hosted Actions VM")
    steps = [int(value) for value in args.steps.split(",")]
    if any(not 1 <= value <= 8000000 for value in steps) or sorted(set(steps)) != steps:
        raise ValueError("steps must be unique counts from 1 through 8000000 in increasing order")
    if args.repeats < 1 or args.scans < 2:
        raise ValueError("repeats >= 1 and scans >= 2 required")
    io_limits = {key: getattr(args, option) for key, option in (
        ("rbps", "read_bps"), ("wbps", "write_bps"), ("riops", "read_iops"), ("wiops", "write_iops"))
        if getattr(args, option) is not None}
    io_device = None
    io_device_number = None
    if args.io_device:
        io_device = Path(args.io_device).resolve(strict=True)
        device_stat = io_device.stat()
        if not stat.S_ISBLK(device_stat.st_mode):
            raise ValueError("--io-device must name a block device")
        io_device_number = f"{os.major(device_stat.st_rdev)}:{os.minor(device_stat.st_rdev)}"
    output = Path(args.output).resolve()
    output.mkdir(parents=True, exist_ok=False)
    harness = Path(__file__).resolve()
    if args.current_backends:
        binaries = {"candidate-v1": (Path(args.candidate).resolve(), "v1"),
                    "candidate-v2": (Path(args.candidate).resolve(), "v2")}
    else:
        binaries = {"baseline-v2": (Path(args.baseline).resolve(), "v2"),
                    "candidate-v2": (Path(args.candidate).resolve(), "v2")}
        if args.include_v1:
            binaries["baseline-v1"] = (Path(args.baseline).resolve(), "v1")
    benchmark_label = "freespace.benchmark=" + (os.environ.get("FREESPACE_BENCHMARK_RUN_TOKEN")
        or os.environ.get("GITHUB_RUN_ID") or uuid.uuid4().hex)
    image = "freespace-balance:" + uuid.uuid4().hex
    subprocess.run(["docker", "build", "-t", image, str(harness.parent / "bench-v2-container")], check=True, timeout=600)
    failures = []
    completed = False
    manifest = dict(schema_version=1, arguments=vars(args), kernel=platform.release(),
        benchmark_label=benchmark_label,
        scan_profile=args.scan_profile,
        measurement_protocol="host-shared-fixture-cold-arm-integrity-v4", cache_flush_receipts=[],
        io_device=str(io_device) if io_device else None, io_device_number=io_device_number, io_limits=io_limits,
        started_unix_seconds=time.time(),
        cpu=Path("/proc/cpuinfo").read_text(), host_meminfo=Path("/proc/meminfo").read_text(),
        docker=capture(["docker", "version"]),
        image=capture(["docker", "image", "inspect", image]),
        resource_policy=f"dedicated ephemeral GitHub-hosted VM; host setup excluded; each arm has {args.cpus} CPU quota, selected RAM MiB, memory-swap=memory, no OOM override; requested I/O limits verified in cgroup io.max",
        cache_policy="host-generated deterministic fixture, os.sync every 10000 files and at completion; os.sync then sudo -n tee /proc/sys/vm/drop_caches with input 3 before each arm on this job's ephemeral VM only; failure aborts, never warm fallback; clean OS input caches requested dropped (active pages and hardware caches not reset), then cache retained across CLI processes, full-file SHA256 reads before/after immutable post-command dbstat; integrity reads outside CLI timing warm/evict cache; alternating paired arm order",
        measurement_policy="SQLITE_TMPDIR is snapshot/tmp on the same measured device; pathname disk sampling omits unlinked files; filesystem statvfs sampling includes their allocated blocks and all other filesystem usage; complete CLI incl close/checkpoint; helper shares cgroup; memory.peak arm-cumulative CLI/helper/observations excluding host fixture generation; per-command sampled current lower bound and GNU time RSS; disk peaks sampled lower bounds",
        provenance={arm: dict(scan_profile=args.scan_profile,
                     sha256=hashlib.sha256(binary.read_bytes()).hexdigest(),
                     source_revision=binary.with_name(binary.name + ".revision.txt").read_text().strip(),
                     version=capture([str(binary), "--version"])) for arm, (binary, _) in binaries.items()},
        github={key: os.environ.get(key) for key in ("GITHUB_SHA", "GITHUB_RUN_ID", "GITHUB_RUN_ATTEMPT", "RUNNER_NAME", "RUNNER_OS", "RUNNER_ENVIRONMENT")})
    dump(output / "manifest.json", manifest)
    try:
        with tempfile.TemporaryDirectory(prefix="freespace-gh-balance-", dir=os.environ.get("RUNNER_TEMP")) as temporary:
            scratch = Path(temporary)
            manifest["filesystem"] = capture(["findmnt", "-T", str(scratch), "-J", "-o", "TARGET,SOURCE,FSTYPE,OPTIONS"])
            dump(output / "manifest.json", manifest)
            if io_device:
                backing = scratch.stat().st_dev
                backing_number = f"{os.major(backing)}:{os.minor(backing)}"
                manifest["scratch_device_number"] = backing_number
                dump(output / "manifest.json", manifest)
                if backing_number != io_device_number:
                    raise RuntimeError(f"I/O device {io_device_number} does not directly back scratch filesystem {backing_number}; layered devices are unsupported")
            ordinal = 0
            keeps = (False, True) if args.keep_previous == "both" else (args.keep_previous == "true",)
            for step_index, count in enumerate(steps):
                fixture = scratch / "fixture"
                fixture.mkdir()
                prepare_fixture(fixture, output, f"fixture-{count}", count)
                for keep in keeps:
                    for repeat in range(args.repeats):
                        arms = list(binaries)
                        if (repeat + step_index + int(keep)) % 2:
                            arms.reverse()
                        for arm in arms:
                            # Host setup is excluded; each arm owns one container
                            # and cgroup for all scans, refresh and observation.
                            case = scratch / "case"
                            case.mkdir()
                            try:
                                (case / "snapshot" / "tmp").mkdir(parents=True)
                                (case / "tree").mkdir()
                                (case / "config.toml").write_text(f"keep_previous = {str(keep).lower()}\n")
                                ordinal += 1
                                ident = f"{ordinal:04}-{arm}-{count}-keep{int(keep)}-r{repeat + 1}"
                                binary, backend = binaries[arm]
                                operations = ["scan"] * args.scans + ["refresh"] * args.refreshes
                                spec = dict(id=ident, arm=arm, backend=backend, scan_profile=args.scan_profile,
                                    expected_entries=count + (count + 999) // 1000 + 20,
                                    operations=operations, memory_mib=args.memory, workers=args.workers, cpus=args.cpus,
                                    io_device=str(io_device) if io_device else None, io_device_number=io_device_number, io_limits=io_limits,
                                    keep_previous=keep, repeat=repeat + 1, files=count,
                                    timeout_seconds=args.timeout_seconds, order=ordinal)
                                spec_path = output / (ident + ".spec.json")
                                dump(spec_path, spec)
                                try:
                                    flush_caches(output, ident)
                                finally:
                                    receipt_path = output / (ident + ".cache-flush.json")
                                    if receipt_path.exists():
                                        manifest["cache_flush_receipts"].append(json.loads(receipt_path.read_text()))
                                        dump(output / "manifest.json", manifest)
                                name = "fs-balance-" + uuid.uuid4().hex
                                print(f"running {ident}: memory={args.memory}MiB CPUs={args.cpus} workers={args.workers} swap=0", flush=True)
                                command = ["docker", "run", "--name", name, "--label", benchmark_label,
                                    "--network", "none", "--cpus", str(args.cpus),
                                    "--memory", f"{args.memory}m", "--memory-swap", f"{args.memory}m",
                                    "--cgroupns", "private", "--pids-limit", "128", "--user", f"{os.getuid()}:{os.getgid()}",
                                    "--mount", f"type=bind,src={case},dst=/scratch",
                                    "--mount", f"type=bind,src={fixture / 'tree'},dst=/scratch/tree,readonly",
                                    "--mount", f"type=bind,src={output},dst=/results",
                                    "--mount", f"type=bind,src={harness.parent},dst=/harness,readonly",
                                    "--mount", f"type=bind,src={binary},dst=/binary,readonly",
                                    image, "/results/" + spec_path.name]
                                for option in ("read-bps", "write-bps", "read-iops", "write-iops"):
                                    value = getattr(args, option.replace("-", "_"))
                                    if value is not None:
                                        command[2:2] = ["--device-" + option, f"{io_device}:{value}"]
                                try:
                                    with (output / (ident + ".docker.log")).open("w") as log:
                                        run = subprocess.run(command, stdout=log, stderr=subprocess.STDOUT,
                                            timeout=300 + len(operations) * (2 * args.timeout_seconds + 180))
                                    inspection = json.loads(capture(["docker", "inspect", name]))[0]
                                    dump(output / (ident + ".docker-state.json"), inspection["State"])
                                    valid = True
                                    for index, operation in enumerate(operations):
                                        metrics_path = output / f"{ident}-{index}-{operation}" / "metrics.json"
                                        metrics = json.loads(metrics_path.read_text()) if metrics_path.exists() else {}
                                        valid = valid and metrics.get("validated", False)
                                    if run.returncode or inspection["State"].get("OOMKilled") or not valid:
                                        failures.append(ident)
                                except subprocess.TimeoutExpired:
                                    failures.append(ident + ":docker-timeout")
                                finally:
                                    subprocess.run(["docker", "rm", "-f", name], stdout=subprocess.DEVNULL,
                                        stderr=subprocess.DEVNULL, timeout=30, check=False)
                            finally:
                                shutil.rmtree(case)
                shutil.rmtree(fixture)
            completed = True
    finally:
        dump(output / "status.json", {"failures": failures, "completed": completed,
                                      "success": completed and not failures,
                                      "finished_unix_seconds": time.time()})
        subprocess.run(["docker", "image", "rm", image], stdout=subprocess.DEVNULL, timeout=60, check=False)
    return 1 if failures else 0


def main():
    if len(sys.argv) > 1 and sys.argv[1] == "--v1-pairs":
        from bench_v1_pair import main as paired_main
        return paired_main(sys.argv[2:])
    if len(sys.argv) == 3 and sys.argv[1] == "--inside":
        return inside(Path(sys.argv[2]))
    args = parse_arguments(__doc__)
    if args.scan_profile != "both":
        return host(args)
    output = Path(args.output).resolve()
    if output.exists():
        raise FileExistsError(f"output already exists: {output}")
    results = {}
    for profile in ("memory", "disk"):
        results[profile] = host(profile_arguments(args, profile, output))
    dump(output / "status.json", dict(success=not any(results.values()), profiles=results))
    return 1 if any(results.values()) else 0


if __name__ == "__main__":
    sys.exit(main())
