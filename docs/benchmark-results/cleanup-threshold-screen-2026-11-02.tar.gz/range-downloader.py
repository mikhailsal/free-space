#!/usr/bin/env python3
"""Retrieve small members of one Actions ZIP with bounded HTTP Range requests.

Usage: script OWNER/REPO ARTIFACT_ID OUTPUT_DIRECTORY
Auth token and signed redirect are held in memory only. ZIP inventory and selected
members are written as received/decompressed; omitted members are not created.
"""
import collections
import io
import json
import pathlib
import re
import subprocess
import sys
import urllib.error
import urllib.request
import zipfile

CHUNK = 262144
MAX_REMOTE = 128 * 1024 * 1024
MAX_OUTPUT = 40 * 1024 * 1024
MAX_MEMBER = 8 * 1024 * 1024


class NoRedirect(urllib.request.HTTPRedirectHandler):
    def redirect_request(self, *args, **kwargs):
        return None


def redirect(repo, artifact):
    token = subprocess.check_output(['gh', 'auth', 'token'], text=True, timeout=15).strip()
    url = 'https://api.github.com/repos/' + repo + '/actions/artifacts/' + artifact + '/zip'
    req = urllib.request.Request(url, headers={'Authorization': 'Bearer ' + token, 'Accept': 'application/vnd.github+json', 'User-Agent': 'cleanup-range-reader'})
    try:
        urllib.request.build_opener(NoRedirect()).open(req, timeout=20)
    except urllib.error.HTTPError as e:
        if e.code != 302 or not e.headers.get('Location'):
            raise ValueError('artifact API did not return expected redirect') from None
        return e.headers['Location']
    raise ValueError('artifact API did not redirect')


class RangeFile(io.RawIOBase):
    def __init__(self, url):
        self.url, self.pos, self.cache, self.remote_bytes = url, 0, collections.OrderedDict(), 0
        req = urllib.request.Request(url, headers={'Range': 'bytes=0-0', 'User-Agent': 'cleanup-range-reader'})
        with urllib.request.urlopen(req, timeout=30) as r:
            match = re.fullmatch(r'bytes 0-0/(\d+)', r.headers.get('Content-Range', ''))
            if r.status != 206 or not match or len(r.read(2)) != 1:
                raise ValueError('artifact server does not support exact ranges')
            self.size = int(match.group(1))
        self.remote_bytes += 1
    def readable(self): return True
    def seekable(self): return True
    def tell(self): return self.pos
    def seek(self, offset, whence=0):
        self.pos = (0 if whence == 0 else self.pos if whence == 1 else self.size) + offset
        if self.pos < 0: raise ValueError('negative seek')
        return self.pos
    def read(self, size=-1):
        end = self.size if size < 0 else min(self.size, self.pos + size)
        pieces = []
        while self.pos < end:
            start = self.pos // CHUNK * CHUNK
            if start not in self.cache:
                stop = min(start + CHUNK, self.size) - 1
                if self.remote_bytes + stop - start + 1 > MAX_REMOTE: raise ValueError('remote byte cap exceeded')
                req = urllib.request.Request(self.url, headers={'Range': f'bytes={start}-{stop}', 'User-Agent':'cleanup-range-reader'})
                with urllib.request.urlopen(req, timeout=30) as r:
                    expected = f'bytes {start}-{stop}/{self.size}'
                    if r.status != 206 or r.headers.get('Content-Range') != expected: raise ValueError('invalid server range response')
                    data = r.read(stop-start+2)
                if len(data) != stop-start+1: raise ValueError('truncated range')
                self.remote_bytes += len(data)
                self.cache[start] = data
                if len(self.cache) > 32: self.cache.popitem(last=False)
            data = self.cache[start]
            self.cache.move_to_end(start)
            amount = min(end-self.pos, len(data)-(self.pos-start))
            pieces.append(data[self.pos-start:self.pos-start+amount])
            self.pos += amount
        return b''.join(pieces)


def allowed(name):
    path = pathlib.PurePosixPath(name)
    if path.is_absolute() or '..' in path.parts or not path.parts: return False
    if name == 'runner-cleanup.json' or name.startswith('source/'): return True
    if name.startswith('measurements/snapshot-evidence/'):
        return path.name.endswith('-receipt.json')
    if name.startswith('measurements/'):
        return not name.endswith(('.db', '.db.gz'))
    if name.startswith('provenance/'):
        return path.name not in ('runtime-image.tar.gz', 'cleanup_probe', 'freespace')
    return name in ('filesystem.json', 'loop-devices.json', 'inodes.txt', 'host-disk.txt', 'cleanup.log',
                    'disk-calibration.json', 'fio-read.json', 'fio-write.json', 'fio-randread.json', 'fio-randwrite.json')


def main():
    if len(sys.argv) != 4 or not re.fullmatch(r'[A-Za-z0-9_.-]+/[A-Za-z0-9_.-]+', sys.argv[1]) or not sys.argv[2].isdigit():
        raise ValueError('usage: script OWNER/REPO ARTIFACT_ID OUTPUT_DIRECTORY')
    dest = pathlib.Path(sys.argv[3]); dest.mkdir(parents=True, exist_ok=True)
    reader = RangeFile(redirect(sys.argv[1], sys.argv[2]))
    with zipfile.ZipFile(reader) as archive:
        infos = archive.infolist()
        inventory = [{'name': i.filename, 'size': i.file_size, 'compressed_size': i.compress_size, 'crc32': f'{i.CRC:08x}', 'selected': not i.is_dir() and allowed(i.filename)} for i in infos]
        selected = [i for i in infos if not i.is_dir() and allowed(i.filename)]
        if len({i.filename for i in selected}) != len(selected): raise ValueError('duplicate ZIP member')
        if sum(i.file_size for i in selected) > MAX_OUTPUT or any(i.file_size > MAX_MEMBER for i in selected): raise ValueError('selected member size cap exceeded')
        (dest / 'zip-inventory.json').write_text(json.dumps(inventory, indent=2) + '\n')
        for entry in selected:
            target = dest.joinpath(*pathlib.PurePosixPath(entry.filename).parts)
            target.parent.mkdir(parents=True, exist_ok=True)
            with archive.open(entry) as src, target.open('xb') as out:
                while chunk := src.read(262144): out.write(chunk)
    print(json.dumps({'success': True, 'archive_bytes': reader.size, 'remote_bytes': reader.remote_bytes, 'member_count': len(infos), 'selected_count': len(selected), 'output_bytes': sum(i.file_size for i in selected)}))


if __name__ == '__main__':
    try: main()
    except Exception as e:
        # Network errors can include signed URLs; never print their text.
        print(json.dumps({'success': False, 'error_type': type(e).__name__}))
        sys.exit(1)
