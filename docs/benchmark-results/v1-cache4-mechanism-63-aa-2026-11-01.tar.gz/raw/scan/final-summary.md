# v1-single-operation-pairs-v4

Case: {"case_policy": "qualification-v1", "memory_mib": 4096, "mutation_receipt": null, "observer_memory_mib": 4096, "scenario": "unchanged", "setup_memory_mib": 4096, "subtree_entries": 100}


Descriptive paired results; no automatic promotion or uncertainty estimate.
Application disk peak is sampled; RSS excludes the observer.

| Pair | Elapsed baseline → candidate (s) | RSS baseline → candidate (MiB) | App disk baseline → candidate (GiB) |
|---:|---:|---:|---:|
| 1 | 46.826 → 46.877 (Δ +0.051) | 36.863 → 36.801 (Δ -0.062) | 0.426 → 0.426 (Δ +0.000) |
| 2 | 46.853 → 46.756 (Δ -0.097) | 36.789 → 36.789 (Δ +0.000) | 0.426 → 0.426 (Δ +0.000) |
| 3 | 46.761 → 46.863 (Δ +0.101) | 36.719 → 36.754 (Δ +0.035) | 0.426 → 0.426 (Δ +0.000) |

Identical binaries: observed maximum absolute paired differences (descriptive band):
- elapsed_seconds: median Δ +0.051; max |Δ| 0.101
- peak_rss_kib: median Δ +0.000; max |Δ| 64.000
- app_disk_peak_bytes: median Δ +0.000; max |Δ| 0.000

VALID
