# v1-single-operation-pairs-v4

Case: {"case_policy": "qualification-v1", "memory_mib": 4096, "mutation_receipt": null, "observer_memory_mib": 4096, "scenario": "unchanged", "setup_memory_mib": 4096, "subtree_entries": 100}


Descriptive paired results; no automatic promotion or uncertainty estimate.
Application disk peak is sampled; RSS excludes the observer.

| Pair | Elapsed baseline → candidate (s) | RSS baseline → candidate (MiB) | App disk baseline → candidate (GiB) |
|---:|---:|---:|---:|
| 1 | 10.579 → 10.503 (Δ -0.075) | 281.438 → 281.523 (Δ +0.086) | 0.350 → 0.350 (Δ +0.000) |
| 2 | 10.513 → 10.492 (Δ -0.020) | 281.566 → 281.445 (Δ -0.121) | 0.350 → 0.350 (Δ +0.000) |
| 3 | 10.504 → 10.518 (Δ +0.014) | 281.547 → 281.473 (Δ -0.074) | 0.350 → 0.350 (Δ +0.000) |

Identical binaries: observed maximum absolute paired differences (descriptive band):
- elapsed_seconds: median Δ -0.020; max |Δ| 0.075
- peak_rss_kib: median Δ -76.000; max |Δ| 124.000
- app_disk_peak_bytes: median Δ +0.000; max |Δ| 0.000

VALID
