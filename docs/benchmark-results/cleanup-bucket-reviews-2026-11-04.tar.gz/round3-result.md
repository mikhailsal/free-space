# Delta review of commit 0942a50 (round 3)

## Findings

**[P2] `scripts/cleanup_probe_analysis.py` `check_arm_row`: v1 must report the total `entries` in every scenario, refreshes included**
- **What is wrong:** For `arm == 'v1'` the code runs `require(row['reported_entries'] == entries, ident + ': wrong full entry count')` unconditionally. Nothing else in the experiment requires a v1 refresh report to carry `entries`:
  - `plan.v1_scope` asks only for `subtree_entries` on refreshes.
  - The worker validates only that.
  - The error text says "full", which suggests the check was scoped to `scenario == 'full'` in the script this was adapted from.
- **Trigger:** v1 `refresh /scratch/tree/large --json` omits `entries`, or reports something other than the whole-tree count there. Then every refresh cell is rejected as an invalid artifact.
- **Why it costs runner time:** The analysis is captured source (`scripts/cleanup_probe*`), and the screen is admitted only from a smoke of the same SHA. Correcting this after the smoke forces a new smoke.
- **Fix:** Move the check under `if scenario == 'full'`. Alternatively, confirm from v1's source or an archived v1 refresh report that `entries` is the total-tree count, and add that field to `v1_scope` so the worker validates it on the runner.

**[P2] `docs/designs/cleanup-bucket-experiment.md` "Predictions" vs "Overall": two incompatible failure rules**
- **What is wrong:** The predictions say "Any of these failing is reported as a failure of the idea". The success rule (`overall`) can return `success: True` while several predictions fail:
  - A directories full scan at +10% in every repeat passes D4 through the disk exchange but fails "Full scans: faster than v1".
  - Probe RSS equal to v1 within noise passes D3 but fails "lower than v1's in every cell".
  - A wide refresh at 15% of v1 passes D6 and D8 but fails "under 10%".
- **Effect:** The analysis does not evaluate predictions at all. Whichever reading the report author prefers can be chosen after the results are known.
- **Fix, before the smoke:** State that `overall` is the experiment verdict and that predictions are scored separately (hit or miss), never folded into or overriding `overall`. Then implement the six predictions as a separate `predictions` block in the analysis, with the medians of the same cell, so they cannot be dropped silently.

**[P3] `scripts/cleanup_oracle.py` `check_refresh`: the proof is narrower than the document claims**
- **(a) "At least one fresh item" is not enforced.** The document says the oracle requires it. Only `check_oracle` in the analysis does; the host accepts any `success: true`.
- **(b) The expectation is not checked against the seed.** It is never verified that the boundary exists as a retained node, or that `(lo, hi)` is an actual bucket of the boundary.
  - Example: with a wrong window (a plan bug), no bucket is expected fresh.
  - A probe that re-read the parent but skipped the bucket rescan would then pass the oracle.
  - With a retained boundary that is absent from the nodes, a probe that only bumped `meta` passes.
- **(c) Boundary normalisation.** `boundary + b'/'` breaks for a trailing slash or for `/`. `Walk` uses `rstrip(b'/')` for exactly this reason.
- **(d) Stamps are written by the probe itself.** On an unchanged tree, a probe that stamps the planned region without reading it still passes. The oracle proves which stamps were rewritten, not that a rescan happened.
- **Fix:**
  - In `check_refresh`, require `fresh_nodes + fresh_buckets > 0`.
  - Require the boundary node in both snapshots.
  - For `range`, require exactly one non-empty seed bucket of the boundary with `lo == window[0]` and `hi == window[1]`.
  - Normalise the boundary with `rstrip(b'/')`.
  - Reword the document to "proves which stored stamps advanced".

**[P3] `cleanup_probe_analysis.py` `direction` / `full_scan_bar` / `confirmed_benefit`: exact ties on the 0.01 s grid misclassified by float error**
- **Examples (all against the probe):**
  - v1 1.00 s vs probe 1.05 s gives a diff of 0.0500000000000000444, which exceeds both floors and counts as a slowdown. The document says exactly the allowance is noise, so D6 fails a pass.
  - v1 3.00 vs 3.45 gives a change of 0.15000000000000008, which is above 0.15. D4 fails at exactly +15%, which the document calls "at most".
- **Fix:** Compute on `fractions.Fraction(str(x))`, or compare with a 1e-9 tolerance.

**[P3] `cleanup_probe_analysis.py` `judge_group['median_change']`: judged and observed disk values are mixed under one name**
- **What is wrong:** `median_change['disk']` uses the 4× probe value, while `medians_and_repeats` holds the observed values.
- **Effect:** A reader computing the change from the tables gets a different number than `median_change` reports.
- **Fix:** Rename it `judged_median_change` and add an `observed_median_change`.

**[P3] `cleanup_probe_analysis.py` `analyze` (smoke stage): per-bar verdicts are emitted for one-pair smoke data**
- **What is wrong:** `bars` contains `'passed'` strings for the smoke, with only the top-level `bars_are_judged: False` beside them.
- **Effect:** A smoke result can be quoted as passing a bar.
- **Fix:** For `stage == 'smoke'`, omit `bars`, or replace each verdict with `'not judged (smoke)'`.

**[P3] `cleanup_probe_analysis.py` `overall`: no check that every cell is present**
- **What is wrong:** `overall` judges whatever groups it is given. A dict with one refresh cell and one full cell can yield `success: True`. `analyze` always builds all eight cells today, so the result is correct only by construction of the caller.
- **Fix:** Require exactly the eight `profile/scenario` keys, D6 in the six refresh cells and D4 in the two full cells.

**[P3] `cleanup_probe_host.py` `run_container` / `oracle`: the early-failure fix covers only containers that were created**
- **What is wrong:** If `docker run` fails before creating the container (exit 125: bad mount source, missing image), `docker inspect` raises `CalledProcessError`. That replaces the log tail in the error.
- **Further risk:** Depending on the Docker version, `docker rm -f` on a nonexistent container exits nonzero. With `check=True` inside `finally`, it then masks the original exception.
- **Note:** The new test fakes a successful `inspect` for exit code 125, so it does not exercise this path.
- **Fix:** Wrap `inspect` in a try block and fall back to the log tail. Run `docker rm -f` with `check=False` and log a failure.

**[P3] Document, D5/D14 justification**
- **What is wrong:** The text says D5 and D14 "name" peak disk, peak RSS and refresh time, and that cgroup memory was removed because they do not name it. The verbatim D5 row names no metric ("Other-metric"), and D14 says "RAM savings".
- **Assessment:** The removal is stricter, so it is acceptable before measurement, but the stated reason contradicts the quote.
- **Fix:** Justify it by the reclaimable-cache argument alone, as a pre-registered narrowing of the owner's rule.

**[P3] Python harness without a linter**
- **What is wrong:** The verdict now lives in Python with many lines over 150 characters, and its correctness rests on tests alone. The disposition (repository decision) is reasonable for `scripts/check.sh`.
- **Fix:** A scoped alternative avoids that decision: run `ruff check` (pyflakes-level rules) on `scripts/cleanup_*.py` only, in `cleanup-ci.yml` and the experiment workflow's contract step. This changes nothing contributors must install.

## Verdict

**GO for the hosted smoke.**

- **Oracle:** I found no way for a correct probe to fail `check_refresh` in the hosted flow.
  - The seed generation is 2 and every timed operation makes it 3.
  - The 1.05 s sleep guarantees strictly newer whole-second stamps.
  - Retained refresh leaves the root's own `scanned_at` untouched; only `min_scanned_at`, which is not compared, is rebuilt.
  - Range refresh re-reads only the parent's stamp and splices exactly the window bucket, which re-tiles identically on an unchanged tree.
  - Full scan rewrites everything.
- **Host plumbing:** It pairs each oracle with its own profile's untouched `seeds['probe']`, read-only. The expectations match the analysis's independently derived scopes for both profiles at both scales.
- **Artifacts:** Every key and path the analysis reads is written by the host or worker, except v1's `entries` on refreshes (P2 above).
- **Bar logic:** I found no input that reports a failed or inconclusive bar as passed. The noise allowance, `v1 = 0`, worst-repeat sizing, flag handling, 4× disk scaling of all three disk uses, and absent gates are handled as documented.
- **4× disk factor:** I agree with it. The measured probe value already contains the current and previous files, so 4× is over-strict rather than lenient.
- **Disclosure for the results report:** Because v1's disk metric includes its whole database, the disk exchange makes D4 effectively "at most +15% in every repeat". Say so in the report.
- **Before dispatch:** Every later edit to captured source costs another smoke. Fix the two P2 findings (and ideally the P3 oracle hardening) before dispatching; neither blocks the smoke from producing valid evidence.

## Not verified

- v1's JSON report fields on `refresh` (`entries`, `subtree_entries`) and v1's snapshot schema as the oracle reads it.
- Behaviour of the walk:
  - that every retained node, including file nodes, gets `now()` as `scanned_at` in `scan` and `scan_range`;
  - that `scan_range` always returns `parent`;
  - that bucket `min_scanned_at` derives only from freshly scanned entries.
- Legacy helpers:
  - `legacy.flush_caches` (whether it syncs, and that it creates nothing under `out/<id>`, which the new strict `mkdir` would hit);
  - `occupancy`;
  - `cg_read` providing `memory.peak`;
  - `capture_resources` keys;
  - `cleanup_probe_versions.py` output;
  - the calibration artifacts.
- Read-only SQLite opens on read-only bind mounts inside the oracle container.
- `docker rm -f` exit status for a missing container on the runner's Docker version.
- Hash vectors and the windows `[804, 971)` and `[945, 956)`.
- The claimed mutation results, file sizes of `tests/refresh.rs`, and clippy on the new let-chains (taken from the author's evidence).