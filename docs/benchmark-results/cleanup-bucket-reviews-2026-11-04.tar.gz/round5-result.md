# Round 5 review: corrected results report, cleanup-bucket screen 2026-11-04

## Disposition of round 4

1. **[P1] wrong cell count of the miss: FIXED BUT WORDED INCORRECTLY.** "It applies to four cells (omitted and wide, both profiles); it hit in three and missed in `directories/wide`" is now correct. The same sentence adds "1.07 s in all three repeats (1.07, 1.08, 1.06)", which contradicts itself (new finding 1).
2. **[P2] seeding sentence: FIXED.** "Each arm and profile is seeded once by two full scans (8 seed scans in all…); every timed command then starts from a fresh copy of that arm's seed, so the three repeats of a cell share seed state. (The pre-registration says … that sentence is inaccurate…)". The sharing is understated (new finding 7).
3. **[P2] "removes that regression entirely" / cross-run comparison: PARTIALLY FIXED.** The Plain-terms bullet now reads "does not appear here … are context, not a comparison". The Evidence section still says "context for the regression this revision removes" (new finding 2).
4. **[P2] best case unstated: FIXED.** "This scenario is the **best case** of the idea: `small` sits alone in the root's lone bucket … after demotions a bucket can exceed the 4,096-entry cap until it is next re-tiled."
5. **[P2] partial credit, causal claim, hypothesis gaps, remedy: FIXED.**
   - "nothing in this run isolates the cause"
   - "about 2,004 directories"
   - "the second of the probe's two passes to be served from cache … (no ext4 `inline_data`); neither was checked"
   - "would need a new experiment"
   
   The Verdict states the miss without "half holds". A residual causal sentence remains in the "what it costs" paragraph (new finding 6).
6. **[P2] per-repeat disk wording and decomposition: FIXED.**
   - "a median of 76 KiB (individual runs 72-76 KiB, and one sampled in-flight publication of 92 KiB)"
   - Absolute-measurements note: "20 peak at 76 KiB, three at 72 KiB … one … 92 KiB". This matches the CSV.
   - The decomposition now cites per-file sizes (author fact 7) instead of the 4 KiB directory block.
7. **[P2] review record incomplete: FIXED.**
   - "**Round 4, after the runs.**"
   - "fixed or disclosed in `59a977f`/`0942a50`/`ba8281f`"
   - "The round-3 fixes in `ba8281f` were **not reviewed by a model before the runs**"
   
   The round-1 "one turn" now rests on "as the archived outputs show", which I cannot check.
8. **[P2] smoke and screen identity overclaim: FIXED.** "Both runs were dispatched from `ba8281f` (the same head SHA in GitHub's run records), each as run attempt 1; the captured source of the two artifacts is byte-identical (229 files…)". This is supported by the proof (`smoke.head_sha`, `smoke_and_screen_captured_source_identical`). A residual "nothing changed" sentence remains (new finding 13).
9. **[P3] pre-registered limitations missing: FIXED.** New bullet "Other pre-registered limitations stand…", plus renames under "Best case versus realistic case". One item in that bullet needs qualification (new finding 5).
10. **[P3] D4 disclosure sentence: FIXED.** "As the pre-registration said this report would state: … D4 would in practice have been a plain 'at most 15% slower in every repeat' cap".
11. **[P3] "same way in all three repeats" ambiguous: FIXED.** "The verdict and the direction of every bar were the same in all three repeats of every cell."
12. **[P3] admission figures and smoke attempt: FIXED.** "admitted by the in-job forecast … projected 4,420 s … 5,746 s … 12,600 s"; "each as run attempt 1". The proof gives `smoke.run_attempt: 1`.
13. **[P3] ledger basis and smoke ZIP hash: FIXED.** "Mixed bases: … on the earlier basis the campaign total would be 66,266 s"; Evidence: "the smoke ZIP was not independently hashed". Arithmetic checked: 61,203 + 5,292 = 66,495 and 61,203 + 5,063 = 66,266.
14. **[P3] RSS caveat next to number: FIXED.** "This is the resident set of the writer process under an 8 GiB ceiling, not a lower required RAM."
15. **[P3] how v1 was built: FIXED.** "The v1 arm is the `freespace` binary built from `ba8281f`. Against master `afce6fd` … changes no file under `core/`, `cli/src/` or `web/` … (checked with `git diff --name-only afce6fd ba8281f`)."

## New findings

**1. [P2] "The missed prediction and what it costs", first paragraph: a false statement inside the P1 fix.**
- **Text:** "missed in `directories/wide`: 1.07 s in all three repeats (1.07, 1.08, 1.06)".
- **Evidence:** The repeats are 1.07, 1.08 and 1.06 (CSV rows 46–48). The sentence's own parenthesis contradicts "1.07 s in all three".
- **Replace with:** "missed in `directories/wide`: above 1 s in all three repeats (1.07, 1.08, 1.06; median 1.07 s) against v1's median of 10.91 s."

**2. [P2] Evidence section, last bullet: the round-4 overclaim survives, so the "every finding applied" claims are untrue.**
- **Text:** "the earlier threshold screen is context for the regression this revision removes".
- **What is wrong:** Round 4 asked that the cross-run figures be context only, with no causal "removes". The body was fixed; this bullet was not.
- **Knock-on:** The Review record ("Every Part A finding was applied to this report") and the proof (`verdict_A: "… all applied to the report"`) are therefore not yet true.
- **Replace with:** "the earlier [threshold screen] is context for the omitted-refresh regression that revision showed, which does not appear in this run; its numbers are never pooled with these."

**3. [P2] "Cross-checks", "Review record", Evidence and proof: stale once this round exists.**
- **Stale text:**
  - "the corrected report was not sent for a further model review"
  - "Reviews, rounds 1 to 4"
  - "Raw prompts … of all four rounds"
  - proof `reviews.rounds: 4`
- **What is wrong:** This round-5 review of the corrected report exists. Publishing that sentence would be false.
- **Replace the sentence with:** "The corrected report was reviewed once more (round 5, `claude-opus-5-5`, tool-less, one turn) against the round-4 findings and the evidence; its findings and their disposition are in the review archive."
- **Also:** Update the archive (add round 5), the "rounds 1 to 4" link text and `proof.reviews` (rounds 5, with a `round_5` entry). Verify the model identity of this round the same way as the earlier rounds before writing it down.

**4. [P3] Verdict and "The missed prediction": the miss is not called a surprise.**
- **What the pre-registration requires:** "A missed prediction is reported as a surprise about the idea and is not explained away".
- **What the report says:** "reported as a miss and discussed below without excusing it".
- **Replace in the Verdict:** "It is reported, as pre-registered, as a surprise about the idea, and is discussed below without excusing it."

**5. [P3] "Other pre-registered limitations stand": non-UTF-8 coverage.**
- **Text:** "a non-UTF-8 name through scan, store and refresh end to end … tested by nothing".
- **Evidence:** The analysis JSON's `fixtures.*.raw_name_hex` decodes to `…/fixture-files/large/raw-\xff` (and the same under `fixture-directories`). The hosted fixture contains a non-UTF-8 name under `large`.
  - Every full scan and every retained refresh of `large` therefore walked it.
  - The oracle compared the probe snapshot with v1 using raw names.
  - Whether its name was stored as a node or only hashed into a bucket is not stated. The 9th retained node, beyond root plus the seven listed controls, is unidentified in the material.
- **Replace with:** "a non-UTF-8 name is present in the fixture (`large/raw-\xff`) and so passed through the hosted scans, the retained refreshes and the oracle, but no test checks its stored identity through scan, store and refresh end to end." Adjust this to what the snapshot actually stores. Also name the 9 retained nodes once in "What was measured".

**6. [P3] Plain terms (wide bullet) and "what it costs", last paragraph: generalisation and residual causality.**
- **Overclaim 1:** "This is the realistic cost of refreshing a path whose bucket is full" generalises one fixture, one envelope and one window of 4,004 entries, not exactly full.
  - **Replace with:** "This is the cost, in this run, of a near-full bucket window (4,004 of at most 4,096 entries)."
- **Overclaim 2:** "its latency depends on what its neighbours in the same bucket are" re-asserts the cause that the paragraph above says was not isolated.
  - **Replace with:** "a refresh of an omitted path pays for the whole bucket window; in this run the same 4,004-entry window cost 0.18 s or 1.07 s depending on the profile."

**7. [P3] "What was measured": seed sharing is understated.**
- **Text:** "so the three repeats of a cell share seed state".
- **What the host does (fact 12):** It copies `seeds[arm]` for every scenario and every repeat, so all 12 timed commands of one arm in one profile share one seed.
- **Replace with:** "so all twelve timed commands of an arm in a profile, across the four scenarios and three repeats, share one seed state."

**8. [P3] "Disk is a lower bound": count of in-flight samples.**
- **Text:** "one run caught a publication in flight, at 92 KiB".
- **Evidence:** Proof and fact 7 say "two runs also sampled `.coarse.tmp`/`.coarse.tmp-journal` in flight". Only one of them raised the peak above 76 KiB.
- **Replace with:** "two runs sampled a publication in flight; one of them raised the sampled peak to 92 KiB".
- **Also:** The Plain-terms definition "(sampled lower bound of the output directory plus its growth)" should say "plus the sampled rise of its filesystem's used bytes", as the pre-registration defines it. The rise is filesystem-wide, which is one way a run whose sampled files sum to 72 KiB can record 76 KiB.

**9. [P3] "Cross-checks": scope of the independent check.**
- **What is wrong:** The check is said to be "written from the pre-registration's rules" and to recompute the bars and the overall rule. It does not implement the D4 exchange (it returns "needs an exchange (not evaluated by this script)") or the memory-flag/inconclusive rule. Neither was triggered in this run.
- **"One command":** "reproduces … with one command" is wrong; the docstring needs two (unpack, run).
- **Add:** "It does not implement the exchange branch of D4 or the memory-flag rule, neither of which this run reached; reproduction is the two commands in its docstring."

**10. [P3] Review record, B3 disclosure: mitigation slightly softened.**
- **Text:** "The frozen work report, which matched the plan in every repeat, covers part of this."
- **What is wrong:** A work report compared with the same plan cannot catch a wrong plan window. What mitigates the coinciding-bug case is that the reported window `[945,956)` equals the pre-registered window computed beforehand by the Python reference and pinned in the Rust tests. The disclosure also omits round 4's point that the oracle output does not echo the scope, boundary and window it was given.
- **Replace with:** "The oracle's output does not echo the expectation it received, and the analysis does not check the per-scope counts. The plan's windows equal those pre-registered from the independent Python reference (`[945,956)` at 1M), which bounds, but does not exclude, a coinciding plan and probe bug."

**11. [P3] Verdict: "the independent reviewer recomputed the verdict by hand".**
- **What is wrong:** The reviewer is a model of the same family, as the Review record says.
- **Replace with:** "the round-4 model reviewer (`claude-opus-5-5`, without tools) recomputed the bars and predictions from the repeats in the analysis JSON."

**12. [P3] "Cost and protocol history": "nothing changed between the smoke and the screen".**
- **What is wrong:** This is broader than the evidence. The runners and hosts differ.
- **Replace with:** "no source, workflow, binary, image or analysis script changed between the smoke and the screen."

## Part B disclosures check

All nine are present.

- **Fairly stated (eight):**
  - seeding sentence (B5/B3)
  - "at least one fresh item" (B2)
  - empty buckets carry no stamp (B2)
  - `< 1 s` bound not pinned (B4)
  - prediction wording loosened (B5)
  - exactness starts at `metrics.json` (B1)
  - host masking and `docker rm -f` warnings, with a job-log statement (B3)
  - smoke cross-check covers only `runtime.json` (B1)
- **Understated (one):** the oracle-versus-plan item (B1/B2). "Covers part of this" overstates what the work report mitigates, and it drops the fact that the oracle does not echo its inputs; see new finding 10.
- **Minor:** The "at least one fresh item" text justifies redundancy only by the boundary check. For `full` scope the reason is that every node must be fresh. This is acceptable as written.

## Decision

**PUBLISH AFTER THE LISTED FIXES.** The verdict, all 48 bars, `overall.success: true` and 31/32 predictions are correct. I spot-recomputed medians, MiB and KiB conversions, every value in the cgroup-memory column, the per-repeat times, the 9.8%, the 0.89 s gap, the 232 s and 231 s gaps, the 227 s floor and the runner-time sums against the JSON and CSV, and found no table error.

What remains is text only:
- the false "1.07 s in all three repeats";
- the surviving "removes" in Evidence, and with it the "every finding applied" claims;
- the stale "not sent for a further model review" and the round counts;
- the P3 wording items.

On the verdict section: it is faithful to the pre-registration's reporting duties.
- The verdict is taken from `overall`.
- The predictions are scored beside it and explicitly "never change it".
- The miss is reported without being argued away; the hypothesis is labelled untested, and the remedy now needs a new experiment.
- No claim about minimum RAM or capacity is made, and D3's budget clause and D11 are listed as open.

The only gap is that the miss is not called a "surprise about the idea" as pre-registered (finding 4).

## Not verified

- **Archive:** Round-1 "one turn" and "every assistant message" ("as the archived outputs show").
- **Proof and fact claims:** the hashes, the ZIP digest, the 229-file identity, the 61,203 s ledger base and the local preflight's "same projection".
- **Job logs and environment:** the absence of `docker rm` warnings in the screen's job log, and "2 CPUs".
- **Calibration location:** whether the calibration ran "in the job". The JSON says `checked_locally: true, profile: local`, which I read as the local-disk profile but could not confirm.
- **Oracle counts:** the per-scope oracle counts (9/257, 7/2, 1/1), and which node is the 9th retained node.
- **Non-UTF-8 entry:** how `raw-\xff` is stored.
- **Per-file sizes:** the decomposition of the probe's disk use. In fact 7, seven runs show `coarse.db` at a maximum of 36 KiB but only three end at 72 KiB. The 50 ms samples probably missed the final state of fast refreshes, but I could not confirm this without the raw files.
- **Independent check:** its extraction half, whose raw `time.json` and `metrics.json` files are not in the material.
- **Miss hypothesis:** the fixture's even/odd alternation, and the ext4 and IOPS assumptions behind the hypothesis about the missed prediction.
