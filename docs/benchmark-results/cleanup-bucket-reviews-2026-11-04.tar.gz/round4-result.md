# Review round 4: results report and delta ba8281f over 0942a50

## Part A findings

**[P1] "The missed prediction and what it costs", first sentence: wrong count of cells.**
- **What is wrong:** The report says the omitted-and-wide prediction "hit in seven of the eight cells and missed in `directories/wide`". That prediction applies only to the four omitted and wide cells.
- **Evidence:** The `predictions.cells` key `under_a_tenth_of_v1_and_1_s` exists in exactly four cells: files/omitted, files/wide, directories/omitted and directories/wide. Three are `true` and one is `false`.
- **Fix:** "It hit in three of the four cells it applies to (omitted and wide, both profiles) and missed in `directories/wide`."

**[P2] "What was measured": "Scenarios, each timed from its own two-scan seed" is false. The pre-registration says the same.**
- **Evidence:**
  - `cleanup_probe_host.py` seeds once per arm per profile: two scans, stored in `seeds[arm]`.
  - Every timed cycle of every scenario and repeat runs on `shutil.copytree(seeds[arm], case)`.
  - The analysis has `seed_cases_excluded: 8`, which is 2 profiles × 2 arms × 2 scans, not one seed per scenario.
- **Why it matters:** The three repeats of a cell share one seed state, so they are less independent than the text implies.
- **Fix:** "Each timed command starts from a fresh copy of the same two-scan seed of its arm and profile (8 seed scans in all). Repeats therefore share seed state." Also disclose that the pre-registration's wording "each measured separately from its own two-scan seed" does not match the code that ran.

**[P2] "Result in plain terms", omitted bullet: "The name-hash buckets remove that regression entirely" overclaims, and it leans on a cross-run comparison.**
- **What is wrong:**
  - The 36.7 s and 269 s figures come from another revision, run and runner. The report may quote them as context, but cannot use them to draw a causal conclusion.
  - "Entirely" generalises from one fixture, unchanged trees and one I/O envelope.
- **Fix:** "In this run, refreshing the omitted folder is faster than v1 in both profiles, so the regression against v1 seen in the earlier revision does not appear here. The earlier figures (36.7 s and 269 s) are from another revision and run and are not compared directly."

**[P2] Plain terms and Verdict: the omitted scenario is a best case, and the report does not say so.**
- **What is missing:**
  - `small` is the root's lone bucket and holds 100 entries. The pre-registration added `wide` precisely because `small` flatters the idea.
  - An omitted path in a typical directory shares a bucket of up to about 4,096 entries. After demotions the bound is soft and can be exceeded.
  - The realistic cost is therefore the wide case: 0.18 s or 1.07 s under this envelope, depending on what the neighbours are.
- **Fix:** Add to the omitted bullet: "This is the best case: the window holds only the 100 target entries. An omitted path that shares a full bucket costs the whole window, as in the wide scenario."
- **Also:** In "Wide windows cost the whole bucket", add the soft bound after demotions from the pre-registration's limitations.

**[P2] "The missed prediction", and the Verdict sentence on the miss: partial-credit framing, and a causal claim stated as a finding.**
- **"Half holds" framing:** "the 'under 10%' half holds" scores a conjunction half by half, which the pre-registration does not do. The relative half held by only 0.2 points (9.8% against 10%). Under "not explained away", the Verdict should state only the miss, for example: "missed: median 1.07 s against the prediction of under 10% of v1 and under 1 s".
- **Causal claim:** "So the cost of the idea is not set by the number of visits alone: it is higher where the window consists of directories" is a causal attribution from a two-profile comparison that differs in more than the window. Reword: "is higher in the `directories` profile, whose window is about half directories, at the same reported visit count."
- **Hypothesis labelling:** The hypothesis is labelled as untested, which is acceptable. The arithmetic is right (2,000 / 2,200 ≈ 0.91 s against a gap of 0.89 s). It does leave out:
  - the window has about 2,004 directories, not 2,000 (the four chunk directories plus about 2,000 children);
  - the probe makes two passes (8,010 visits); the hypothesis only holds if the second pass is served from cache;
  - it assumes no ext4 `inline_data`, under which an empty directory needs no block read.
- **Optional consistency check (label it as untested):** The full-scan gaps are also close to 500,000 / 2,200 ≈ 227 s: the probe's gap is 269.38 − 37.01 = 232 s and v1's is 293.36 − 62.72 = 231 s. If this is the cause, it also explains why D8 failed in `directories/full`: both arms pay the same per-directory read floor.
- **Drop or reword the remedy:** "If this is right, the cost … would shrink with a smaller cap or with warm caches" starts to argue the miss away. Either drop it, or keep it and add "untested; it would also need a new experiment".

**[P2] Plain terms (peak disk bullet) and the Absolute measurements note: per-repeat probe disk is not always 76 KiB.**
- **What is wrong:**
  - "the probe's snapshot pair is the same 76 KiB at the peak and at the end" holds only for the medians.
  - The decomposition "a 36 KiB snapshot … plus the output directory's own 4 KiB block" is stated as fact, but author fact 7 says the 4 KiB block was not checked.
- **Evidence:**
  - Three repeats show 73,728 bytes (72 KiB): directories/retained r1, directories/omitted r2 and directories/wide r2.
  - directories/wide r3 shows a sampled peak of 94,208 bytes (92 KiB) against a final 77,824. This is the only sampled publication transient in the run.
  - 72 KiB equals 2 × 36,864 with no directory block, so the decomposition does not fit every repeat.
- **Fix:** "Median 76 KiB; individual repeats 72–92 KiB (one sampled transient of 92 KiB in directories/wide r3). The split into two 36 KiB files plus a directory block is the author's reading and was not checked."

**[P2] "Review record": incomplete once this review exists.**
- **What is missing:** The report should record round 4, a post-run model review of the results and of the ba8281f delta, with its outcome. It should state that the ba8281f fixes were reviewed only after the smoke and the screen had run.
- **Wording to fix:**
  - "fixed in `0942a50`" and "fixed in `ba8281f`" should read "fixed or disclosed". Round 2 disclosed the arm order and the absent Python linter instead of fixing them, and round 3 replaced the proposed linter.
  - The round-1 record in the pre-registration cites only "the CLI's init event and `modelUsage`" and does not say "one turn". The report's "every assistant message … one turn each" therefore overstates what was recorded for round 1, unless the archive shows otherwise.

**[P2] "Cost and protocol history": "no source, workflow or analysis file changed between the smoke and the screen" is stronger than the cited evidence.**
- **What the evidence supports:** The proof shows identical binary hashes, an identical runtime image and an identical analysis-script hash in both artifacts. Byte-for-byte equality of all 229 captured files is asserted for the screen only. The material shows neither the smoke's head SHA nor the workflow file's hash.
- **Fix:** "The smoke and the screen used identical binaries, runtime image and analysis script (hashes in the proof), both dispatched from `ba8281f`." Use that wording, or check and cite the smoke's captured source and run SHA.

**[P3] "What this does not show": pre-registered limitations are left out.**
- The three repeats inside a judged cell are ordered 2:1 by arm, and no order effect was estimated.
- Renames leave another bucket stale.
- A retained file target rescans its parent.
- Non-UTF-8 names and demotion into an over-cap bucket followed by a refresh are tested by nothing.
- **Fix:** Add one bullet listing these, or link the pre-registration's "Known limitations" explicitly as part of the report's limits.

**[P3] Verdict table, D4 row: the pre-registered disclosure sentence is missing.**
- **What is missing:** The pre-registration says "In practice this bar then reduces to 'at most 15% slower in every repeat', and the report says so." The report only says the exchange "never came into play".
- **Fix:** Add "Had the probe been up to 15% slower, the disk exchange would have passed it anyway; D4 is effectively a 15% cap."

**[P3] "Every one of these cells came out the same way in all three repeats" is ambiguous.**
- Values did vary, for example directories/omitted probe at 0.02 s in one repeat and probe disk at 72–92 KiB.
- **Fix:** "The verdict and the direction of every bar were the same in all three repeats."

**[P3] Cost and protocol history: admission figures and run claims.**
- The figures 4,420 / 5,746 / 12,600 are the in-job admission values from the proof. The preflight forecast is a separate file that is not quoted. Say "in-job admission".
- "The smoke passed on the first attempt" and "No run was repeated" are supported only for the screen (`run_attempt: 1`).
- **Fix:** Cite the smoke's attempt number.

**[P3] Ledger and integrity wording.**
- The campaign total of 66,495 s cannot be verified from the material. It also mixes accounting bases: CI is counted here but was not counted in earlier entries. Either restate the earlier entries on the same basis or flag the mix next to the total.
- In Evidence, add "the smoke ZIP was not independently hashed" (proof: `full_github_zip_independently_hashed: false`).

**[P3] Plain terms, RSS bullet: carry the caveat next to the number.**
- **Fix:** Add "(writer resident set under an 8 GiB ceiling; not a lower required RAM)" next to the −97% figure.

**[P3] "Both arms are built from the same source" against "v1 (unchanged master `afce6fd`)".**
- **Fix:** State how v1 was built, for example "v1's code in `ba8281f` is unchanged from `afce6fd`", and say whether that was checked.

**A1 summary:** I recomputed every median, matched change, per-repeat time quoted in the text, absolute-table cell (MiB conversions included) and percentage, and I found no discrepancy between the CSV and the JSON. Everything else agrees with the JSON. The only discrepancies are the "seven of eight" count, the per-repeat 76 KiB statement and the unverified 4 KiB decomposition.

**A2 (independent verdict):** Working by hand from the repeats with the pre-registered rules, I agree with all 48 bar verdicts:
- `directories/full` D8 fails because every repeat is about −8%.
- D4 passes in both full cells, with every repeat faster beyond the floors.
- `overall.success = true`.

I also agree with all 32 predictions: 31 hit and `directories/wide` misses on the 1 s bound.

One note on the author's recomputation: it is independent of the rule code but not of data extraction, because the CSV is derived from the analysis JSON.

## Part B findings

**[P3] B5/B3: the pre-registration's seeding description contradicts the host.**
- **What is wrong:** "each measured separately from its own two-scan seed" does not match the host, which takes one seed per arm per profile and copies it for every cycle (the same finding as in Part A).
- **Effect:** The verdict does not change; this is a disclosure.

**[P3] B2: "at least one fresh item" adds nothing with a real snapshot.**
- **Why:** A real snapshot always retains the root. For `full`, every node must be fresh. For `retained` and `range`, the boundary is required to be a retained node and to be fresh. So `fresh_nodes + fresh_buckets == 0` is reachable only with an empty snapshot, and the only test for it uses one.
- **Fix:** In the round-3 disposition, reword "nothing enforced a fresh item" to "the fresh item was already implied by the boundary check".

**[P3] B1/B2: the analysis does not verify what the oracle was asked to check.**
- **What is missing:**
  - The oracle's JSON does not echo the scope, boundary and window it was given.
  - `check_oracle` requires only `refresh_checked` and more than zero fresh items. It does not require the per-scope counts (9/257, 7/2, 1/1).
- **Effect:** The link between the stamp proof and the frozen plan rests on `plan.refresh_expectation`, which is not in the material. Two coinciding bugs could pass: a wrong plan window together with a probe that stamps the same wrong bucket. The verdict does not change; disclose it.

**[P3] B2: buckets without entries are skipped.**
- A rewrite of an empty slot range cannot be seen.
- **Effect:** Harmless, but "nothing else advanced" should read "nothing else that carries a stamp advanced".

**[P3] B4: one prediction boundary is not pinned.**
- **What is missing:** No test isolates the `< 1 s` bound at exactly 1.0 s with the relative bound still holding. A mutation to `<= 1` survives, because the only 1.0 s test also fails the relative half (10.0 against 10.0).
- **Fix:** Reword the round-3 disposition's "tests for every boundary" accordingly.
- **Effect:** Irrelevant to the reported miss at 1.07 s.

**[P3] B5: the unreviewed delta loosened the prediction wording before the run.**
- "well under 1 s" became "under 1 s".
- "reported as a failure of the idea" became "a surprise about the idea".
- **Effect:** Legitimate before any run, and the outcome is the same, since 1.07 s misses both versions. Disclose that the reviewed version was stricter.

**[P3] B1: exactness starts at `metrics.json`.**
- **What is wrong:** "Exact rational arithmetic on the decimal values as written" begins after the worker converted GNU `time` output. That conversion is not in the material.
- **Effect:** All values in this run are clean two-decimal numbers, so no tie is affected.

**[P3] B3: residual masking and invisible warnings in the host.**
- `container_state` can still mask the writer's log: malformed inspect output, a missing `State` key or an inspect timeout would raise from inside the `try` block. Moot after this run.
- `remove_container` warnings go only to the job log. The artifacts and the analysis cannot see them.
- **Fix:** State whether the screen's job log shows any `docker rm -f` warning.

**[P3] B1: the smoke cross-check covers only `runtime.json`.**
- `provenance(..., smoke_root)` compares only that file. The equality of binaries and source between smoke and screen is enforced outside the analysis, by a workflow that is not in the material.

**Checked with no finding:**
- **Analysis rules:**
  - `direction` requires a difference to exceed both floors.
  - The tie at 15% is inside the limit.
  - The worst-repeat exchange sizing is right.
  - Memory flags make D3, D9 and the RSS exchange inconclusive.
  - The 4x disk factor is applied.
  - The smoke masks bars and predictions.
- **`overall`:** It refuses an incomplete set of cells and excludes inconclusive results from the confirmed benefits.
- **"Or a median above it" (no-increase bars):** Not coded explicitly, but it is implied. The allowance f(b) = b + max(rel·b, abs) is monotone, so if pᵢ ≤ f(bᵢ) in every repeat, then median(p) ≤ f(median(b)).
- **Predictions:** Exact comparisons on the arm medians, matching the pre-registration.
- **v1 rows:** The full scan checks `entries`; refreshes check `subtree_entries`.
- **Oracle `inside()` and boundary normalisation:** Correct for a trailing slash, for `/` and for a sibling sharing the boundary prefix.
- **Oracle rejects broken probes:** A no-op, a wrong window and any extra stamped rewrite, including a silent root fallback, are all rejected.
- **Oracle accepts correct probes:** In the hosted scenarios, I found no way for a correct probe to be rejected.
- **Description:** The document's statement of what the oracle proves is accurate.

## Verdict A

**PUBLISH AFTER THE LISTED FIXES.** The verdict, all 48 bars, `overall` and the 31/32 prediction score are correct. Nearly every number matches the JSON and the CSV. Three things must change before publication:
- the false count "seven of the eight cells", which must become "three of four";
- the false protocol statement "each timed from its own two-scan seed";
- the overclaims that would mislead a product decision: "removes that regression entirely", the unstated best-case nature of the omitted scenario, and the per-repeat disk wording.

The missed-prediction section also needs work. Remove the "half holds" partial credit, reword the causal sentence as an observation, and complete the review record with this round. The P3 items are disclosures and wording.

## Verdict B

**NO.** Nothing in the delta puts the reported verdict in doubt:
- I found no input on which the frozen analysis would report a failed or inconclusive bar as passed, or score a prediction wrongly.
- My hand recomputation agrees with every reported bar and prediction.
- The oracle changes only tighten acceptance.

The delta findings are disclosures. The most relevant are the seed-sharing contradiction in the pre-registration, the unverified link between the oracle's expectation and the plan, and the loosening of the prediction wording before the run.

## Not verified

- **Code not in the material:** `cleanup_probe_plan.py` (`scope`, `refresh_expectation`, `order`), the worker (GNU `time` parsing, flags), the fixture builder (the even/odd alternation of directories and files), the Rust probe, v1, and both workflows, including whether the smoke and screen ran the same captured source and workflow.
- **Author-checked facts:** All ten listed facts. In particular:
  - the 56 `metrics.json` files;
  - the oracle counts 9/259, 4,004, 9/257, 7/2 and 1/1;
  - the snapshot size of 36,864 bytes and its decomposition;
  - the hashes and ZIP digest;
  - the runner seconds and the campaign total of 66,495 s;
  - "124 Python tests" and the mutation checks;
  - the pre-registration's hash and the commit preceding the smoke.

  Some of these are implied indirectly by `valid: true` together with `check_arm_row` and `check_oracle`: the probe's report fields and v1's `subtree_entries`.
- **Other documents and archives:** The D5/D14 quotations from the v1 plan, the content of the round-1 to round-3 review archives, the smoke analysis and the preflight file.
- **Filesystem assumptions:** ext4 `inline_data` and directory-block behaviour, on which the miss hypothesis depends.