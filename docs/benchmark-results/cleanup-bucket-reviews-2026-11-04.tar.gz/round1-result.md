# Review: bucketed residual cleanup probe

## Findings

**[P1] `buckets.rs` `find` and `walk.rs` `Scope::admits`: clippy `-D warnings` will very likely fail**
- **What is wrong.** `b.lo <= slot && slot < b.hi` and `self.lo <= slot && slot < self.hi && …` match `clippy::manual_range_contains`, which is a warn-by-default style lint. `state::scope` already uses `(lo..hi).contains(..)`, so the style is inconsistent.
- **Why it blocks dispatch.** `cleanup-ci.yml` would go red. `v2-balance.yml` runs `cargo test` but not clippy, so the smoke could measure a source that breaks the repo gate. The fix then changes the measured source, and the doc's own rule requires a new smoke.
- **Fix.** Use `(b.lo..b.hi).contains(&slot)` and `(self.lo..self.hi).contains(&slot) && !self.skip.contains(name)`. Run `cleanup-ci` green before dispatching.

**[P1] `cleanup_probe_plan.probe_scope`: reads `fixture['scale']`, which the diff never adds**
- **What is wrong.** `wide_range(fixture['scale'])` needs that key. The diff to `cleanup_probe_fixture.build` adds only the controls. The `receipt()` helper in `test_cleanup_plan.py` invents `scale=count`, so the contract tests pass whether or not `build()` writes it.
- **Scenario.** If the key is absent, the run raises `KeyError` at the first probe `wide` case. That is the last scenario of the `files` profile, after about three quarters of the smoke budget is spent, and a failed smoke may not be rerun unchanged.
- **Fix.** Either have `build()` write `receipt['scale'] = count`, or derive the chunk count from `bulk_files`/`bulk_directories`. Add a test that runs `build()` on a tiny count (or a stubbed filesystem) and feeds the real receipt into `plan.scope`.
- **Needed to close this.** I need `cleanup_probe_fixture.py` in full.

**[P2] `main.rs` `refresh`: a deleted target loses bucket targeting and is misreported**
- **What is wrong.** `let target = live_ancestor(target)?` shadows the requested path, and the plan is then computed on the live ancestor.
- **Scenario 1.** Delete `root/large/x`, where `x` was folded and `large` is retained. Then refresh `root/large/x`. The plan becomes `Retained(large)` and the whole retained directory is rescanned.
- **Scenario 2.** Delete `root/small` and refresh it. The live ancestor is the root, so a full root rescan runs. It reports `fallback_full_root: false` because `target != root` compares the shadowed value.
- **Why it matters.** Delete-then-refresh is the main workflow of a cleanup tool. It reproduces the 36.7 s / 269 s regression this revision exists to remove. It also contradicts the `buckets.rs` header claim ("never the whole retained directory").
- **Fix.** Keep the requested path. Canonicalize only the live prefix and re-append the missing suffix. Plan on that path, since `state::plan` does not need existence and `scan_range` copes with absent names. Compute `fallback` from the original request.
- **Disclosure and testing.** Disclose this, and add delete-then-refresh to the untimed correctness tests (or to the scenarios).

**[P2] `main.rs` `refresh_range` / `state::update_range`: the parent's own stats are never refreshed**
- **What is wrong.** A range refresh replaces buckets but keeps the retained parent's `own_allocated`, `own_apparent` and `scanned_at` from the old snapshot.
- **Scenario.** Create a few hundred files in a retained directory such as `root/bulk/`, then refresh one of them. The ext4 directory inode grows by one or more blocks. Totals now differ from v1 and from a full rescan.
- **Why the tests miss it.** `range_refresh_matches_a_full_rescan` only adds files inside a folded child, so the parent inode does not change. The doc's claims "both are exact" and "never left wrong" are not supported.
- **Fix.** `scan_inner` already stats the parent (`folded.root`). Copy its own fields into the parent node in `update_range`. Add a test that adds direct entries to the parent and compares against `walk::scan`.

**[P2] Timed refreshes never exercise the merge, and the oracle could not validate one if they did**
- **What is wrong.** All refresh scenarios run on an unchanged tree. The post-refresh snapshot is therefore byte-for-byte the seed layout plus a new generation. A `update_range` that silently did nothing would pass both `scope_errors` and the oracle.
- **The oracle cannot fill the gap as written.** `Walk.check_buckets` requires the from-scratch greedy tiling `cb.tile(n['slots'])`. Range re-tiling and demotion absorb are history-dependent, so after any real change the oracle would reject a correct snapshot.
- **Fix.**
  - Add an oracle mode that checks a valid tiling plus, for each stored `[lo, hi)`, the exact sum of v1 children hashing into it. Cap checks become soft, and the layout is not required to match.
  - Add at least one untimed smoke cycle that mutates the tree (add, delete, grow past threshold) and then refreshes `small` and `bulk/g000050`.
  - Otherwise, state explicitly in the report that merge correctness rests on local Rust tests only.

**[P2] Doc, "Confirmed" and decision bars: regressions are judged more leniently than benefits**
- **What is wrong.** A regression counts only if all three repeats point the same way and the median clears the floor. So a true 10 % RSS or full-scan regression with one noisy repeat is "not confirmed", and passes "no confirmed increase".
- **Same gap for memory.** A cap, reclaim or OOM flag makes the memory comparison "inconclusive". Nothing says an inconclusive non-inferiority bar is a failure; "Inconclusive is not a pass" is stated only for benefits.
- **Ambiguous noise floor.** "5 % and 0.05 s" does not say whether a change must exceed both or either.
- **Fix, before any run.**
  - A no-increase bar passes only if it is affirmatively shown: e.g. all three repeats below the floor, or a median below the floor with no repeat above the bar.
  - Inconclusive on any bar means not a pass.
  - Write "a change is noise unless it exceeds both 5 % and 0.05 s".

**[P2] Cross-language wide window is pinned only in Python**
- **What is wrong.** `test_wide_bucket_ranges_are_pinned_across_languages` pins `(804, 971, 4004)` and `(945, 956, 4004)` with `cleanup_buckets.py` only. Rust shares just six hash vectors.
- **Scenario.** Any Rust tiling divergence on these inputs (tie handling, range bounds) shows up only at the last smoke scenario.
- **Fix.** Add a Rust unit test in `buckets.rs`. It should tile `g000000..g000099` and `g000000..g000999` at 1001 entries each and assert the same windows. Both workflows run it before measuring.

**[P2] `cleanup-ci.yml` "Lints": clippy skips all test code**
- **What is wrong.** `cargo clippy --example cleanup_probe` does not compile `#[cfg(test)]` modules. `bucket_tests.rs`, `tests.rs` and `buckets::tests` are therefore never linted, including `too_many_lines` and nesting.
- **Example.** `bucket_tests.rs` has `bucket.lo <= slot && slot < bucket.hi` in `folded_children_tile_all_slots…`.
- **Fix.** Use `cargo clippy -p freespace --example cleanup_probe --tests --locked -- -D warnings`, or `--all-targets`.

**[P2] `cleanup_probe_plan.v1_scope` / `probe_scope`: the `directories` profile assumptions are untested**
- **What is wrong.** `CHUNK_ENTRIES = 1001` is hard-coded rather than checked against the receipt the way `subtree_sizes` checks `large`/`small`. `test_cleanup_plan.receipt()` models only the `files` profile.
- **Scenario.** If bulk chunk children in the `directories` profile are not empty leaves (for example, each holds a file), every `directories`/`wide` case fails the scope check mid-run.
- **Fix.** Derive the chunk subtree size from receipt fields and assert it. Add a `directories` receipt test.
- **Needed to close this.** I need `build()`.

**[P3] `state::verify` does not check structure**
- **What it accepts.** It does not require exactly one parentless node, or that this root equals `meta.root`. It does not require `path.parent() == parent`, that the parent has `kind == 1`, or that `kind ∈ {0, 1, 2}`.
- **Scenario.** Tampering a node's `parent` to a sibling directory with matching totals passes `read`. `plan`/`scope` then misattribute names, and `state::links` picks an arbitrary root.
- **Fix.** Add these checks, plus tamper tests for them.

**[P3] `state::scope`: retained siblings in the range are never revisited**
- **What is wrong.** They are skipped by name, so a deleted, shrunk or replaced retained sibling stays stale. A retained-dir path later replaced by a file makes `refresh_retained` fail with "root must be a directory".
- **Fix.** Disclose this, or `lstat` skipped names during the range scan and fall back to `Retained(parent)` when they changed.

**[P3] `cleanup_probe_plan.order`: the arm order is identical in both profiles**
- **What is wrong.** Each screen scenario is 2:1 the same way in both profiles.
- **Fix.** Use `ORDERS[(scenario_index + pair + profile_index) % 2]`. That gives 3:3 per scenario across profiles at no cost.

**[P3] Doc predictions: "Full scans … within ±10 % of the previous probe" is a cross-run comparison**
- **What is wrong.** It compares against a different runner and run, which is what the doc forbids for v2 numbers.
- **Fix.** Mark it as non-evaluable, or drop it.

**[P3] Overclaims in the doc and in `buckets.rs`**
- "Both are exact", "never left wrong" and "never the whole retained directory" are contradicted by the deleted-target, parent-own-stats and retained-sibling findings.
- **Fix.** Reword, and list these under Known limitations.

**[P3] Hash spec is pinned only by mutual agreement**
- **What is wrong.** The Rust/Python vectors could both be derived from one implementation.
- **Fix.** Add canonical FNV-1a-64 vectors before the mix in both languages, e.g. `FNV1a64("a") = 0xaf63dc4c8601ec8c`.

**[P3] Workflows: third-party actions are pinned by tag, not SHA**
- `dtolnay/rust-toolchain@1.99.1`, `Swatinem/rust-cache@v2` and `oven-sh/setup-bun@v2` are tag-pinned. Permissions are read-only and there are no secrets, so the risk is low.
- **Fix.** Pin to commit SHAs.

**[P3] `cleanup-ci.yml` coverage gaps**
- **What is missing.**
  - It runs no size-limit or nesting checker.
  - It runs no Python linters (ruff plus mypy/pyright) for the new scripts.
  - Its `paths` filter omits `Cargo.lock`, `cli/Cargo.toml`, `clippy.toml` and `rustfmt.toml`.
- **Fix.** Add the repo's size checker and linters, and widen the paths filter.
- **Needed to close this.** Confirm whether another workflow on this branch already runs the size checker and linters.

**[P3] `store::write`: bucket-cap errors are reported late**
- **What is wrong.** `MAX_BUCKETS` is enforced only at write, after a full scan or refresh.
- **Fix.** Count buckets in `seal`/`update_range` and fail early.

**[P3] Missing Rust tests for risky paths**
- Deleted target, and target outside root.
- Non-UTF-8 name through scan → store → plan → `scan_range`.
- Range-refresh promotion by the entries rule (a child grows past 4096 entries).
- Demotion into an over-cap bucket followed by a range refresh of it.
- Store tamper cases: overlapping buckets, `slot_bits` mismatch, two roots.
- Snapshot with `has_hardlinks` while the target region has none.
- Retained target replaced by a file.

## Verdict

**NO-GO** for the hosted smoke.

The likely clippy failure (`manual_range_contains`) means the source as committed does not pass the repo gate. `v2-balance` does not run clippy, so the smoke could measure a source that must then change, and the doc's own rules require a new smoke after any source change. Separately, the `wide` expectation depends on `fixture['scale']`, which the diff does not show being produced. If absent, it would crash late in the smoke.

Both are cheap to fix:
1. Fix the range comparisons.
2. Add the Rust wide-window test.
3. Confirm or add `scale`.
4. Run `cleanup-ci` green.

Before dispatching, also amend the pre-registration to treat inconclusive no-increase bars as non-passes. Either disclose that merge correctness is not exercised on hosted runs, or add the tiling-independent oracle mode with one mutated cycle. The P2 behavioural gaps (deleted targets, parent own stats) do not affect the timed unchanged-tree scenarios, but they must be disclosed in the results report.

## Not verified

- Whether the Rust code compiles and passes. The doc says only a std-only harness ran locally. In particular, `tests.rs` lines outside the diff may still reference `rest`, `update`, `rebuild` or `prune` unqualified, and the `main.rs` remainder may need the removed `HashMap`/`MAX_RECORDS` imports.
- The numeric hash vectors (3979, 59, 3502, 1228, 1142, 3954) and the pinned windows (804–971, 945–956).
- Whether `manual_range_contains` fires exactly as expected on the toolchain 1.99.1 clippy.
- `cleanup_probe_fixture.build`: the `scale` key, the directories-profile chunk contents, and the location of the root-level entries. The receipt arithmetic suggests the root holds only `bulk`, `small` and `large`.
- The `metadata_pass` stack layout (`stack.len() == 1` meaning root children), and `live_ancestor`'s canonicalization and symlink handling.
- `scope_errors` and `run_container` in `cleanup_probe_host.py`.
- `store::publish` atomicity.
- Total line counts of `main.rs`, `walk.rs`, `store.rs` and `cleanup_probe_host.py` against the 500-line limit.
- `rustfmt --check` output.
- Whether `v2-balance.yml`'s source-hash selectors cover `cli/examples/cleanup_probe/**`.
- Runtime behaviour: RSS, timings, and the test runtime of 5000-file temp trees.