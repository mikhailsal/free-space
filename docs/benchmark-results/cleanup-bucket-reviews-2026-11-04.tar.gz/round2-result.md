# Round 2 review of commit 59a977f

## Findings

**[P2] `scripts/cleanup_oracle.py` `Walk.check_node` / `check_buckets`: the hosted run cannot tell a real refresh from a no-op, and the new parent re-read is never checked.**
- **What is wrong.** The node check computes `expected['min_scanned_at']` from `actual['scanned_at']`, the probe's own value, so a node's freshness can never fail. The bucket check tests only whether `min_scanned_at` is present, not its value. Every refresh cycle runs on an unchanged tree, so the seed snapshot is already the exact folded image of v1.
- **Trigger.** A refresh that publishes the copied seed state unchanged passes the oracle, as long as its self-reported `visited`, `boundary`, `scope` and `range` match the plan. The same holds for a bug that skips `update_range`, or skips the new `own_*`/`scanned_at` copy. The probe's only evidence of work is its own counters.
- **Doc overclaim.** "every bucket row … freshness extrema" overstates the check: `min_scanned_at` is checked for presence only.
- **Fix.** Pass the seed `coarse.db` to the oracle for refresh cycles and assert:
  - `generation` equals seed + 1.
  - Retained refresh: every node at or below the boundary has `scanned_at` greater than the seed's.
  - Range refresh: the parent's `scanned_at` and the refreshed bucket's `min_scanned_at` are greater than the seed's. Every other bucket and node is byte-identical to the seed.
  - Strictness is guaranteed: refreshes start more than 1.05 s after the last seed, and stamps are whole seconds.

**[P2] The pre-registered judgment rule is not implemented in any frozen code.**
- **What is wrong.** `run()` in `cleanup_probe_host.py` stores only per-arm medians in `manifest['comparisons']`. The rules in "How a bar is judged" need per-pair data: paired per-repeat differences, `max(relative, absolute)` floors, per-cell inconclusive flags, and passed/failed/inconclusive per bar. None of this is computed. A manual analysis written after results are seen leaves room to pick the convenient statistic, which is what the stricter rules are meant to prevent.
- **Fix.** Add `cleanup_probe_verdict.py` with contract tests, before the smoke. It reads the case `metrics.json` files, pairs them by `(profile, scenario, pair)`, applies each bar, and writes a verdict per bar per profile × scenario. Any missing, invalid or flagged cell makes the verdict `inconclusive`. Include it in the source capture.

**[P2] Doc, full-scan bar: the judgment is ambiguous.**
- **What is wrong.** "A bar with its own explicit tolerance … judged against that tolerance without adding a floor" leaves four questions open:
  - Must every repeat be at most +15%, or only the median?
  - Does a +1% increase (below the 5% / 0.05 s noise floor) trigger the "2x that percentage reduction in another metric" clause? "Without adding a floor" says it does, while the noise rule says it is no change.
  - Must the compensating reduction be *confirmed* (all three repeats), and by which percentage: the median or the worst repeat?
  - Is the bar judged per profile?
- **Fix.** Specify each point explicitly. For example: every repeat must be at most +15%. Any repeat above the noise floor requires a confirmed reduction of at least 2 × the worst-repeat increase. Judged per profile.

**[P2] `cleanup_probe_worker.py`: peak disk is a sampled lower bound, and it is biased toward the short-running arm.**
- **What is wrong.** The sampler reads `filesystem_used` once at start, then every 50 ms. A probe refresh is expected to finish in about 0.02–0.03 s. In that window it writes `.coarse.tmp`, copies `.coarse-prev.tmp`, and renames twice. All of that usually completes between samples, so `output_peak_estimate_bytes` reflects the end state. v1 runs about 10 s and gets sampled hundreds of times.
- **Effect.** The "Peak disk: no increase" bar compares a near-true peak (v1) with an end-state value (probe). At the expected sizes (32 KiB vs 242 MiB) this will not flip the verdict, but the measured quantity is not what the bar names.
- **Fix.** Either derive the probe's peak analytically from its publish sequence (old current + previous temp + new temp, recorded by the probe in its report), or state in the doc and the results that the disk bar uses a sampled lower bound that misses transients shorter than 50 ms.

**[P3] Doc, "Decision bars (unchanged from the v1 plan …) apply as written": the bullets are not as written.**
- **What is wrong.** The bullets now say "no increase" and "no slowdown". The paragraph below admits the plan says "no confirmed increase". Tightening before measurement is legitimate, but the bullets are presented as quotations of D2–D14.
- **Fix.** Quote D2–D14 verbatim, then present the stricter evidence rule as an explicit pre-registered addition.

**[P3] Doc, evidence rules: three smaller gaps.**
- The smoke has one pair. The doc never says smoke results are excluded from bar judgment.
- "v1 value plus the noise floor" does not say whether the allowance is `max(5%, 0.05 s)` or something else. That is implied by "exceeds both" but should be stated.
- "the worker polls up to 50 ms" is not why elapsed time is coarse. Elapsed is measured around `process.wait()`; only the disk/space sampler polls.
- **Fix.** State that bars are judged on the screen only, state the allowance formula, and correct the justification.

**[P3] Doc, predictions: they contradict the new bullet.**
- **What is wrong.** "Under 10% of v1's roughly 10.7 s" and "under v1's (36.7 MiB earlier)" use cross-run absolutes. The added bullet says those absolutes are "not a prediction and not a gate".
- **Fix.** Restate the predictions against this run's v1 medians, per profile.

**[P3] Arm order is still 2:1 within each judged cell at screen scale.**
- **What is wrong.** `order(s, p, q)` balances each scenario across both profiles (3:3). Bars, however, are judged "separately for each scenario and profile", and within each such cell the screen order is still 2:1. The doc's "12:12" balance does not reach the unit of judgment.
- **Fix.** Disclose this, or accept it explicitly as round 1 did.

**[P3] `main.rs::refresh` / `live_ancestor`: `..` in the missing remainder defeats the root check and plans the wrong bucket.**
- **What is wrong.** `requested = live.join(missing)` is not normalized, and `starts_with(root)` compares components lexically.
- **Triggers.**
  - `--target /scratch/tree/gone/../small`, where `gone` does not exist: canonicalize fails with ENOENT on `gone`, so `live` is the root and `missing` is `gone/../small`. The plan rescans the bucket of `gone`, not `small`, and reports `scope: range` with success.
  - `/scratch/tree/gone/../../../etc` passes the outside-root check.
- **Fix.** Reject targets containing a `Component::ParentDir` in `missing`, or anywhere in the target.

**[P3] `main.rs::live_ancestor`: two missing-target forms fail although the doc says missing targets are handled.**
- A relative single-component missing target (`--target gone`) fails. `Path::new("gone").parent()` is `Some("")`, and `canonicalize("")` returns NotFound, so the function ends with "missing target ancestor". Fix: map an empty parent to `"."`.
- A target below an ancestor that is now a file (`large/above/x`) returns ENOTDIR as a hard error rather than being treated as missing. Fix: treat ENOTDIR like NotFound, or document it next to "a retained target replaced by a file".

**[P3] `state.rs::check_structure` / `store::read`: the single root is not tied to the metadata.**
- **What is wrong.** `verify` accepts a snapshot whose only root is a file (kind 0), or whose root path differs from `meta.root`.
- **Effect.** `refresh` then fails later with "no retained ancestor" instead of being rejected at read time. The doc says the reader rejects structural damage.
- **Fix.** In `store::read`, require `root.kind == 1 && root.path == meta.root`.

**[P3] Quality gates are incomplete for the Python harness and for the dev CI trigger.**
- **What is wrong.**
  - No formatter, linter or type checker gates `scripts/cleanup_*.py`. Compound statements such as `small.mkdir(); retained.mkdir()` and `if not data: break` would fail strict ruff (E701/E702).
  - The `cleanup-ci.yml` `paths` filter omits `scripts/check.sh`, the size allowlist, `rustfmt.toml` and `core/**`. All of these change what `scripts/check.sh rust size` checks.
- **Fix.** Add ruff (and mypy or pyright) to `check.sh`, the pre-push hook and the CI job, and extend the `paths` filter.

**[P3] `cleanup_probe_host.py::run_container`: an early worker failure is masked.**
- **What is wrong.** If the worker fails before `output.mkdir()`, for example on the cgroup limit check, `(out/ident/'docker-state.json').write_text` raises FileNotFoundError and hides the real cause.
- **Fix.** Create `out/ident` with `mkdir(exist_ok=True)` before writing.

## Dispositions

- **Round-1 P1 clippy `manual_range_contains`:** I concede. That lint looks for a constant bound, and `b.lo <= slot && slot < b.hi` uses field and variable bounds. "Not reproduced" is plausible.
- **Round-1 P1 `scale`:** I concede. `scale=count` is in `build`'s receipt.
- **Round-1 P2 "timed refreshes never exercise the merge" (disclosed):** acceptable as a disclosure only if the oracle at least proves a refresh happened. See the first finding.
- **Other dispositions:** I accept them.

## Checked and found correct

- **`refresh` and `live_ancestor`:**
  - Target equal to the root: `Retained(root)`, `fallback=false`.
  - Deleted omitted target: `Range` with the same parent, no re-plan.
  - Deleted retained file: `Retained(parent)`.
  - Deleted retained directory: re-plan to `Retained(live)`. `live` is retained because retention is monotone in the ancestors, so the re-plan cannot yield a Range.
  - Symlinks resolving outside the root are rejected.
- **`check_structure`:** it accepts every output of `scan`, `update`, `update_range` and `prune`. Retained files are always direct children of a directory that is retained by the same size rule.
- **Scoped `scan_inner`:** returns the root node re-read, and it is covered by the two-pass digest.
- **Plan scopes for both profiles at 100k and 1M:** 148 / 202 / 8010 and 2 × entries are consistent with the fixture.
- **Counts:** cases 24 / 56, oracles 8 / 24, cycles, and trims 22 / 30 are consistent.

## Verdict

**GO** for the hosted smoke. Nothing found would make the smoke fail, mis-report scope, or let a failed result pass at the smoke stage. The expected scopes for every arm, scenario and profile follow from the fixture arithmetic and match the probe's planning code. The re-plan logic and the parent re-read are correct for the hosted targets. `check_structure` does not reject valid snapshots.

The P2 findings concern how the screen will be judged and what the oracle can prove. They must be fixed, or explicitly disclosed, before the screen result is reported. One practical point: any edit to `scripts/cleanup_*` changes the captured source and requires a new smoke. If you intend to fix the oracle seed check and add a verdict script, do it before this smoke to avoid spending smoke time twice.

## Not verified

- Line counts and nesting of `main.rs` (about 400 lines by eye), `walk.rs`, `state.rs` and `bucket_tests.rs`. `bucket_tests.rs` is not named `tests.rs`, so the 500-line source limit applies to it.
- That `mounts::nested` treats the `/scratch/tree` bind mount as the root and not as a nested mount.
- v1 CLI report fields (`entries`, `subtree_entries`) and the v1 snapshot schema the oracle reads.
- `bench-v2-container.py` helpers (`flush_caches`, `verify_io`, `occupancy`), `cleanup_probe_runner.sh`, `scripts/check.sh`, and whether the size checker covers Python files.
- The FNV-1a vectors and the pinned windows `[804, 971)` / `[945, 956)`. I did not recompute them.
- That clippy `--all-targets` lints the example in test mode under the toolchain the CI and hook actually run.
- Whether any 1M chunk directory's slot collisions change the 4004-entry window.