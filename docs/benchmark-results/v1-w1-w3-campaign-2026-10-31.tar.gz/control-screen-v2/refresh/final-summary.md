# v1-single-operation-pairs-v2

Descriptive paired results; no automatic promotion or uncertainty estimate.
Application disk peak is sampled; RSS excludes the observer.

| Pair | Elapsed baseline → candidate (s) | RSS baseline → candidate (MiB) | App disk baseline → candidate (GiB) |
|---:|---:|---:|---:|
| 1 | 10.590 → 10.628 (Δ +0.038) | 245.422 → 245.316 (Δ -0.105) | 0.349 → 0.349 (Δ +0.000) |
| 2 | 10.706 → 10.606 (Δ -0.100) | 245.426 → 245.184 (Δ -0.242) | 0.349 → 0.349 (Δ +0.000) |
| 3 | 10.623 → 10.608 (Δ -0.015) | 245.102 → 245.309 (Δ +0.207) | 0.349 → 0.349 (Δ +0.000) |

Identical binaries: observed maximum absolute paired differences (descriptive band):
- elapsed_seconds: median Δ -0.015; max |Δ| 0.100
- peak_rss_kib: median Δ -108.000; max |Δ| 248.000
- app_disk_peak_bytes: median Δ +0.000; max |Δ| 0.000

VALID
