# v1-single-operation-pairs-v2

Descriptive paired results; no automatic promotion or uncertainty estimate.
Application disk peak is sampled; RSS excludes the observer.

| Pair | Elapsed baseline → candidate (s) | RSS baseline → candidate (MiB) | App disk baseline → candidate (GiB) |
|---:|---:|---:|---:|
| 1 | 62.253 → 61.571 (Δ -0.682) | 26.910 → 26.984 (Δ +0.074) | 0.428 → 0.428 (Δ +0.000) |
| 2 | 61.335 → 61.221 (Δ -0.114) | 27.117 → 26.793 (Δ -0.324) | 0.428 → 0.428 (Δ +0.000) |
| 3 | 61.364 → 61.249 (Δ -0.115) | 26.918 → 26.938 (Δ +0.020) | 0.428 → 0.428 (Δ +0.000) |

Identical binaries: observed maximum absolute paired differences (descriptive band):
- elapsed_seconds: median Δ -0.115; max |Δ| 0.682
- peak_rss_kib: median Δ +20.000; max |Δ| 332.000
- app_disk_peak_bytes: median Δ +0.000; max |Δ| 0.000

VALID
