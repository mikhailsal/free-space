# v1-single-operation-pairs-v2

Descriptive paired results; no automatic promotion or uncertainty estimate.
Application disk peak is sampled; RSS excludes the observer.

| Pair | Elapsed baseline → candidate (s) | RSS baseline → candidate (MiB) | App disk baseline → candidate (GiB) |
|---:|---:|---:|---:|
| 1 | 2.179 → 2.157 (Δ -0.022) | 26.773 → 26.762 (Δ -0.012) | 0.042 → 0.042 (Δ +0.000) |

Identical binaries: observed maximum absolute paired differences (descriptive band):
- elapsed_seconds: median Δ -0.022; max |Δ| 0.022
- peak_rss_kib: median Δ -12.000; max |Δ| 12.000
- app_disk_peak_bytes: median Δ +0.000; max |Δ| 0.000

VALID
