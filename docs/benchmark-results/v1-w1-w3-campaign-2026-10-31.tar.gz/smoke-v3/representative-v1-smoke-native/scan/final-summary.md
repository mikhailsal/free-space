# v1-single-operation-pairs-v3

Descriptive paired results; no automatic promotion or uncertainty estimate.
Application disk peak is sampled; RSS excludes the observer.

| Pair | Elapsed baseline → candidate (s) | RSS baseline → candidate (MiB) | App disk baseline → candidate (GiB) |
|---:|---:|---:|---:|
| 1 | 2.729 → 2.727 (Δ -0.001) | 26.879 → 26.730 (Δ -0.148) | 0.036 → 0.042 (Δ +0.007) |

Identical binaries: observed maximum absolute paired differences (descriptive band):
- elapsed_seconds: median Δ -0.001; max |Δ| 0.001
- peak_rss_kib: median Δ -152.000; max |Δ| 152.000
- app_disk_peak_bytes: median Δ +7159808.000; max |Δ| 7159808.000

VALID
