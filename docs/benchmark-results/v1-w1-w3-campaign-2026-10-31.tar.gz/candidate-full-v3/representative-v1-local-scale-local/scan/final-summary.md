# v1-single-operation-pairs-v3

Descriptive paired results; no automatic promotion or uncertainty estimate.
Application disk peak is sampled; RSS excludes the observer.

| Pair | Elapsed baseline → candidate (s) | RSS baseline → candidate (MiB) | App disk baseline → candidate (GiB) |
|---:|---:|---:|---:|
| 1 | 534.609 → 470.898 (Δ -63.712) | 23.113 → 23.391 (Δ +0.277) | 3.133 → 3.133 (Δ -0.000) |

VALID
