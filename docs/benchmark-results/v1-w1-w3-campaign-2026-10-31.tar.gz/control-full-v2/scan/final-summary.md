# v1-single-operation-pairs-v2

Descriptive paired results; no automatic promotion or uncertainty estimate.
Application disk peak is sampled; RSS excludes the observer.

| Pair | Elapsed baseline → candidate (s) | RSS baseline → candidate (MiB) | App disk baseline → candidate (GiB) |
|---:|---:|---:|---:|
| 1 | 522.921 → 532.228 (Δ +9.307) | 23.332 → 23.477 (Δ +0.145) | 3.133 → 3.133 (Δ -0.000) |

Identical binaries: observed maximum absolute paired differences (descriptive band):
- elapsed_seconds: median Δ +9.307; max |Δ| 9.307
- peak_rss_kib: median Δ +148.000; max |Δ| 148.000
- app_disk_peak_bytes: median Δ -16384.000; max |Δ| 16384.000

VALID
