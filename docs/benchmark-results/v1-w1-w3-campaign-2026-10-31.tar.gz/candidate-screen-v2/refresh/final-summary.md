# v1-single-operation-pairs-v2

Descriptive paired results; no automatic promotion or uncertainty estimate.
Application disk peak is sampled; RSS excludes the observer.

| Pair | Elapsed baseline → candidate (s) | RSS baseline → candidate (MiB) | App disk baseline → candidate (GiB) |
|---:|---:|---:|---:|
| 1 | 10.633 → 10.621 (Δ -0.012) | 245.348 → 245.199 (Δ -0.148) | 0.349 → 0.349 (Δ +0.000) |
| 2 | 10.643 → 10.587 (Δ -0.056) | 245.246 → 245.211 (Δ -0.035) | 0.349 → 0.349 (Δ +0.000) |
| 3 | 10.615 → 10.687 (Δ +0.072) | 245.367 → 245.461 (Δ +0.094) | 0.349 → 0.349 (Δ +0.000) |

VALID
