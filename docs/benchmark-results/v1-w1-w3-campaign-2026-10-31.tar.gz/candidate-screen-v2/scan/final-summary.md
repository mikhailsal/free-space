# v1-single-operation-pairs-v2

Descriptive paired results; no automatic promotion or uncertainty estimate.
Application disk peak is sampled; RSS excludes the observer.

| Pair | Elapsed baseline → candidate (s) | RSS baseline → candidate (MiB) | App disk baseline → candidate (GiB) |
|---:|---:|---:|---:|
| 1 | 61.958 → 53.106 (Δ -8.852) | 26.910 → 27.051 (Δ +0.141) | 0.428 → 0.428 (Δ +0.000) |
| 2 | 63.179 → 53.163 (Δ -10.016) | 26.648 → 26.922 (Δ +0.273) | 0.428 → 0.428 (Δ +0.000) |
| 3 | 61.470 → 53.399 (Δ -8.071) | 26.699 → 26.734 (Δ +0.035) | 0.428 → 0.428 (Δ +0.000) |

VALID
