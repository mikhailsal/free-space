# v1-single-operation-pairs-v4

Case: {"case_policy": "qualification-v1", "memory_mib": 4096, "mutation_receipt": null, "observer_memory_mib": 4096, "scenario": "unchanged", "setup_memory_mib": 4096, "subtree_entries": 100}


Descriptive paired results; no automatic promotion or uncertainty estimate.
Application disk peak is sampled; RSS excludes the observer.

| Pair | Elapsed baseline → candidate (s) | RSS baseline → candidate (MiB) | App disk baseline → candidate (GiB) |
|---:|---:|---:|---:|
| 1 | 10.820 → 10.803 (Δ -0.016) | 369.109 → 281.098 (Δ -88.012) | 0.349 → 0.349 (Δ +0.000) |
| 2 | 10.777 → 10.779 (Δ +0.002) | 369.039 → 281.043 (Δ -87.996) | 0.349 → 0.349 (Δ +0.000) |
| 3 | 10.810 → 10.765 (Δ -0.045) | 369.082 → 280.902 (Δ -88.180) | 0.349 → 0.349 (Δ +0.000) |

VALID
