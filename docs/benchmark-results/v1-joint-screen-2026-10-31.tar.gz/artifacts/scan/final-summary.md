# v1-single-operation-pairs-v4

Case: {"case_policy": "qualification-v1", "memory_mib": 4096, "mutation_receipt": null, "observer_memory_mib": 4096, "scenario": "unchanged", "setup_memory_mib": 4096, "subtree_entries": 100}


Descriptive paired results; no automatic promotion or uncertainty estimate.
Application disk peak is sampled; RSS excludes the observer.

| Pair | Elapsed baseline → candidate (s) | RSS baseline → candidate (MiB) | App disk baseline → candidate (GiB) |
|---:|---:|---:|---:|
| 1 | 70.245 → 48.301 (Δ -21.945) | 37.004 → 36.906 (Δ -0.098) | 0.428 → 0.428 (Δ +0.000) |
| 2 | 70.047 → 48.237 (Δ -21.810) | 36.891 → 36.926 (Δ +0.035) | 0.428 → 0.428 (Δ +0.000) |
| 3 | 70.040 → 48.449 (Δ -21.591) | 36.895 → 36.867 (Δ -0.027) | 0.428 → 0.428 (Δ +0.000) |

VALID
