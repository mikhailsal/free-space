# v1-single-operation-pairs-v3

Descriptive paired results; no automatic promotion or uncertainty estimate.
Application disk peak is sampled; RSS excludes the observer.

| Pair | Elapsed baseline → candidate (s) | RSS baseline → candidate (MiB) | App disk baseline → candidate (GiB) |
|---:|---:|---:|---:|
| 1 | 74.188 → 74.585 (Δ +0.397) | 1764.629 → 1202.832 (Δ -561.797) | 2.550 → 2.550 (Δ -0.000) |

VALID
