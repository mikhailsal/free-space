# v1-single-operation-pairs-v3

Descriptive paired results; no automatic promotion or uncertainty estimate.
Application disk peak is sampled; RSS excludes the observer.

| Pair | Elapsed baseline → candidate (s) | RSS baseline → candidate (MiB) | App disk baseline → candidate (GiB) |
|---:|---:|---:|---:|
| 1 | 69.167 → 47.401 (Δ -21.766) | 36.938 → 36.930 (Δ -0.008) | 0.428 → 0.428 (Δ +0.000) |
| 2 | 68.847 → 47.301 (Δ -21.546) | 36.984 → 37.062 (Δ +0.078) | 0.428 → 0.428 (Δ +0.000) |
| 3 | 69.287 → 47.579 (Δ -21.707) | 36.984 → 36.934 (Δ -0.051) | 0.428 → 0.428 (Δ +0.000) |

VALID
