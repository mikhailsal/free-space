# v1-single-operation-pairs-v3

Descriptive paired results; no automatic promotion or uncertainty estimate.
Application disk peak is sampled; RSS excludes the observer.

| Pair | Elapsed baseline → candidate (s) | RSS baseline → candidate (MiB) | App disk baseline → candidate (GiB) |
|---:|---:|---:|---:|
| 1 | 10.774 → 10.824 (Δ +0.050) | 369.512 → 369.641 (Δ +0.129) | 0.350 → 0.350 (Δ +0.000) |
| 2 | 10.762 → 10.761 (Δ -0.001) | 369.703 → 369.691 (Δ -0.012) | 0.350 → 0.350 (Δ +0.000) |
| 3 | 10.749 → 10.766 (Δ +0.016) | 369.586 → 369.570 (Δ -0.016) | 0.350 → 0.350 (Δ +0.000) |

VALID
